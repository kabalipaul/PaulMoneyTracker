# PaulMoneyTracker: user guide

> "A part of all you earn is yours to keep."

## The idea

Every time you earn money, the app divides it into four envelopes:

| Envelope | Default | What it is for |
|----------|---------|----------------|
| Living Expenses | 70% | Rent, food, transport, bills, family needs |
| Savings | 10% | Money you keep. Build it up, withdraw rarely |
| Investments | 10% | Money you put to work (T-bills, bonds, business, land…) |
| Debt Repayment / Giving | 10% | Paying what you owe, supporting family, donations, charity |

These are tracking envelopes, not bank accounts. The app never moves real money.

## Daily routine (under a minute)

1. Open the app and tap **+ Add Income**.
2. Enter the amount, check the date, pick the source (Salary, Business, Freelancing, Agriculture, Other) and add an optional note.
3. The allocation preview shows exactly where the money goes. Tap **Save income**.
4. Got paid from two places today? Add a second entry. Each is split separately.

If you haven't recorded anything by your reminder time (8:00 PM by default), you'll get a notification.
Tap it to go straight to Add Income.

## Screens

**Home:** wealth built so far and the share of your income you've kept, today/week/month/all-time
income, the four envelope cards (allocated, used, remaining), a distribution chart, a summary and recent income.
Tap the ⚙ icon for Settings.

**Calendar:** each month at a glance. Green days have income, and the small number is that day's total.
Today has a gold outline. Use ‹ › to change month and « » to change year. Tap a day to see its entries and how
they were split, or to **add income for that date**. The month summary shows total income, days with income,
average per income day and each envelope's share.

**My Accounts:** tap an envelope to see its full history and record what you did with the money:
- *Living Expenses* → **Record expense** (category, date, description, notes).
- *Savings* → **Withdraw**, or **Add deposit** for money from outside your recorded income. Set a **savings target** here.
- *Investments* → **Invest money** (choose the type, and optionally the current value), **Record return** (profit/interest),
  **Cash out** (capital back when an investment matures). To update what an investment is worth, open it and change *Current value*.
- *Debt Repayment / Giving* → debt repayment, family support, donation, charity, other.
- **Transfer** moves money between envelopes (e.g. Living → Savings at month end). Transfers are never counted as income.
- Tap the ✎ icon to rename an envelope.

Tap any history line to edit or delete it. Everything recalculates instantly.

**Reports** (now with a **Loans** tab covering borrowing, lending and the combined position): pick a period (today, this week, last month, last 6 months, this year… or a **custom range** with start
and end dates). There are six tabs: Overview, Income, Allocation, Expenses, Savings, Investments. **Export PDF** or **Export
CSV** (opens in Excel/Google Sheets), then **Share** (WhatsApp, email, Drive…) or **Save to phone**.

**Loans:** keeps track of money you borrow and money you lend.
- The summary at the top shows what you owe (orange), what others owe you (green), repayments made and received,
  and your **net loan position**. Overdue loans show in a red banner.
- **Money I Owe** tab → **+ Add Loan**: the creditor, the amount, the date, an optional expected repayment date, the
  **account that received the money**, optional interest, purpose, contact and notes. Borrowed money is *not* income,
  so it is not split 70-10-10-10.
- **Money Owed to Me** tab → **+ Add Debtor**: the same fields, plus the **account the money came from**. That
  account goes down by the amount lent.
- Tap any loan to see its details and history. Use **Make Repayment** or **Record Repayment Received**. Choose
  Living Expenses, Savings or Debt Repayment/Giving (Investments is never used for loans). The app refuses to pay more
  than is owed, or more than the account holds.
- Tap a repayment in the history to edit or delete it. Every balance updates automatically.
- **Interest (optional):** choose per month or per year. It is simple interest on the amount still owed, and never
  interest on interest. Choose whether repayments cover interest first or principal first.
- Filter each tab by status: Active, Partially Paid/Repaid, Overdue, Fully Paid/Repaid.

**Goals:** tap **+** to create a goal, e.g. *Save UGX 5,000,000*, *Invest UGX 3,000,000*, or *Emergency fund
UGX 2,000,000*. Choose how progress is measured:
- *Savings balance*: follows your Savings envelope
- *Total money invested*: all contributions
- *Recorded investment value*: what your investments are worth now
- *Total tracked assets*: all envelope balances plus investments (good for "UGX 10,000,000 in total assets")
- *I'll update it myself*: enter the amount manually

Add an optional target date to see days left.

## Settings

- **Allocation percentages:** change to e.g. 60/15/15/10. They must total exactly 100%. You'll be asked to
  confirm. Only new income uses the new split; old entries keep theirs.
- **Daily reminder:** turn on/off, pick the time, and choose whether you want a "well done" message on days you've already recorded.
- **Currency:** code, symbol and decimals (UGX has none). This changes display only; it doesn't convert records.
- **Account names**, **Appearance** (light/dark/system).
- **Your data:** **Back up database** (save the file to Google Drive or your computer regularly),
  **Restore from backup** (replaces everything and restarts), **Export all records (CSV)**.

## Tips

- Record income the same day you receive it. The calendar makes gaps obvious.
- At month end, move any unused Living money into Savings with a **Transfer**.
- Never use investment *contributions* as profit. Record **returns** when they actually arrive.
- Back up at least once a month. Your data exists only on this phone.
