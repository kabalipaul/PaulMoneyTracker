# Architecture and financial rules

## Layers

```
Compose screens  ──observe──▶  ViewModels (StateFlow)  ──call──▶  Repositories  ──▶  Room DAOs  ──▶  SQLite
                                     │
                                     └── pure domain calculators (no Android code, unit-tested)
```

- **MainViewModel** combines every stored record into one `AppState` (balances, totals, goals) that
  Home, Calendar, Accounts and Goals read. It also performs all writes and reports errors back to the screen.
- **ReportsViewModel** owns the selected period and builds the six reports; it also writes PDF/CSV exports.
- **SettingsViewModel** handles allocation, currency, names, theme, reminders, backup/restore and export-all.
- **FinanceRepository** is the only class that writes financial records. Every multi-row write runs in
  `db.withTransaction { }`.
- Dependencies are wired by hand in `AppContainer` (no DI framework to keep the build simple).

## Database (Room, version 1)

| Table | Purpose |
|-------|---------|
| `accounts` | The four envelopes (ids 1–4), with user-editable names |
| `income_transactions` | Amount, date, source, description, **the four percentages in force when recorded**, created/updated time |
| `allocations` | One row per envelope per income: account, percentage, amount. FK → income (cascade) |
| `account_transactions` | Ledger of every other money movement: account, type, amount, date, description, notes, transfer reference |
| `expense_transactions` | Category for a living expense. FK → ledger row (cascade) |
| `investment_transactions` | Investment type and optional current value. FK → ledger row (cascade) |
| `savings_goals` | Name, target, optional date, how progress is measured, manual amount |
| `app_settings` | Currency, decimals, theme, current percentages, savings target |
| `reminder_settings` | On/off, time, confirmation preference |

Dates are stored as epoch days (`LocalDate.toEpochDay()`), so a date never shifts with time-zone changes.
Money is stored as `Long` minor units (amount × 100). There is no floating-point arithmetic on balances.

**No balance is stored.** Every balance is rebuilt from `allocations` + `account_transactions` each time data
changes (`LedgerCalculator.overview`). Editing or deleting any record therefore can't leave a balance out of step.

## Financial rules and decisions

1. **Automatic allocation.** On save, `AllocationCalculator` splits the income. Savings, Investments and
   Debt/Giving are each rounded *down* to the currency's smallest unit (whole shillings for UGX).
   Living Expenses gets the remainder, so the four parts always equal the income exactly.
2. **Historical accuracy.** Each income stores its own percentages. Changing the settings affects only income
   recorded afterwards. **Editing** an old income re-splits the new amount using *that entry's* original percentages.
3. **No double counting.**
   - *Transfers* between envelopes are two linked ledger rows (out + in). They are never income or expenditure.
     Deleting one side deletes both.
   - *Savings deposits* ("from another source") add to Savings but are not income. If the money was earned, record it as income instead.
4. **Balances.** `balance = allocated + money in (transfers in, deposits, returns, cash-outs) − main use − transfers out`.
   Main use is Expenses (Living), Withdrawals (Savings), Contributions (Investments) and Payments (Debt/Giving).
5. **Investments.**
   - *Contribution*: money moved out of the Investments envelope into an investment. It is not an expense and not profit.
   - *Return*: profit, interest or dividends. It goes back into the Investments envelope (ready to reinvest) and is
     reported separately. It is not counted as income, so it is never allocated 70/10/10/10.
   - *Cash-out*: original capital coming back. It refills the envelope and lowers the recorded investment value.
   - *Recorded value* = sum of each contribution's latest value (or its cost if no value was entered) − cash-outs.
6. **Expenditure** in summaries = living expenses + debt repayment/giving. Investment contributions,
   transfers and savings withdrawals are not expenditure.
7. **Wealth built** = Savings balance + uninvested Investments cash + recorded investment value.
   "Kept %" on Home = wealth built ÷ total income.
8. **Overspending** is allowed but clearly flagged. The form warns, and the account turns red if its balance is negative.
9. **Reports** use only stored transactions inside the chosen range. "Balance at end" figures include everything
   up to the range's last day. Weeks run Monday–Sunday. "Last 3/6 months" are rolling windows ending today.
   Charts use daily buckets for ≤ 31 days, weekly for ≤ 124 days, and monthly beyond.

## Loans module (database version 2)

**Tables added by `MIGRATION_1_2`.** The migration only creates new tables and changes no existing data:

| Table | Purpose |
|-------|---------|
| `loans` | Direction (BORROWED = money I owe, LENT = owed to me), name, principal, date, expected date, interest rate (basis points), interest period (none / monthly / annual), repayment order, purpose, contact, notes, and `disbursementTxId`, the ledger row that moved the money in or out |
| `loan_repayments` | Links a loan to the ledger row of each repayment. FK → loans (cascade) and FK → account_transactions (cascade) |

Amount, date and account for every loan movement live on its `account_transactions` row, using four new types:
`LOAN_RECEIVED` (in), `LOAN_REPAYMENT` (out), `LOAN_GIVEN` (out) and `LOAN_RECOVERED` (in).
The loan history and the account history are therefore the same records and can never disagree.

**Accounting rules**
- Borrowed money is never income and is never split 70-10-10-10. It enters the chosen account, and the debt is tracked.
- A repayment leaves the chosen account. It is not living expenditure. From Debt Repayment/Giving it counts as that envelope's "Used".
- Lent money leaves the chosen account and becomes a receivable. It is not an expense.
- Money received back refills the chosen account. Returned principal is not income. The interest part is reported separately as "interest earned".
- Only Living Expenses, Savings and Debt Repayment/Giving can send or receive loan money. Investments is excluded.
- Net wealth on Home = savings + investments + money owed to me − money I owe.

**Balances are calculated, never typed in.** `LoanCalculator.compute` replays the loan: simple interest accrues on
the principal still outstanding between events (calendar-exact months/years; interest is never charged on interest),
then each repayment is split by the chosen order (interest-first or principal-first).
Status: **Fully Paid/Repaid** when nothing is owed; **Overdue** when money is owed after the expected date;
**Partially Paid/Repaid** after any repayment; otherwise **Active**.

**Atomic safety.** Each loan action runs in one `withTransaction`. It writes the loan row and its ledger row, then
re-checks the result. The action is rejected and fully rolled back if (a) any account it reduced would fall below zero,
or (b) any repayment would pay more than was owed at its date. Editing or deleting a repayment changes its ledger row
in place or removes it, so the account balance and the loan balance are both recalculated.

## Reminders

`ReminderScheduler` queues a one-time WorkManager job for the next reminder time. When the job runs it checks
whether income exists for today: if none, it posts the reminder; if some, it posts an optional confirmation.
It then queues the next day's job (`APPEND_OR_REPLACE`, so it doesn't cancel itself). WorkManager keeps jobs across
app closes and reboots. `BootReceiver` also re-aligns the time after a reboot, app update, or clock/time-zone
change. If the phone was off and the job runs more than 3 hours late, it skips that reminder instead of nagging at
the wrong time. The notification opens the Add Income screen. Android 13+ permission is requested once on first
launch and can be granted later from Settings.

## Exports and backup

- **PDF** uses Android's built-in `PdfDocument`: A4, all six report sections, bar charts.
- **CSV** is Excel-compatible (UTF-8 with BOM, quoted fields) and includes a summary plus every transaction in the range.
- Files can be shared with the Android share sheet (`FileProvider`) or saved anywhere with the system file picker.
- **Backup** checkpoints the SQLite write-ahead log and copies the database file to a location you choose.
  **Restore** validates the file (SQLite header, required tables, schema version), replaces the database and restarts the app.

## Extending

- New envelope types: add to `AccountType` and seed in `AppDatabase.SeedCallback` (with a Room migration).
- Schema changes: bump `version` in `AppDatabase`, add a `Migration`, and keep the exported schema in `app/schemas`.
- New transaction kinds: add to `TxType` with its direction and allowed accounts. Balances pick it up automatically.
