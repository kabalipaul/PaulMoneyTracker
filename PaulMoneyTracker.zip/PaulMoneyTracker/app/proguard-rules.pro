# Room, WorkManager and Compose ship their own consumer rules.
# Keep enum names because they are persisted in the database as text.
-keepclassmembers enum com.babylon.moneytracker.domain.** { *; }
-keep class com.babylon.moneytracker.reminder.** { *; }
