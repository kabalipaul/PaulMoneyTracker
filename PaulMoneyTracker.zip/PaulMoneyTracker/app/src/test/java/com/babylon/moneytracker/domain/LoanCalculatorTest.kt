package com.babylon.moneytracker.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class LoanCalculatorTest {

    private val unit = Money.allocationUnit(0)
    private fun ugx(units: Long) = units * Money.SCALE
    private val d0 = LocalDate.of(2026, 1, 1)
    private var nextId = 100L

    private fun loan(
        principal: Long,
        dir: LoanDirection = LoanDirection.BORROWED,
        account: AccountType = AccountType.SAVINGS,
        due: LocalDate? = null,
        rateBp: Int = 0,
        period: InterestPeriod = InterestPeriod.NONE,
        order: RepaymentOrder = RepaymentOrder.INTEREST_FIRST,
        payments: List<LoanPayment> = emptyList(),
    ) = LoanRecord(
        id = 1, direction = dir, counterparty = "John", principal = ugx(principal), date = d0, dueDate = due,
        account = account, interestRateBp = rateBp, interestPeriod = period, repaymentOrder = order,
        purpose = null, contact = null, notes = null, disbursementTxId = 1, payments = payments,
    )

    private fun pay(units: Long, date: LocalDate, account: AccountType = AccountType.SAVINGS) =
        LoanPayment(nextId++, ugx(units), date, account, null, nextId)

    // ---- the money side, as the account ledger sees it ----
    private fun income(units: Long) = IncomeRecord(
        1, ugx(units), d0, "Salary", null, Percentages.DEFAULT,
        AllocationCalculator.allocate(ugx(units), Percentages.DEFAULT, unit),
    )

    private fun tx(account: AccountType, type: TxType, units: Long) =
        LedgerRecord(nextId++, account, type, ugx(units), d0, type.label)

    @Test
    fun `borrowing into savings raises savings but not income`() {
        val o = LedgerCalculator.overview(
            listOf(income(1_000_000)),
            listOf(tx(AccountType.SAVINGS, TxType.LOAN_RECEIVED, 1_000_000)),
        )
        assertEquals(ugx(1_100_000), o.account(AccountType.SAVINGS).balance)
        assertEquals(ugx(1_000_000), o.totalIncome)
        assertEquals(0L, o.totalExpenditure)
    }

    @Test
    fun `repaying from savings lowers savings and the loan, not counted as expenditure`() {
        val l = loan(1_000_000, payments = listOf(pay(200_000, d0.plusDays(10))))
        val s = LoanCalculator.compute(l, d0.plusDays(20), unit)
        assertEquals(ugx(200_000), s.totalPaid)
        assertEquals(ugx(800_000), s.totalOutstanding)
        assertEquals(LoanStatus.PARTIAL, s.status)

        val o = LedgerCalculator.overview(
            listOf(income(1_000_000)),
            listOf(
                tx(AccountType.SAVINGS, TxType.LOAN_RECEIVED, 1_000_000),
                tx(AccountType.SAVINGS, TxType.LOAN_REPAYMENT, 200_000),
            ),
        )
        assertEquals(ugx(900_000), o.account(AccountType.SAVINGS).balance)
        assertEquals(0L, o.totalExpenditure)
    }

    @Test
    fun `repayment from debt-giving counts as that envelope's use`() {
        val o = LedgerCalculator.overview(
            listOf(income(1_000_000)),
            listOf(tx(AccountType.GIVING, TxType.LOAN_REPAYMENT, 30_000)),
        )
        assertEquals(ugx(30_000), o.account(AccountType.GIVING).used)
        assertEquals(ugx(70_000), o.account(AccountType.GIVING).balance)
    }

    @Test
    fun `lending and recovering through living expenses`() {
        val o1 = LedgerCalculator.overview(
            listOf(income(1_000_000)),
            listOf(tx(AccountType.LIVING, TxType.LOAN_GIVEN, 500_000)),
        )
        assertEquals(ugx(200_000), o1.account(AccountType.LIVING).balance)
        assertEquals(0L, o1.totalExpenditure) // lending is not an expense

        val o2 = LedgerCalculator.overview(
            listOf(income(1_000_000)),
            listOf(
                tx(AccountType.LIVING, TxType.LOAN_GIVEN, 500_000),
                tx(AccountType.LIVING, TxType.LOAN_RECOVERED, 150_000),
            ),
        )
        assertEquals(ugx(350_000), o2.account(AccountType.LIVING).balance)
        assertEquals(ugx(1_000_000), o2.totalIncome) // returned principal is not income

        val mary = loan(500_000, dir = LoanDirection.LENT, account = AccountType.LIVING,
            payments = listOf(pay(150_000, d0.plusDays(5), AccountType.LIVING)))
        val s = LoanCalculator.compute(mary, d0.plusDays(6), unit)
        assertEquals(ugx(350_000), s.totalOutstanding)
        assertEquals("Partially Repaid", s.status.label(LoanDirection.LENT))
    }

    @Test
    fun `multiple repayments and full settlement`() {
        val l = loan(1_000_000, payments = listOf(
            pay(200_000, d0.plusDays(1)), pay(300_000, d0.plusDays(2)), pay(500_000, d0.plusDays(3)),
        ))
        val s = LoanCalculator.compute(l, d0.plusDays(10), unit)
        assertEquals(0L, s.totalOutstanding)
        assertEquals(LoanStatus.SETTLED, s.status)
        assertEquals("Fully Paid", s.status.label(LoanDirection.BORROWED))
        assertEquals(listOf(ugx(800_000), ugx(500_000), 0L), s.lines.map { it.balanceAfter })
    }

    @Test
    fun `overdue when due date passed with balance left`() {
        val l = loan(100_000, due = d0.plusDays(30))
        assertEquals(LoanStatus.ACTIVE, LoanCalculator.compute(l, d0.plusDays(30), unit).status)
        assertEquals(LoanStatus.OVERDUE, LoanCalculator.compute(l, d0.plusDays(31), unit).status)
        val paid = l.copy(payments = listOf(pay(100_000, d0.plusDays(40))))
        assertEquals(LoanStatus.SETTLED, LoanCalculator.compute(paid, d0.plusDays(41), unit).status)
    }

    @Test
    fun `overpayment is detected as excess`() {
        val l = loan(100_000, payments = listOf(pay(150_000, d0.plusDays(1))))
        val s = LoanCalculator.compute(l, d0.plusDays(2), unit)
        assertEquals(ugx(50_000), s.excess)
        assertEquals(0L, s.totalOutstanding)
    }

    @Test
    fun `deleting a repayment restores the balance`() {
        val p1 = pay(200_000, d0.plusDays(1))
        val p2 = pay(300_000, d0.plusDays(2))
        val l = loan(1_000_000, payments = listOf(p1, p2))
        assertEquals(ugx(500_000), LoanCalculator.compute(l, d0.plusDays(5), unit).totalOutstanding)
        val afterDelete = l.copy(payments = listOf(p1))
        assertEquals(ugx(800_000), LoanCalculator.compute(afterDelete, d0.plusDays(5), unit).totalOutstanding)
        val afterEdit = l.copy(payments = listOf(p1, p2.copy(amount = ugx(100_000))))
        assertEquals(ugx(700_000), LoanCalculator.compute(afterEdit, d0.plusDays(5), unit).totalOutstanding)
    }

    @Test
    fun `monthly simple interest is exact for whole months`() {
        // 1,000,000 at 5% per month for exactly 1 month = 50,000
        val l = loan(1_000_000, rateBp = 500, period = InterestPeriod.MONTHLY)
        val s = LoanCalculator.compute(l, d0.plusMonths(1), unit)
        assertEquals(ugx(50_000), s.interestAccrued)
        assertEquals(ugx(1_050_000), s.totalOutstanding)
        assertEquals(ugx(1_000_000), s.principalOutstanding)
    }

    @Test
    fun `annual simple interest is not compounded`() {
        // 1,000,000 at 10% per year for 2 years = 200,000 (compound would be 210,000)
        val l = loan(1_000_000, rateBp = 1000, period = InterestPeriod.ANNUAL)
        val s = LoanCalculator.compute(l, d0.plusYears(2), unit)
        assertEquals(ugx(200_000), s.interestAccrued)
    }

    @Test
    fun `interest-first versus principal-first`() {
        val p = pay(60_000, d0.plusMonths(1))
        val interestFirst = LoanCalculator.compute(
            loan(1_000_000, rateBp = 500, period = InterestPeriod.MONTHLY, payments = listOf(p)), d0.plusMonths(1), unit,
        )
        assertEquals(ugx(50_000), interestFirst.interestPaid)
        assertEquals(ugx(10_000), interestFirst.principalPaid)
        assertEquals(ugx(990_000), interestFirst.totalOutstanding)

        val principalFirst = LoanCalculator.compute(
            loan(1_000_000, rateBp = 500, period = InterestPeriod.MONTHLY,
                order = RepaymentOrder.PRINCIPAL_FIRST, payments = listOf(p)), d0.plusMonths(1), unit,
        )
        assertEquals(0L, principalFirst.interestPaid)
        assertEquals(ugx(60_000), principalFirst.principalPaid)
        assertEquals(ugx(940_000 + 50_000), principalFirst.totalOutstanding)
    }

    @Test
    fun `interest accrues on the reduced principal after a repayment`() {
        // Month 1 on 1,000,000 = 50,000. Pay 550,000 (interest first) -> principal 500,000.
        // Month 2 on 500,000 = 25,000.
        val l = loan(1_000_000, rateBp = 500, period = InterestPeriod.MONTHLY,
            payments = listOf(pay(550_000, d0.plusMonths(1))))
        val s = LoanCalculator.compute(l, d0.plusMonths(2), unit)
        assertEquals(ugx(75_000), s.interestAccrued)
        assertEquals(ugx(525_000), s.totalOutstanding)
    }

    @Test
    fun `totals and report`() {
        val borrowed = loan(1_000_000, payments = listOf(pay(200_000, d0.plusDays(5))), due = d0.plusDays(20))
        val lent = loan(500_000, dir = LoanDirection.LENT, account = AccountType.LIVING,
            payments = listOf(pay(150_000, d0.plusDays(6), AccountType.LIVING))).copy(id = 2, counterparty = "Mary")
        val today = d0.plusDays(25)
        val states = listOf(borrowed, lent).map { LoanCalculator.compute(it, today, unit) }
        val t = LoanTotals.of(states)
        assertEquals(ugx(800_000), t.owed)
        assertEquals(ugx(350_000), t.receivable)
        assertEquals(ugx(-450_000), t.net)
        assertEquals(ugx(200_000), t.repaymentsMade)
        assertEquals(ugx(150_000), t.repaymentsReceived)
        assertEquals(1, t.overdueOwed)

        val r = LoanReport.build(listOf(borrowed, lent), DateRange(d0, d0.plusDays(5)), today, unit)
        assertEquals(ugx(1_000_000), r.borrowing.newPrincipal)
        assertEquals(ugx(200_000), r.borrowing.repaidInPeriod)
        assertEquals(ugx(800_000), r.borrowing.outstandingAtEnd)
        assertEquals(0L, r.lending.repaidInPeriod) // Mary's repayment is on day 6, outside the range
        assertEquals(ugx(500_000), r.lending.outstandingAtEnd)
        assertEquals(1, r.borrowing.overdue.size)
        assertTrue(r.lending.byPerson.first().name == "Mary")
    }
}
