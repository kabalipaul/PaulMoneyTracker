package com.babylon.moneytracker.domain

import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDate

class LedgerCalculatorTest {

    private val unit = Money.allocationUnit(0)
    private fun ugx(units: Long) = units * Money.SCALE
    private val day1 = LocalDate.of(2026, 11, 2)
    private val day2 = LocalDate.of(2026, 11, 3)

    private var nextId = 1L
    private fun income(units: Long, date: LocalDate = day1, p: Percentages = Percentages.DEFAULT) =
        IncomeRecord(nextId++, ugx(units), date, "Salary", null, p, AllocationCalculator.allocate(ugx(units), p, unit))

    private fun tx(account: AccountType, type: TxType, units: Long, date: LocalDate = day1, value: Long? = null) =
        LedgerRecord(nextId++, account, type, ugx(units), date, type.label, currentValue = value?.let { ugx(it) })

    @Test
    fun `dashboard example balances`() {
        val incomes = listOf(income(1_000_000))
        val ledger = listOf(
            tx(AccountType.LIVING, TxType.EXPENSE, 350_000),
            tx(AccountType.INVESTMENTS, TxType.INVESTMENT_CONTRIBUTION, 50_000),
            tx(AccountType.GIVING, TxType.DEBT_REPAYMENT, 30_000),
        )
        val o = LedgerCalculator.overview(incomes, ledger)
        assertEquals(ugx(700_000), o.account(AccountType.LIVING).allocated)
        assertEquals(ugx(350_000), o.account(AccountType.LIVING).balance)
        assertEquals(ugx(100_000), o.account(AccountType.SAVINGS).balance)
        assertEquals(ugx(50_000), o.account(AccountType.INVESTMENTS).balance)
        assertEquals(ugx(50_000), o.account(AccountType.INVESTMENTS).used)
        assertEquals(ugx(70_000), o.account(AccountType.GIVING).balance)
        // Investment contribution is NOT expenditure.
        assertEquals(ugx(380_000), o.totalExpenditure)
        assertEquals(ugx(50_000), o.investmentContributions)
        assertEquals(ugx(1_000_000), o.totalIncome)
    }

    @Test
    fun `multiple incomes on the same day add up`() {
        val incomes = listOf(income(100_000), income(50_000), income(25_000))
        val t = LedgerCalculator.incomeTotals(incomes, today = day1)
        assertEquals(ugx(175_000), t.today)
        val o = LedgerCalculator.overview(incomes, emptyList())
        assertEquals(ugx(122_500), o.account(AccountType.LIVING).balance)
        assertEquals(ugx(17_500), o.account(AccountType.SAVINGS).balance)
    }

    @Test
    fun `deleting an income removes its allocation`() {
        val a = income(100_000)
        val b = income(200_000, day2)
        val before = LedgerCalculator.overview(listOf(a, b), emptyList())
        assertEquals(ugx(30_000), before.account(AccountType.SAVINGS).balance)
        val after = LedgerCalculator.overview(listOf(b), emptyList())
        assertEquals(ugx(20_000), after.account(AccountType.SAVINGS).balance)
        assertEquals(ugx(200_000), after.totalIncome)
    }

    @Test
    fun `editing an income keeps its original percentages`() {
        val original = income(100_000, p = Percentages.DEFAULT)
        // User changes settings to 60-15-15-10 later; the edit still uses the stored 70-10-10-10.
        val edited = original.copy(
            amount = ugx(200_000),
            split = AllocationCalculator.allocate(ugx(200_000), original.percentages, unit),
        )
        val newer = income(100_000, day2, Percentages(6000, 1500, 1500, 1000))
        val o = LedgerCalculator.overview(listOf(edited, newer), emptyList())
        assertEquals(ugx(140_000 + 60_000), o.account(AccountType.LIVING).allocated)
        assertEquals(ugx(20_000 + 15_000), o.account(AccountType.SAVINGS).allocated)
    }

    @Test
    fun `transfers move money but are not income`() {
        val incomes = listOf(income(100_000))
        val ledger = listOf(
            tx(AccountType.LIVING, TxType.TRANSFER_OUT, 20_000),
            tx(AccountType.SAVINGS, TxType.TRANSFER_IN, 20_000),
        )
        val o = LedgerCalculator.overview(incomes, ledger)
        assertEquals(ugx(100_000), o.totalIncome)
        assertEquals(ugx(50_000), o.account(AccountType.LIVING).balance)
        assertEquals(ugx(30_000), o.account(AccountType.SAVINGS).balance)
        assertEquals(ugx(100_000), o.accounts.values.sumOf { it.balance })
        assertEquals(0L, o.totalExpenditure)
    }

    @Test
    fun `savings withdrawals and deposits`() {
        val incomes = listOf(income(500_000))
        val ledger = listOf(
            tx(AccountType.SAVINGS, TxType.WITHDRAWAL, 20_000),
            tx(AccountType.SAVINGS, TxType.DEPOSIT, 5_000),
        )
        val s = LedgerCalculator.overview(incomes, ledger).account(AccountType.SAVINGS)
        assertEquals(ugx(50_000), s.allocated)
        assertEquals(ugx(20_000), s.used)
        assertEquals(ugx(35_000), s.balance)
    }

    @Test
    fun `investment returns are tracked separately from contributions`() {
        val incomes = listOf(income(1_000_000))
        val ledger = listOf(
            tx(AccountType.INVESTMENTS, TxType.INVESTMENT_CONTRIBUTION, 80_000, value = 90_000),
            tx(AccountType.INVESTMENTS, TxType.INVESTMENT_RETURN, 5_000),
        )
        val o = LedgerCalculator.overview(incomes, ledger)
        assertEquals(ugx(80_000), o.investmentContributions)
        assertEquals(ugx(5_000), o.investmentReturns)
        assertEquals(ugx(90_000), o.investmentHoldingsValue)
        assertEquals(ugx(25_000), o.account(AccountType.INVESTMENTS).balance)
        // Returns are not income.
        assertEquals(ugx(1_000_000), o.totalIncome)
    }

    @Test
    fun `cashing out reduces holdings and refills the envelope`() {
        val incomes = listOf(income(1_000_000))
        val ledger = listOf(
            tx(AccountType.INVESTMENTS, TxType.INVESTMENT_CONTRIBUTION, 100_000),
            tx(AccountType.INVESTMENTS, TxType.INVESTMENT_CASHOUT, 100_000),
        )
        val o = LedgerCalculator.overview(incomes, ledger)
        assertEquals(0L, o.investmentHoldingsValue)
        assertEquals(ugx(100_000), o.account(AccountType.INVESTMENTS).balance)
    }

    @Test
    fun `balance up to a date ignores later records`() {
        val incomes = listOf(income(100_000, day1), income(100_000, day2))
        val ledger = listOf(tx(AccountType.LIVING, TxType.EXPENSE, 10_000, day2))
        val o = LedgerCalculator.overview(incomes, ledger, upTo = day1)
        assertEquals(ugx(70_000), o.account(AccountType.LIVING).balance)
    }

    @Test
    fun `goal progress uses the right metric`() {
        val incomes = listOf(income(1_000_000))
        val o = LedgerCalculator.overview(incomes, emptyList())
        val g = Goal(1, "Save 5M", ugx(5_000_000), null, GoalMetric.SAVINGS_BALANCE, 0)
        val p = LedgerCalculator.goalProgress(g, o)
        assertEquals(ugx(100_000), p.current)
        assertEquals(2, p.percent)
        val manual = LedgerCalculator.goalProgress(g.copy(metric = GoalMetric.MANUAL, manualCurrent = ugx(2_500_000)), o)
        assertEquals(50, manual.percent)
    }
}
