package com.babylon.moneytracker.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AllocationCalculatorTest {

    private val ugxUnit = Money.allocationUnit(0)
    private fun ugx(units: Long) = units * Money.SCALE

    @Test
    fun `100,000 UGX splits 70-10-10-10`() {
        val s = AllocationCalculator.allocate(ugx(100_000), Percentages.DEFAULT, ugxUnit)
        assertEquals(ugx(70_000), s.living)
        assertEquals(ugx(10_000), s.savings)
        assertEquals(ugx(10_000), s.investments)
        assertEquals(ugx(10_000), s.giving)
        assertEquals(ugx(100_000), s.total)
    }

    @Test
    fun `1,500,000 UGX splits 70-10-10-10`() {
        val s = AllocationCalculator.allocate(ugx(1_500_000), Percentages.DEFAULT, ugxUnit)
        assertEquals(ugx(1_050_000), s.living)
        assertEquals(ugx(150_000), s.savings)
        assertEquals(ugx(150_000), s.investments)
        assertEquals(ugx(150_000), s.giving)
    }

    @Test
    fun `rounding remainder goes to living and total is exact`() {
        // 10% of 12,345 is 1,234.5 -> each small envelope gets 1,234; living gets the rest.
        val s = AllocationCalculator.allocate(ugx(12_345), Percentages.DEFAULT, ugxUnit)
        assertEquals(ugx(1_234), s.savings)
        assertEquals(ugx(1_234), s.investments)
        assertEquals(ugx(1_234), s.giving)
        assertEquals(ugx(8_643), s.living)
        assertEquals(ugx(12_345), s.total)
    }

    @Test
    fun `whole-shilling allocations for many odd amounts always sum exactly`() {
        val p = Percentages(6000, 1500, 1500, 1000)
        for (units in listOf(1L, 7L, 99L, 1_001L, 33_333L, 987_654_321L)) {
            val s = AllocationCalculator.allocate(ugx(units), p, ugxUnit)
            assertEquals(ugx(units), s.total)
            assertEquals(0L, s.savings % ugxUnit)
            assertEquals(0L, s.investments % ugxUnit)
            assertEquals(0L, s.giving % ugxUnit)
            assertTrue(s.living >= 0)
        }
    }

    @Test
    fun `custom 60-15-15-10 split`() {
        val s = AllocationCalculator.allocate(ugx(200_000), Percentages(6000, 1500, 1500, 1000), ugxUnit)
        assertEquals(ugx(120_000), s.living)
        assertEquals(ugx(30_000), s.savings)
        assertEquals(ugx(30_000), s.investments)
        assertEquals(ugx(20_000), s.giving)
    }

    @Test
    fun `two-decimal currency allocates to the cent`() {
        // USD 10.05 -> savings 10% = 1.005 -> 1.00, living gets 7.05
        val s = AllocationCalculator.allocate(1_005, Percentages.DEFAULT, Money.allocationUnit(2))
        assertEquals(100L, s.savings)
        assertEquals(705L, s.living)
        assertEquals(1_005L, s.total)
    }

    @Test(expected = IllegalArgumentException::class)
    fun `invalid percentages are rejected`() {
        AllocationCalculator.allocate(ugx(100), Percentages(7000, 1000, 1000, 500), ugxUnit)
    }

    @Test(expected = IllegalArgumentException::class)
    fun `negative amount is rejected`() {
        AllocationCalculator.allocate(-1, Percentages.DEFAULT, ugxUnit)
    }

    @Test
    fun `percentages validation`() {
        assertTrue(Percentages.DEFAULT.isValid)
        assertTrue(Percentages(6000, 1500, 1500, 1000).isValid)
        assertTrue(!Percentages(7000, 1000, 1000, 1001).isValid)
        assertTrue(!Percentages(11000, -1000, 0, 0).isValid)
    }
}
