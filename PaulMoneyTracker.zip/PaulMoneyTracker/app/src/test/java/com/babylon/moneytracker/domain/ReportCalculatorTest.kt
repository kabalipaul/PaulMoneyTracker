package com.babylon.moneytracker.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test
import java.time.LocalDate
import java.time.YearMonth

class ReportCalculatorTest {

    private val unit = Money.allocationUnit(0)
    private fun ugx(units: Long) = units * Money.SCALE
    private var id = 1L
    private fun income(units: Long, date: LocalDate, source: String = "Salary") =
        IncomeRecord(id++, ugx(units), date, source, null, Percentages.DEFAULT,
            AllocationCalculator.allocate(ugx(units), Percentages.DEFAULT, unit))

    private fun expense(units: Long, date: LocalDate, cat: String) =
        LedgerRecord(id++, AccountType.LIVING, TxType.EXPENSE, ugx(units), date, cat, expenseCategory = cat)

    @Test
    fun `custom range report uses only records inside the range`() {
        val incomes = listOf(
            income(100_000, LocalDate.of(2026, 10, 31)),
            income(200_000, LocalDate.of(2026, 11, 1), "Business"),
            income(50_000, LocalDate.of(2026, 11, 1)),
            income(300_000, LocalDate.of(2026, 11, 5)),
            income(999_000, LocalDate.of(2026, 11, 20)),
        )
        val ledger = listOf(
            expense(40_000, LocalDate.of(2026, 11, 2), "Food"),
            expense(60_000, LocalDate.of(2026, 11, 3), "Rent"),
            expense(10_000, LocalDate.of(2026, 11, 4), "Food"),
        )
        val r = ReportCalculator.build(incomes, ledger, DateRange(LocalDate.of(2026, 11, 1), LocalDate.of(2026, 11, 10)))

        assertEquals(ugx(550_000), r.income.total)
        assertEquals(3, r.income.count)
        assertEquals(ugx(550_000) / 3, r.income.averagePerTransaction)
        assertEquals(LocalDate.of(2026, 11, 5), r.income.highestDay!!.date)
        assertEquals(LocalDate.of(2026, 11, 1), r.income.lowestDay!!.date)
        assertEquals(ugx(250_000), r.income.lowestDay!!.amount)
        assertEquals("Salary", r.income.bySource.first().name)
        assertEquals(10, r.income.trend.size)

        assertEquals(ugx(385_000), r.allocation.split.living)
        assertEquals(ugx(110_000), r.expenditure.total)
        assertEquals("Rent", r.expenditure.byCategory.first().name)
        assertEquals(ugx(385_000 - 110_000), r.expenditure.remainingInPeriod)
        // Balance at end includes the 31 Oct income (70,000 to living).
        assertEquals(ugx(70_000 + 385_000 - 110_000), r.expenditure.livingBalanceAtEnd)

        assertEquals(ugx(55_000), r.savings.contributions)
        assertEquals(ugx(65_000), r.savings.balanceAtEnd)
    }

    @Test
    fun `empty range produces zeroes not sample data`() {
        val r = ReportCalculator.build(emptyList(), emptyList(), DateRange(LocalDate.of(2026, 1, 1), LocalDate.of(2026, 1, 31)))
        assertEquals(0L, r.income.total)
        assertNull(r.income.highestDay)
        assertEquals(0L, r.expenditure.total)
        assertEquals(0L, r.overall.wealthAtEnd)
    }

    @Test
    fun `period ranges`() {
        val today = LocalDate.of(2026, 11, 4) // Wednesday
        assertEquals(DateRange(LocalDate.of(2026, 11, 2), LocalDate.of(2026, 11, 8)), ReportPeriod.THIS_WEEK.range(today))
        assertEquals(DateRange(LocalDate.of(2026, 10, 26), LocalDate.of(2026, 11, 1)), ReportPeriod.LAST_WEEK.range(today))
        assertEquals(DateRange(LocalDate.of(2026, 10, 1), LocalDate.of(2026, 10, 31)), ReportPeriod.LAST_MONTH.range(today))
        assertEquals(DateRange(LocalDate.of(2025, 1, 1), LocalDate.of(2025, 12, 31)), ReportPeriod.LAST_YEAR.range(today))
        assertEquals(DateRange(LocalDate.of(2026, 8, 5), today), ReportPeriod.LAST_3_MONTHS.range(today))
        assertNull(ReportPeriod.CUSTOM.range(today))
    }

    @Test
    fun `bucket sizes adapt to range length`() {
        val start = LocalDate.of(2026, 1, 1)
        assertEquals(31, ReportCalculator.buckets(DateRange(start, LocalDate.of(2026, 1, 31))).size)
        assertEquals(12, ReportCalculator.buckets(DateRange(start, LocalDate.of(2026, 12, 31))).size)
    }

    @Test
    fun `month summary for calendar`() {
        val incomes = listOf(
            income(100_000, LocalDate.of(2026, 11, 1)),
            income(50_000, LocalDate.of(2026, 11, 1)),
            income(30_000, LocalDate.of(2026, 11, 9)),
            income(70_000, LocalDate.of(2026, 12, 1)),
        )
        val m = ReportCalculator.monthSummary(incomes, YearMonth.of(2026, 11))
        assertEquals(ugx(180_000), m.total)
        assertEquals(2, m.daysWithIncome)
        assertEquals(ugx(90_000), m.averagePerIncomeDay)
        assertEquals(ugx(150_000), m.dailyTotals[LocalDate.of(2026, 11, 1)])
        assertEquals(ugx(18_000), m.split.savings)
    }
}
