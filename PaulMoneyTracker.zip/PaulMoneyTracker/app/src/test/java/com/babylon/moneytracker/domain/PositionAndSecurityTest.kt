package com.babylon.moneytracker.domain

import com.babylon.moneytracker.security.BackupCrypto
import com.babylon.moneytracker.security.PinHasher
import com.babylon.moneytracker.security.WrongPasswordException
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import java.time.LocalDate

class PositionAndSecurityTest {

    private val unit = Money.allocationUnit(0)
    private fun ugx(units: Long) = units * Money.SCALE
    private val d0 = LocalDate.of(2026, 1, 1)

    private fun income(units: Long, date: LocalDate) = IncomeRecord(
        date.toEpochDay(), ugx(units), date, "Salary", null, Percentages.DEFAULT,
        AllocationCalculator.allocate(ugx(units), Percentages.DEFAULT, unit),
    )

    @Test
    fun `financial position balances assets and liabilities`() {
        val incomes = listOf(income(1_000_000, d0))
        val ledger = listOf(
            LedgerRecord(1, AccountType.SAVINGS, TxType.LOAN_RECEIVED, ugx(500_000), d0, "Loan"),
            LedgerRecord(2, AccountType.LIVING, TxType.LOAN_GIVEN, ugx(200_000), d0, "Lent"),
            LedgerRecord(3, AccountType.INVESTMENTS, TxType.INVESTMENT_CONTRIBUTION, ugx(80_000), d0, "T-bill",
                currentValue = ugx(90_000)),
            LedgerRecord(4, AccountType.LIVING, TxType.EXPENSE, ugx(100_000), d0, "Food"),
        )
        fun loan(id: Long, dir: LoanDirection, units: Long) = LoanRecord(
            id, dir, "X", ugx(units), d0, null, AccountType.SAVINGS, 0, InterestPeriod.NONE,
            RepaymentOrder.INTEREST_FIRST, null, null, null, id, emptyList(),
        )
        val loans = listOf(loan(1, LoanDirection.BORROWED, 500_000), loan(2, LoanDirection.LENT, 200_000))
        val p = PositionCalculator.snapshot(incomes, ledger, loans, d0, unit)

        // Cash: living 700k-200k-100k=400k, savings 100k+500k=600k, investments 100k-80k=20k, giving 100k
        assertEquals(ugx(1_120_000), p.totalCash)
        assertEquals(ugx(90_000), p.investmentsHeld)
        assertEquals(ugx(200_000), p.receivables)
        assertEquals(ugx(1_410_000), p.totalAssets)
        assertEquals(ugx(500_000), p.liabilities)
        // Net worth = income kept (1,000,000) - spent (100,000) + investment gain (10,000)
        assertEquals(ugx(910_000), p.netWorth)
    }

    @Test
    fun `position before the first record is empty`() {
        val p = PositionCalculator.report(
            listOf(income(1_000_000, d0.plusDays(5))), emptyList(), emptyList(),
            DateRange(d0, d0.plusDays(9)), unit,
        )
        assertEquals(0L, p.start.netWorth)
        assertEquals(ugx(1_000_000), p.end.netWorth)
        assertEquals(ugx(1_000_000), p.netWorthChange)
        assertEquals(10, p.netWorthTrend.size)
    }

    @Test
    fun `encrypted backup round trip`() {
        val data = "SQLite format 3\u0000 some database bytes".toByteArray()
        val enc = BackupCrypto.encrypt(data, "secret123".toCharArray(), iterations = 20_000)
        assertTrue(BackupCrypto.isEncrypted(enc))
        assertTrue(!enc.toString(Charsets.ISO_8859_1).contains("SQLite"))
        val dec = BackupCrypto.decrypt(enc, "secret123".toCharArray())
        assertTrue(dec.contentEquals(data))
    }

    @Test(expected = WrongPasswordException::class)
    fun `wrong backup password is rejected`() {
        val enc = BackupCrypto.encrypt("hello".toByteArray(), "secret123".toCharArray(), iterations = 20_000)
        BackupCrypto.decrypt(enc, "secret124".toCharArray())
    }

    @Test(expected = WrongPasswordException::class)
    fun `tampered backup is rejected`() {
        val enc = BackupCrypto.encrypt("hello world".toByteArray(), "secret123".toCharArray(), iterations = 20_000)
        enc[enc.size - 20] = (enc[enc.size - 20].toInt() xor 1).toByte()
        BackupCrypto.decrypt(enc, "secret123".toCharArray())
    }

    @Test
    fun `plain database is not mistaken for an encrypted backup`() {
        assertTrue(!BackupCrypto.isEncrypted("SQLite format 3\u0000".toByteArray()))
    }

    @Test
    fun `pin hashing`() {
        val salt = PinHasher.newSalt()
        val h = PinHasher.hash("2580", salt, 10_000)
        assertTrue(PinHasher.matches("2580", salt, h, 10_000))
        assertTrue(!PinHasher.matches("2581", salt, h, 10_000))
        assertTrue(PinHasher.isValidPin("1234"))
        assertTrue(PinHasher.isValidPin("123456"))
        assertTrue(!PinHasher.isValidPin("123"))
        assertTrue(!PinHasher.isValidPin("12a4"))
    }
}
