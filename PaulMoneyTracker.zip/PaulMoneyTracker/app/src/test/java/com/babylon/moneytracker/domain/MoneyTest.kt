package com.babylon.moneytracker.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class MoneyTest {

    @Test
    fun `formats UGX with thousands separators`() {
        assertEquals("UGX 1,500,000", Money.format(150_000_000, "UGX", 0))
        assertEquals("UGX 0", Money.format(0, "UGX", 0))
        assertEquals("-UGX 5,000", Money.format(-500_000, "UGX", 0))
        assertEquals("$ 12.50", Money.format(1_250, "$", 2))
    }

    @Test
    fun `parses valid amounts`() {
        assertEquals(ParseResult.Ok(150_000_000), Money.parse("1,500,000", 0))
        assertEquals(ParseResult.Ok(10_000_000), Money.parse(" 100000 ", 0))
        assertEquals(ParseResult.Ok(1_250), Money.parse("12.5", 2))
        assertEquals(ParseResult.Ok(10_000), Money.parse("100.00", 0))
    }

    @Test
    fun `rejects invalid amounts`() {
        assertTrue(Money.parse("", 0) is ParseResult.Error)
        assertTrue(Money.parse("-500", 0) is ParseResult.Error)
        assertTrue(Money.parse("0", 0) is ParseResult.Error)
        assertTrue(Money.parse("abc", 0) is ParseResult.Error)
        assertTrue(Money.parse("100.5", 0) is ParseResult.Error)
        assertTrue(Money.parse("1.234", 2) is ParseResult.Error)
    }

    @Test
    fun `compact format`() {
        assertEquals("70K", Money.compact(7_000_000))
        assertEquals("1.5M", Money.compact(150_000_000))
        assertEquals("950", Money.compact(95_000))
    }

    @Test
    fun `percent parsing`() {
        assertEquals(7000, Money.parsePercent("70"))
        assertEquals(1250, Money.parsePercent("12.5"))
        assertEquals(null, Money.parsePercent("101"))
        assertEquals(null, Money.parsePercent("abc"))
        assertEquals("12.5", Money.formatPercent(1250))
        assertEquals("70", Money.formatPercent(7000))
    }
}
