package com.babylon.moneytracker.domain

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.time.temporal.TemporalAdjusters
import java.util.Locale

data class DateRange(val start: LocalDate, val end: LocalDate) {
    init {
        require(!end.isBefore(start)) { "End date must not be before start date" }
    }

    operator fun contains(date: LocalDate): Boolean = !date.isBefore(start) && !date.isAfter(end)

    val dayCount: Long get() = ChronoUnit.DAYS.between(start, end) + 1

    fun label(): String {
        val f = DateTimeFormatter.ofPattern("d MMM yyyy", Locale.US)
        return if (start == end) start.format(f) else "${start.format(f)} – ${end.format(f)}"
    }
}

enum class ReportPeriod(val label: String) {
    TODAY("Today"),
    YESTERDAY("Yesterday"),
    THIS_WEEK("This week"),
    LAST_WEEK("Last week"),
    THIS_MONTH("This month"),
    LAST_MONTH("Last month"),
    LAST_3_MONTHS("Last 3 months"),
    LAST_6_MONTHS("Last 6 months"),
    THIS_YEAR("This year"),
    LAST_YEAR("Last year"),
    CUSTOM("Custom range");

    /**
     * Resolves the period relative to [today]. Weeks run Monday–Sunday.
     * "Last 3/6 months" are rolling windows ending today.
     * Returns null for [CUSTOM], whose dates the user picks.
     */
    fun range(today: LocalDate, weekStart: DayOfWeek = DayOfWeek.MONDAY): DateRange? {
        val weekStartDate = today.with(TemporalAdjusters.previousOrSame(weekStart))
        return when (this) {
            TODAY -> DateRange(today, today)
            YESTERDAY -> today.minusDays(1).let { DateRange(it, it) }
            THIS_WEEK -> DateRange(weekStartDate, weekStartDate.plusDays(6))
            LAST_WEEK -> DateRange(weekStartDate.minusWeeks(1), weekStartDate.minusDays(1))
            THIS_MONTH -> DateRange(today.withDayOfMonth(1), today.with(TemporalAdjusters.lastDayOfMonth()))
            LAST_MONTH -> today.minusMonths(1).let {
                DateRange(it.withDayOfMonth(1), it.with(TemporalAdjusters.lastDayOfMonth()))
            }
            LAST_3_MONTHS -> DateRange(today.minusMonths(3).plusDays(1), today)
            LAST_6_MONTHS -> DateRange(today.minusMonths(6).plusDays(1), today)
            THIS_YEAR -> DateRange(today.withDayOfYear(1), today.with(TemporalAdjusters.lastDayOfYear()))
            LAST_YEAR -> today.minusYears(1).let {
                DateRange(it.withDayOfYear(1), it.with(TemporalAdjusters.lastDayOfYear()))
            }
            CUSTOM -> null
        }
    }
}
