package com.babylon.moneytracker.domain

import java.math.BigDecimal
import java.math.RoundingMode
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

sealed interface ParseResult {
    data class Ok(val minor: Long) : ParseResult
    data class Error(val message: String) : ParseResult
}

object Money {
    /** Stored minor units per whole currency unit. Fixed for every currency. */
    const val SCALE = 100L

    /** Largest single amount accepted: 1 trillion currency units. */
    private val MAX_UNITS = BigDecimal("1000000000000")

    /**
     * Smallest amount an envelope may receive, in minor units.
     * For UGX (0 decimals) allocations are whole shillings; for 2-decimal currencies, cents.
     */
    fun allocationUnit(decimals: Int): Long = when (decimals.coerceIn(0, 2)) {
        0 -> 100L
        1 -> 10L
        else -> 1L
    }

    fun parse(input: String, decimals: Int): ParseResult {
        val cleaned = input.trim().replace(",", "").replace(" ", "")
        if (cleaned.isEmpty()) return ParseResult.Error("Enter an amount")
        if (!Regex("""^\d+(\.\d+)?$""").matches(cleaned)) {
            return ParseResult.Error(if (cleaned.startsWith("-")) "Amount cannot be negative" else "Enter a valid number")
        }
        val value = BigDecimal(cleaned).stripTrailingZeros().let { if (it.scale() < 0) it.setScale(0) else it }
        val maxDecimals = decimals.coerceIn(0, 2)
        if (value.scale() > maxDecimals) {
            return ParseResult.Error(
                if (maxDecimals == 0) "Enter a whole amount (no decimals)"
                else "Use at most $maxDecimals decimal places"
            )
        }
        if (value.signum() <= 0) return ParseResult.Error("Amount must be greater than zero")
        if (value > MAX_UNITS) return ParseResult.Error("Amount is too large")
        return ParseResult.Ok(value.movePointRight(2).longValueExact())
    }

    /** Plain number for pre-filling an edit field, e.g. 150000000 -> "1500000". */
    fun toInput(minor: Long, decimals: Int): String =
        BigDecimal.valueOf(minor, 2).setScale(decimals.coerceIn(0, 2), RoundingMode.HALF_UP).toPlainString()

    fun format(minor: Long, symbol: String, decimals: Int): String {
        val d = decimals.coerceIn(0, 2)
        val pattern = if (d == 0) "#,##0" else "#,##0." + "0".repeat(d)
        val fmt = DecimalFormat(pattern, DecimalFormatSymbols(Locale.US))
        val value = BigDecimal.valueOf(minor, 2).setScale(d, RoundingMode.HALF_UP)
        val body = fmt.format(value.abs())
        val sign = if (value.signum() < 0) "-" else ""
        return if (symbol.isBlank()) "$sign$body" else "$sign$symbol $body"
    }

    /** Short form for tight spaces such as calendar cells: 70K, 1.5M, 2.3B. */
    fun compact(minor: Long): String {
        val units = BigDecimal.valueOf(minor, 2).abs()
        val sign = if (minor < 0) "-" else ""
        fun fmt(v: BigDecimal, suffix: String): String {
            val r = v.setScale(1, RoundingMode.HALF_UP).stripTrailingZeros()
            return sign + (if (r.scale() < 0) r.setScale(0) else r).toPlainString() + suffix
        }
        return when {
            units >= BigDecimal("1000000000") -> fmt(units.divide(BigDecimal("1000000000")), "B")
            units >= BigDecimal("1000000") -> fmt(units.divide(BigDecimal("1000000")), "M")
            units >= BigDecimal("1000") -> fmt(units.divide(BigDecimal("1000")), "K")
            else -> sign + units.setScale(0, RoundingMode.HALF_UP).toPlainString()
        }
    }

    /** Parse a percentage like "70" or "12.5" into basis points. Null when invalid. */
    fun parsePercent(input: String): Int? {
        val cleaned = input.trim().removeSuffix("%").trim()
        if (!Regex("""^\d{1,3}(\.\d{1,2})?$""").matches(cleaned)) return null
        val bp = BigDecimal(cleaned).movePointRight(2).toInt()
        return if (bp in 0..Percentages.FULL) bp else null
    }

    fun formatPercent(bp: Int): String {
        val v = BigDecimal.valueOf(bp.toLong(), 2).stripTrailingZeros()
        return (if (v.scale() < 0) v.setScale(0) else v).toPlainString()
    }
}
