package com.babylon.moneytracker.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.babylon.moneytracker.data.FinanceRepository
import com.babylon.moneytracker.data.LedgerInput
import com.babylon.moneytracker.data.SettingsRepository
import com.babylon.moneytracker.data.allocationUnit
import com.babylon.moneytracker.data.db.AppSettings
import com.babylon.moneytracker.data.db.ReminderSettings
import com.babylon.moneytracker.data.percentages
import com.babylon.moneytracker.domain.AccountType
import com.babylon.moneytracker.domain.FinancialOverview
import com.babylon.moneytracker.domain.Goal
import com.babylon.moneytracker.domain.GoalMetric
import com.babylon.moneytracker.domain.GoalProgress
import com.babylon.moneytracker.domain.IncomeRecord
import com.babylon.moneytracker.domain.IncomeTotals
import com.babylon.moneytracker.domain.LedgerCalculator
import com.babylon.moneytracker.domain.LedgerRecord
import com.babylon.moneytracker.domain.Money
import com.babylon.moneytracker.domain.ParseResult
import com.babylon.moneytracker.domain.TxType
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

data class AppState(
    val loaded: Boolean,
    val today: LocalDate,
    val settings: AppSettings,
    val reminder: ReminderSettings,
    val names: Map<AccountType, String>,
    val incomes: List<IncomeRecord>,
    val ledger: List<LedgerRecord>,
    val goals: List<GoalProgress>,
    val overview: FinancialOverview,
    val totals: IncomeTotals,
) {
    fun name(t: AccountType): String = names[t] ?: t.defaultName

    companion object {
        fun empty(): AppState = AppState(
            loaded = false,
            today = LocalDate.now(),
            settings = AppSettings(),
            reminder = ReminderSettings(),
            names = AccountType.entries.associateWith { it.defaultName },
            incomes = emptyList(),
            ledger = emptyList(),
            goals = emptyList(),
            overview = LedgerCalculator.overview(emptyList(), emptyList()),
            totals = IncomeTotals(0, 0, 0, 0),
        )
    }
}

/**
 * App-wide state shared by Home, Calendar, Accounts and Goals, plus every
 * write action. Each action reports back with an error message, or null on success.
 */
class MainViewModel(
    private val finance: FinanceRepository,
    private val settingsRepo: SettingsRepository,
) : ViewModel() {

    /** Ticks so "today" rolls over at midnight and follows time-zone changes. */
    private val todayFlow = flow {
        while (true) {
            emit(LocalDate.now()); delay(30_000)
        }
    }.distinctUntilChanged()

    private data class Data(
        val incomes: List<IncomeRecord>,
        val ledger: List<LedgerRecord>,
        val goals: List<Goal>,
        val names: Map<AccountType, String>,
    )

    private val data = combine(finance.incomes, finance.ledger, finance.goals, finance.accountNames) { i, l, g, n ->
        Data(i, l, g, n)
    }

    val state: StateFlow<AppState> = combine(data, settingsRepo.settings, settingsRepo.reminder, todayFlow) { d, s, r, today ->
        val overview = LedgerCalculator.overview(d.incomes, d.ledger)
        AppState(
            loaded = true,
            today = today,
            settings = s,
            reminder = r,
            names = d.names,
            incomes = d.incomes,
            ledger = d.ledger,
            goals = d.goals.map { LedgerCalculator.goalProgress(it, overview) },
            overview = overview,
            totals = LedgerCalculator.incomeTotals(d.incomes, today),
        )
    }.flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.Eagerly, AppState.empty())

    private fun launchAction(onResult: (String?) -> Unit, block: suspend () -> Unit) {
        viewModelScope.launch {
            val error = try {
                block(); null
            } catch (e: CancellationException) {
                throw e
            } catch (e: IllegalArgumentException) {
                e.message ?: "Please check the details"
            } catch (e: Exception) {
                e.message ?: "Something went wrong"
            }
            onResult(error)
        }
    }

    private fun parseAmount(text: String): Long {
        return when (val r = Money.parse(text, state.value.settings.currencyDecimals)) {
            is ParseResult.Ok -> r.minor
            is ParseResult.Error -> throw IllegalArgumentException(r.message)
        }
    }

    private fun parseOptionalAmount(text: String): Long? =
        if (text.isBlank()) null else parseAmount(text)

    // ---------------- Income ----------------

    fun saveIncome(
        id: Long?, amountText: String, date: LocalDate, source: String, description: String,
        onResult: (String?) -> Unit,
    ) = launchAction(onResult) {
        val amount = parseAmount(amountText)
        require(source.isNotBlank()) { "Choose a source of income" }
        val s = settingsRepo.current()
        if (id == null) {
            finance.addIncome(amount, date, source, description, s.percentages(), s.allocationUnit())
        } else {
            finance.updateIncome(id, amount, date, source, description, s.allocationUnit())
        }
    }

    fun deleteIncome(id: Long, onResult: (String?) -> Unit) = launchAction(onResult) { finance.deleteIncome(id) }

    // ---------------- Envelope transactions ----------------

    fun saveLedger(
        id: Long?,
        account: AccountType,
        type: TxType,
        amountText: String,
        date: LocalDate,
        description: String,
        notes: String,
        category: String?,
        investmentType: String?,
        currentValueText: String,
        onResult: (String?) -> Unit,
    ) = launchAction(onResult) {
        val input = LedgerInput(
            account = account,
            type = type,
            amount = parseAmount(amountText),
            date = date,
            description = description.ifBlank { category ?: investmentType ?: type.label },
            notes = notes,
            expenseCategory = category,
            investmentType = investmentType,
            currentValue = if (type == TxType.INVESTMENT_CONTRIBUTION) parseOptionalAmount(currentValueText) else null,
        )
        if (id == null) finance.addLedger(input) else finance.updateLedger(id, input)
    }

    fun deleteLedger(id: Long, onResult: (String?) -> Unit) = launchAction(onResult) { finance.deleteLedger(id) }

    fun saveTransfer(
        ref: String?, from: AccountType, to: AccountType, amountText: String, date: LocalDate, description: String,
        onResult: (String?) -> Unit,
    ) = launchAction(onResult) {
        val amount = parseAmount(amountText)
        if (ref == null) finance.transfer(from, to, amount, date, description)
        else finance.updateTransfer(ref, amount, date, description)
    }

    suspend fun transferLegs(ref: String) = finance.transferLegs(ref)

    // ---------------- Accounts, goals, savings target ----------------

    fun renameAccount(type: AccountType, name: String, onResult: (String?) -> Unit) =
        launchAction(onResult) { finance.renameAccount(type, name) }

    fun setSavingsTarget(text: String, onResult: (String?) -> Unit) = launchAction(onResult) {
        settingsRepo.setSavingsTarget(parseOptionalAmount(text))
    }

    fun saveGoal(
        id: Long?, name: String, targetText: String, targetDate: LocalDate?, metric: GoalMetric, manualText: String,
        onResult: (String?) -> Unit,
    ) = launchAction(onResult) {
        val manual = if (metric == GoalMetric.MANUAL) parseOptionalAmount(manualText) ?: 0L else 0L
        finance.saveGoal(id, name, parseAmount(targetText), targetDate, metric, manual)
    }

    fun deleteGoal(id: Long, onResult: (String?) -> Unit) = launchAction(onResult) { finance.deleteGoal(id) }
}
