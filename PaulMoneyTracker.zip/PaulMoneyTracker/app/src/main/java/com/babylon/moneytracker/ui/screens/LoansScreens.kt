package com.babylon.moneytracker.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.babylon.moneytracker.domain.AccountType
import com.babylon.moneytracker.domain.InterestPeriod
import com.babylon.moneytracker.domain.LOAN_ACCOUNTS
import com.babylon.moneytracker.domain.LedgerCalculator
import com.babylon.moneytracker.domain.LoanCalculator
import com.babylon.moneytracker.domain.LoanDirection
import com.babylon.moneytracker.domain.LoanState
import com.babylon.moneytracker.domain.LoanStatus
import com.babylon.moneytracker.domain.Money
import com.babylon.moneytracker.domain.ParseResult
import com.babylon.moneytracker.domain.RepaymentOrder
import com.babylon.moneytracker.ui.AppState
import com.babylon.moneytracker.ui.MainViewModel
import com.babylon.moneytracker.ui.Routes
import com.babylon.moneytracker.ui.components.AmountField
import com.babylon.moneytracker.ui.components.ChipRow
import com.babylon.moneytracker.ui.components.ConfirmDialog
import com.babylon.moneytracker.ui.components.DateField
import com.babylon.moneytracker.ui.components.DateShort
import com.babylon.moneytracker.ui.components.EmptyNote
import com.babylon.moneytracker.ui.components.LabelValue
import com.babylon.moneytracker.ui.components.LocalMoney
import com.babylon.moneytracker.ui.components.ScreenTopBar
import com.babylon.moneytracker.ui.components.SectionCard
import com.babylon.moneytracker.ui.components.SelectField
import com.babylon.moneytracker.ui.components.TxRow
import com.babylon.moneytracker.ui.theme.Palette
import java.time.LocalDate

/** Orange for money I owe, green for money owed to me, grey once settled. */
@Composable
fun loanColor(direction: LoanDirection, settled: Boolean = false): Color = when {
    settled -> MaterialTheme.colorScheme.onSurfaceVariant
    direction == LoanDirection.BORROWED -> Palette.Orange
    else -> MaterialTheme.colorScheme.primary
}

@Composable
private fun StatusChip(status: LoanStatus, direction: LoanDirection) {
    val (bg, fg) = when (status) {
        LoanStatus.OVERDUE -> MaterialTheme.colorScheme.error to Color.White
        LoanStatus.SETTLED -> MaterialTheme.colorScheme.surfaceVariant to MaterialTheme.colorScheme.onSurfaceVariant
        LoanStatus.PARTIAL -> Palette.Gold.copy(alpha = 0.25f) to MaterialTheme.colorScheme.onSurface
        LoanStatus.ACTIVE -> loanColor(direction).copy(alpha = 0.15f) to loanColor(direction)
    }
    Box(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(bg)
            .padding(horizontal = 10.dp, vertical = 3.dp)
    ) {
        Text(status.label(direction), color = fg, style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun SummaryTile(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
        shape = RoundedCornerShape(16.dp),
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(4.dp).height(34.dp).clip(RoundedCornerShape(2.dp)).background(color))
            Spacer(Modifier.width(10.dp))
            Column {
                Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(value, style = MaterialTheme.typography.titleMedium, color = color, maxLines = 1)
            }
        }
    }
}

// =====================================================================
// Loans home
// =====================================================================

@Composable
fun LoansScreen(state: AppState, nav: NavController) {
    val fmt = LocalMoney.current
    val t = state.loanTotals
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var filterName by rememberSaveable { mutableStateOf("ALL") }
    val direction = if (tab == 0) LoanDirection.BORROWED else LoanDirection.LENT

    val list = state.loans
        .filter { it.loan.direction == direction }
        .filter { filterName == "ALL" || it.status.name == filterName }
        .sortedWith(
            compareBy<LoanState> {
                when (it.status) {
                    LoanStatus.OVERDUE -> 0
                    LoanStatus.PARTIAL -> 1
                    LoanStatus.ACTIVE -> 2
                    LoanStatus.SETTLED -> 3
                }
            }.thenBy { it.loan.dueDate ?: LocalDate.MAX }
        )

    Column(Modifier.fillMaxSize()) {
        ScreenTopBar("Loans")
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SummaryTile("I owe (outstanding)", fmt(t.owed), Palette.Orange, Modifier.weight(1f))
                SummaryTile("Owed to me", fmt(t.receivable), MaterialTheme.colorScheme.primary, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                SummaryTile("Repayments made", fmt(t.repaymentsMade), MaterialTheme.colorScheme.onSurfaceVariant, Modifier.weight(1f))
                SummaryTile("Repayments received", fmt(t.repaymentsReceived), MaterialTheme.colorScheme.onSurfaceVariant, Modifier.weight(1f))
            }
            SectionCard {
                Text("Net loan position", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                    (if (t.net > 0) "+" else "") + fmt(t.net),
                    style = MaterialTheme.typography.headlineSmall,
                    color = if (t.net >= 0) MaterialTheme.colorScheme.primary else Palette.Orange,
                )
                Text(
                    "Money owed to you minus money you owe." +
                        if (t.interestReceived > 0) " Interest earned so far: ${fmt(t.interestReceived)}." else "",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            val overdue = t.overdueOwed + t.overdueReceivable
            if (overdue > 0) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                        Spacer(Modifier.width(10.dp))
                        Text(
                            listOfNotNull(
                                if (t.overdueOwed > 0) "${t.overdueOwed} loan(s) you owe are overdue" else null,
                                if (t.overdueReceivable > 0) "${t.overdueReceivable} debtor(s) are overdue" else null,
                            ).joinToString(" · "),
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            style = MaterialTheme.typography.bodyMedium,
                        )
                    }
                }
            }

            TabRow(selectedTabIndex = tab, containerColor = MaterialTheme.colorScheme.background) {
                Tab(selected = tab == 0, onClick = { tab = 0; filterName = "ALL" }, text = { Text("Money I Owe") })
                Tab(selected = tab == 1, onClick = { tab = 1; filterName = "ALL" }, text = { Text("Money Owed to Me") })
            }

            ChipRow(
                listOf("ALL") + LoanStatus.entries.map { it.name },
                filterName,
                { if (it == "ALL") "All" else LoanStatus.valueOf(it).label(direction) },
                { filterName = it },
            )

            Button(
                onClick = { nav.navigate(Routes.loanForm(direction)) },
                modifier = Modifier.fillMaxWidth().height(50.dp),
            ) {
                Icon(Icons.Filled.Add, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text(if (direction == LoanDirection.BORROWED) "Add Loan" else "Add Debtor")
            }

            if (list.isEmpty()) {
                EmptyNote(
                    if (direction == LoanDirection.BORROWED) "No loans here. Record money you borrow so you always know what you owe."
                    else "No debtors here. Record money you lend so nothing is forgotten."
                )
            }
            list.forEach { s -> LoanCard(s) { nav.navigate(Routes.loan(s.loan.id)) } }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun LoanCard(s: LoanState, onClick: () -> Unit) {
    val fmt = LocalMoney.current
    val settled = s.status == LoanStatus.SETTLED
    SectionCard(onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(s.loan.counterparty, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f), maxLines = 1)
            StatusChip(s.status, s.loan.direction)
        }
        Spacer(Modifier.height(8.dp))
        Row {
            Column(Modifier.weight(1f)) {
                Text("Original", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(fmt(s.loan.principal), style = MaterialTheme.typography.bodyLarge)
            }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                Text("Outstanding", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                    fmt(s.totalOutstanding),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = loanColor(s.loan.direction, settled),
                )
            }
        }
        val due = s.loan.dueDate
        if (due != null && !settled) {
            Spacer(Modifier.height(4.dp))
            Text(
                (if (s.isOverdue) "Was due " else "Due ") + due.format(DateShort),
                style = MaterialTheme.typography.bodySmall,
                color = if (s.isOverdue) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

// =====================================================================
// Add / edit loan
// =====================================================================

@Composable
fun LoanFormScreen(state: AppState, vm: MainViewModel, nav: NavController, direction: LoanDirection, id: Long?) {
    val context = LocalContext.current
    val fmt = LocalMoney.current
    val decimals = state.settings.currencyDecimals
    val existing = id?.let { state.loan(it)?.loan }
    val dir = existing?.direction ?: direction
    val borrowed = dir == LoanDirection.BORROWED
    val accounts = AccountType.entries.filter { it in LOAN_ACCOUNTS }

    var loaded by rememberSaveable { mutableStateOf(id == null) }
    var name by rememberSaveable { mutableStateOf("") }
    var principal by rememberSaveable { mutableStateOf("") }
    var dateText by rememberSaveable { mutableStateOf(state.today.toString()) }
    var dueText by rememberSaveable { mutableStateOf("") }
    var accountName by rememberSaveable { mutableStateOf((if (borrowed) AccountType.SAVINGS else AccountType.LIVING).name) }
    var periodName by rememberSaveable { mutableStateOf(InterestPeriod.NONE.name) }
    var rate by rememberSaveable { mutableStateOf("") }
    var orderName by rememberSaveable { mutableStateOf(RepaymentOrder.INTEREST_FIRST.name) }
    var purpose by rememberSaveable { mutableStateOf("") }
    var contact by rememberSaveable { mutableStateOf("") }
    var notes by rememberSaveable { mutableStateOf("") }
    var saving by rememberSaveable { mutableStateOf(false) }
    var confirmDelete by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(existing?.id) {
        if (!loaded && existing != null) {
            name = existing.counterparty
            principal = Money.toInput(existing.principal, decimals)
            dateText = existing.date.toString()
            dueText = existing.dueDate?.toString() ?: ""
            accountName = existing.account.name
            periodName = existing.interestPeriod.name
            rate = if (existing.interestRateBp > 0) Money.formatPercent(existing.interestRateBp) else ""
            orderName = existing.repaymentOrder.name
            purpose = existing.purpose ?: ""
            contact = existing.contact ?: ""
            notes = existing.notes ?: ""
            loaded = true
        }
    }

    val account = AccountType.valueOf(accountName)
    val period = InterestPeriod.valueOf(periodName)
    val parsed = (Money.parse(principal, decimals) as? ParseResult.Ok)?.minor
    // Balance of the account without this loan's own starting entry, so editing shows the real room available.
    val available = LedgerCalculator.balanceOf(account, state.incomes, state.ledger, excludeLedgerId = existing?.disbursementTxId)
    val tooMuch = !borrowed && parsed != null && parsed > available
    val rateOk = period == InterestPeriod.NONE || rate.isBlank() || Money.parsePercent(rate) != null

    Column(Modifier.fillMaxSize()) {
        ScreenTopBar(
            title = when {
                id != null -> "Edit loan"
                borrowed -> "Add loan (money I owe)"
                else -> "Add debtor (money owed to me)"
            },
            onBack = { nav.popBackStack() },
            actions = {
                if (id != null) {
                    IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, contentDescription = "Delete") }
                }
            },
        )
        Column(
            Modifier
                .fillMaxSize()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                if (borrowed) "Borrowed money is not income: it is not split 70-10-10-10. It goes into the account you choose and is tracked as a debt."
                else "Money you lend leaves the account you choose and is tracked as money owed to you. It is not an expense.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            OutlinedTextField(
                value = name, onValueChange = { name = it.take(60) }, singleLine = true,
                label = { Text(if (borrowed) "Creditor's name (person or institution)" else "Borrower's name") },
                modifier = Modifier.fillMaxWidth(),
            )
            AmountField(principal, { principal = it }, if (borrowed) "Amount borrowed" else "Amount lent", decimals = decimals)
            DateField(if (borrowed) "Date borrowed" else "Date lent", LocalDate.parse(dateText), { dateText = it.toString() })
            DateField(
                "Expected repayment date (optional)",
                dueText.takeIf { it.isNotBlank() }?.let { LocalDate.parse(it) },
                { dueText = it.toString() },
                onClear = { dueText = "" },
            )
            SelectField(
                if (borrowed) "Money received into" else "Money lent from",
                accounts, account, { state.name(it) }, { accountName = it.name },
            )
            Text(
                "Available in ${state.name(account)}: ${fmt(available)}",
                style = MaterialTheme.typography.bodySmall,
                color = if (tooMuch) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (tooMuch) {
                Text(
                    "You can't lend more than this account holds.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                )
            }

            Text("Interest", style = MaterialTheme.typography.labelLarge)
            ChipRow(InterestPeriod.entries, period, { it.label }, { periodName = it.name })
            if (period != InterestPeriod.NONE) {
                OutlinedTextField(
                    value = rate,
                    onValueChange = { v -> rate = v.filter { it.isDigit() || it == '.' }.take(6) },
                    label = { Text(if (period == InterestPeriod.MONTHLY) "Interest rate per month" else "Interest rate per year") },
                    suffix = { Text("%") },
                    singleLine = true,
                    isError = !rateOk,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth(),
                )
                Text("Repayments are applied", style = MaterialTheme.typography.labelLarge)
                ChipRow(RepaymentOrder.entries, RepaymentOrder.valueOf(orderName), { it.label }, { orderName = it.name })
                Text(
                    "Simple interest: principal still owed × rate × time. Interest is never added to the principal, " +
                        "so no interest is charged on interest.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            OutlinedTextField(
                value = purpose, onValueChange = { purpose = it }, singleLine = true,
                label = { Text(if (borrowed) "Loan description or purpose" else "Purpose or reason for lending") },
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = contact, onValueChange = { contact = it }, singleLine = true,
                label = { Text("Contact information (optional)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = notes, onValueChange = { notes = it }, minLines = 2,
                label = { Text("Additional notes") },
                modifier = Modifier.fillMaxWidth(),
            )

            Button(
                onClick = {
                    saving = true
                    vm.saveLoan(
                        id = id,
                        direction = dir,
                        name = name,
                        principalText = principal,
                        date = LocalDate.parse(dateText),
                        dueDate = dueText.takeIf { it.isNotBlank() }?.let { LocalDate.parse(it) },
                        account = account,
                        rateText = rate,
                        period = period,
                        order = RepaymentOrder.valueOf(orderName),
                        purpose = purpose,
                        contact = contact,
                        notes = notes,
                    ) { err ->
                        saving = false
                        if (err != null) Toast.makeText(context, err, Toast.LENGTH_LONG).show()
                        else {
                            Toast.makeText(context, "Saved", Toast.LENGTH_SHORT).show()
                            nav.popBackStack()
                        }
                    }
                },
                enabled = loaded && !saving && parsed != null && name.isNotBlank() && !tooMuch && rateOk,
                modifier = Modifier.fillMaxWidth().height(52.dp),
            ) { Text("Save") }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (confirmDelete && id != null) {
        ConfirmDialog(
            title = "Delete this loan?",
            text = "The loan, all its repayments and their account entries will be removed, and every balance recalculated.",
            confirmLabel = "Delete",
            destructive = true,
            onConfirm = {
                vm.deleteLoan(id) { err ->
                    if (err != null) Toast.makeText(context, err, Toast.LENGTH_LONG).show()
                    else if (!nav.popBackStack(Routes.LOANS, inclusive = false)) nav.popBackStack()
                }
            },
            onDismiss = { confirmDelete = false },
        )
    }
}

// =====================================================================
// Loan details and history
// =====================================================================

@Composable
fun LoanDetailScreen(state: AppState, nav: NavController, id: Long) {
    val s = state.loan(id)
    Column(Modifier.fillMaxSize()) {
        ScreenTopBar(
            title = s?.loan?.counterparty ?: "Loan",
            onBack = { nav.popBackStack() },
            actions = {
                if (s != null) {
                    IconButton(onClick = { nav.navigate(Routes.loanForm(s.loan.direction, s.loan.id)) }) {
                        Icon(Icons.Filled.Edit, contentDescription = "Edit loan")
                    }
                }
            },
        )
        if (s == null) {
            EmptyNote("This loan no longer exists.", Modifier.padding(16.dp))
        } else {
            LoanDetailBody(state, nav, s)
        }
    }
}

@Composable
private fun LoanDetailBody(state: AppState, nav: NavController, s: LoanState) {
    val fmt = LocalMoney.current
    run {
        val l = s.loan
        val borrowed = l.direction == LoanDirection.BORROWED
        val settled = s.status == LoanStatus.SETTLED
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            SectionCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (borrowed) "Money I owe" else "Money owed to me",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(1f),
                    )
                    StatusChip(s.status, l.direction)
                }
                Text(
                    fmt(s.totalOutstanding),
                    style = MaterialTheme.typography.headlineMedium,
                    color = loanColor(l.direction, settled),
                )
                Text("outstanding", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                LabelValue(if (borrowed) "Original loan" else "Original amount lent", fmt(l.principal))
                LabelValue(if (borrowed) "Amount repaid" else "Amount received back", fmt(s.totalPaid))
                if (l.hasInterest) {
                    LabelValue("Principal outstanding", fmt(s.principalOutstanding))
                    LabelValue("Interest accrued to date", fmt(s.interestAccrued))
                    LabelValue("Interest outstanding", fmt(s.interestOutstanding))
                    LabelValue("Total outstanding", fmt(s.totalOutstanding), emphasize = true)
                }
                HorizontalDivider(Modifier.padding(vertical = 6.dp))
                LabelValue(if (borrowed) "Date borrowed" else "Date lent", l.date.format(DateShort))
                LabelValue(
                    "Expected repayment",
                    l.dueDate?.format(DateShort) ?: "Not set",
                    valueColor = if (s.isOverdue) MaterialTheme.colorScheme.error else Color.Unspecified,
                )
                LabelValue(
                    "Interest",
                    if (l.hasInterest) "${Money.formatPercent(l.interestRateBp)}% ${l.interestPeriod.label.lowercase()}, simple · ${l.repaymentOrder.label.lowercase()}"
                    else "No interest",
                )
                LabelValue(if (borrowed) "Received into" else "Lent from", state.name(l.account))
                l.contact?.let { LabelValue("Contact", it) }
                l.purpose?.let { LabelValue("Purpose", it) }
                l.notes?.let { LabelValue("Notes", it) }
            }

            Button(
                onClick = { nav.navigate(Routes.loanPayment(l.id)) },
                enabled = !settled,
                modifier = Modifier.fillMaxWidth().height(50.dp),
            ) { Text(if (borrowed) "Make Repayment" else "Record Repayment Received") }
            OutlinedButton(
                onClick = { nav.navigate(Routes.loanForm(l.direction, l.id)) },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Edit loan details") }

            SectionCard(title = "Transaction history") {
                TxRow(
                    title = if (borrowed) "Borrowed · into ${state.name(l.account)}" else "Lent · from ${state.name(l.account)}",
                    subtitle = "${l.date.format(DateShort)} · balance ${fmt(l.principal)}",
                    amount = fmt(l.principal),
                    amountColor = loanColor(l.direction),
                )
                s.lines.forEach { line ->
                    HorizontalDivider()
                    val split = if (l.hasInterest) " · principal ${fmt(line.principalPart)}, interest ${fmt(line.interestPart)}" else ""
                    TxRow(
                        title = (if (borrowed) "Repaid · from " else "Received · into ") + state.name(line.payment.account),
                        subtitle = "${line.payment.date.format(DateShort)}$split · balance ${fmt(line.balanceAfter)}" +
                            (line.payment.notes?.let { " · $it" } ?: ""),
                        amount = "−" + fmt(line.payment.amount),
                        amountColor = MaterialTheme.colorScheme.onSurface,
                        onClick = { nav.navigate(Routes.loanPayment(l.id, line.payment.id)) },
                    )
                }
                if (s.lines.isEmpty()) EmptyNote("No repayments yet.")
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

// =====================================================================
// Make / receive / edit a repayment
// =====================================================================

@Composable
fun LoanPaymentScreen(state: AppState, vm: MainViewModel, nav: NavController, loanId: Long, txId: Long?) {
    val context = LocalContext.current
    val fmt = LocalMoney.current
    val decimals = state.settings.currencyDecimals
    val s = state.loan(loanId)
    val existing = s?.loan?.payments?.firstOrNull { it.id == txId }
    val accounts = AccountType.entries.filter { it in LOAN_ACCOUNTS }

    var loaded by rememberSaveable { mutableStateOf(txId == null) }
    var amount by rememberSaveable { mutableStateOf("") }
    var dateText by rememberSaveable { mutableStateOf(state.today.toString()) }
    var accountName by rememberSaveable {
        mutableStateOf((s?.loan?.takeIf { it.direction == LoanDirection.LENT }?.account ?: AccountType.GIVING).name)
    }
    var notes by rememberSaveable { mutableStateOf("") }
    var saving by rememberSaveable { mutableStateOf(false) }
    var confirmDelete by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(existing?.id) {
        if (!loaded && existing != null) {
            amount = Money.toInput(existing.amount, decimals)
            dateText = existing.date.toString()
            accountName = existing.account.name
            notes = existing.notes ?: ""
            loaded = true
        }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenTopBar(
            title = when {
                txId != null -> "Edit repayment"
                s?.loan?.direction == LoanDirection.LENT -> "Repayment received"
                else -> "Make repayment"
            },
            onBack = { nav.popBackStack() },
            actions = {
                if (txId != null) {
                    IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, contentDescription = "Delete") }
                }
            },
        )
        if (s == null) {
            EmptyNote("This loan no longer exists.", Modifier.padding(16.dp))
        } else {
        val l = s.loan
        val borrowed = l.direction == LoanDirection.BORROWED
        val date = LocalDate.parse(dateText)
        val account = AccountType.valueOf(accountName)
        val unit = Money.allocationUnit(decimals)
        // What is owed on the chosen date, ignoring the repayment being edited.
        val owedThen = LoanCalculator.compute(l.copy(payments = l.payments.filter { it.id != txId }), date, unit).totalOutstanding
        val available = LedgerCalculator.balanceOf(account, state.incomes, state.ledger, excludeLedgerId = txId)
        val parsed = (Money.parse(amount, decimals) as? ParseResult.Ok)?.minor
        val overOwed = parsed != null && parsed > owedThen
        val overAvailable = borrowed && parsed != null && parsed > available

        Column(
            Modifier
                .fillMaxSize()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            SectionCard {
                LabelValue(if (borrowed) "Creditor" else "Debtor", l.counterparty, emphasize = true)
                LabelValue("Outstanding balance on ${date.format(DateShort)}", fmt(owedThen), valueColor = loanColor(l.direction))
                if (l.hasInterest) {
                    Text(
                        "Includes simple interest up to this date. Repayments go to ${l.repaymentOrder.label.lowercase()}.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            AmountField(amount, { amount = it }, if (borrowed) "Repayment amount" else "Amount received", decimals = decimals)
            TextButton(onClick = { amount = Money.toInput(owedThen, decimals) }) { Text("Use full balance (${fmt(owedThen)})") }
            if (overOwed) {
                Text(
                    "That is more than the outstanding balance.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                )
            }
            DateField(if (borrowed) "Repayment date" else "Date received", date, { dateText = it.toString() })
            SelectField(
                if (borrowed) "Pay from account" else "Receive into account",
                accounts, account, { state.name(it) }, { accountName = it.name },
            )
            Text(
                "Available in ${state.name(account)}: ${fmt(available)}",
                style = MaterialTheme.typography.bodySmall,
                color = if (overAvailable) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (overAvailable) {
                Text(
                    "Not enough money in this account. Choose another account or move money in first.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                )
            }
            OutlinedTextField(
                value = notes, onValueChange = { notes = it }, minLines = 2,
                label = { Text("Description or notes") },
                modifier = Modifier.fillMaxWidth(),
            )
            Button(
                onClick = {
                    saving = true
                    vm.saveLoanPayment(l.id, txId, amount, date, account, notes) { err ->
                        saving = false
                        if (err != null) Toast.makeText(context, err, Toast.LENGTH_LONG).show()
                        else {
                            Toast.makeText(context, "Repayment saved", Toast.LENGTH_SHORT).show()
                            nav.popBackStack()
                        }
                    }
                },
                enabled = loaded && !saving && parsed != null && !overOwed && !overAvailable,
                modifier = Modifier.fillMaxWidth().height(52.dp),
            ) { Text("Save repayment") }
            Spacer(Modifier.height(24.dp))
        }
        }
    }

    if (confirmDelete && txId != null) {
        ConfirmDialog(
            title = "Delete this repayment?",
            text = "Its account entry will be reversed and the loan balance recalculated.",
            confirmLabel = "Delete",
            destructive = true,
            onConfirm = {
                vm.deleteLoanPayment(txId) { err ->
                    if (err != null) Toast.makeText(context, err, Toast.LENGTH_LONG).show() else nav.popBackStack()
                }
            },
            onDismiss = { confirmDelete = false },
        )
    }
}
