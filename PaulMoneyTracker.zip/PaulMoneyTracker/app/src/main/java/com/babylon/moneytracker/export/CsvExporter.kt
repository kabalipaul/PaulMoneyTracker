package com.babylon.moneytracker.export

import com.babylon.moneytracker.domain.AccountType
import com.babylon.moneytracker.domain.DateRange
import com.babylon.moneytracker.domain.FullReport
import com.babylon.moneytracker.domain.IncomeRecord
import com.babylon.moneytracker.domain.LedgerRecord
import com.babylon.moneytracker.domain.Money
import java.io.File
import java.math.BigDecimal

/**
 * Excel-compatible CSV (UTF-8 with BOM, comma-separated, quoted where needed).
 * Amounts are written as plain numbers in currency units so spreadsheets can sum them.
 */
class CsvExporter(
    private val currencyCode: String,
    private val decimals: Int,
    private val accountName: (AccountType) -> String,
) {
    private fun num(minor: Long): String =
        BigDecimal.valueOf(minor, 2).setScale(decimals.coerceIn(0, 2), java.math.RoundingMode.HALF_UP).toPlainString()

    private fun esc(v: String?): String {
        val s = v ?: ""
        return if (s.any { it == ',' || it == '"' || it == '\n' || it == '\r' }) "\"" + s.replace("\"", "\"\"") + "\"" else s
    }

    private fun StringBuilder.line(vararg cells: String?) {
        append(cells.joinToString(",") { esc(it) }).append("\r\n")
    }

    fun writeReport(report: FullReport, incomes: List<IncomeRecord>, ledger: List<LedgerRecord>, file: File) {
        val r = report
        val sb = StringBuilder("﻿")
        sb.line("PaulMoneyTracker report")
        sb.line("Period", r.range.start.toString(), r.range.end.toString())
        sb.line("Currency", currencyCode)
        sb.line()

        val pos = r.position.end
        sb.line("FINANCIAL POSITION", "Amount")
        AccountType.entries.forEach { sb.line("Money in ${accountName(it)}", num(pos.cashIn(it))) }
        sb.line("Investments held (recorded value)", num(pos.investmentsHeld))
        sb.line("Money owed to me", num(pos.receivables))
        sb.line("Total assets", num(pos.totalAssets))
        sb.line("Total liabilities (money I owe)", num(pos.liabilities))
        sb.line("Net worth", num(pos.netWorth))
        sb.line("Net worth at start of period", num(r.position.start.netWorth))
        sb.line("Change in net worth", num(r.position.netWorthChange))
        sb.line()

        sb.line("SUMMARY", "Amount")
        sb.line("Total income", num(r.income.total))
        sb.line("Income transactions", r.income.count.toString())
        sb.line("Average per transaction", num(r.income.averagePerTransaction))
        r.income.highestDay?.let { sb.line("Highest income day", num(it.amount), it.date.toString()) }
        r.income.lowestDay?.let { sb.line("Lowest income day", num(it.amount), it.date.toString()) }
        AccountType.entries.forEach { sb.line("Allocated to ${accountName(it)}", num(r.allocation.split.of(it))) }
        sb.line("Living expenses", num(r.expenditure.total))
        sb.line("Debt repayment / giving", num(r.overall.giving))
        sb.line("Investment contributions", num(r.investment.contributions))
        sb.line("Investment returns", num(r.investment.returns))
        sb.line("Savings contributions", num(r.savings.contributions))
        sb.line("Savings withdrawals", num(r.savings.withdrawals))
        AccountType.entries.forEach { sb.line("Balance at end: ${accountName(it)}", num(r.overall.balancesAtEnd[it] ?: 0)) }
        sb.line()

        sb.line("INCOME BY SOURCE", "Amount")
        r.income.bySource.forEach { sb.line(it.name, num(it.amount)) }
        sb.line()
        sb.line("EXPENSES BY CATEGORY", "Amount")
        r.expenditure.byCategory.forEach { sb.line(it.name, num(it.amount)) }
        sb.line()
        sb.line("INVESTMENTS BY TYPE", "Amount")
        r.investment.byType.forEach { sb.line(it.name, num(it.amount)) }
        sb.line()

        val lr = r.loans
        sb.line("LOANS", "Amount")
        sb.line("Outstanding debts (I owe)", num(lr.borrowing.outstandingAtEnd))
        sb.line("Outstanding receivables (owed to me)", num(lr.lending.outstandingAtEnd))
        sb.line("Net loan position", num(lr.netPositionAtEnd))
        sb.line("Money borrowed in period", num(lr.borrowing.newPrincipal))
        sb.line("Repayments made in period", num(lr.borrowing.repaidInPeriod))
        sb.line("Interest paid in period", num(lr.borrowing.interestInPeriod))
        sb.line("Money lent in period", num(lr.lending.newPrincipal))
        sb.line("Repayments received in period", num(lr.lending.repaidInPeriod))
        sb.line("Interest earned in period", num(lr.lending.interestInPeriod))
        sb.line()
        sb.line("LOANS BY PERSON", "Type", "Loans", "Original", "Paid", "Outstanding", "Next due")
        (lr.borrowing.byPerson.map { "I owe" to it } + lr.lending.byPerson.map { "Owed to me" to it }).forEach { (kind, p) ->
            sb.line(p.name, kind, p.loans.toString(), num(p.principal), num(p.paid), num(p.outstanding), p.nextDue?.toString())
        }
        sb.line()

        appendIncomeRows(sb, incomes.filter { it.date in r.range })
        sb.line()
        appendLedgerRows(sb, ledger.filter { it.date in r.range })
        file.parentFile?.mkdirs()
        file.writeText(sb.toString(), Charsets.UTF_8)
    }

    /** Every record ever stored, for "Export all financial records". */
    fun writeAll(incomes: List<IncomeRecord>, ledger: List<LedgerRecord>, file: File) {
        val sb = StringBuilder("﻿")
        sb.line("PaulMoneyTracker – all records")
        sb.line("Currency", currencyCode)
        sb.line()
        appendIncomeRows(sb, incomes)
        sb.line()
        appendLedgerRows(sb, ledger)
        file.parentFile?.mkdirs()
        file.writeText(sb.toString(), Charsets.UTF_8)
    }

    private fun appendIncomeRows(sb: StringBuilder, rows: List<IncomeRecord>) {
        sb.line("INCOME TRANSACTIONS")
        sb.line(
            "Date", "Source", "Description", "Amount",
            "${accountName(AccountType.LIVING)} %", accountName(AccountType.LIVING),
            "${accountName(AccountType.SAVINGS)} %", accountName(AccountType.SAVINGS),
            "${accountName(AccountType.INVESTMENTS)} %", accountName(AccountType.INVESTMENTS),
            "${accountName(AccountType.GIVING)} %", accountName(AccountType.GIVING),
        )
        rows.sortedWith(compareBy({ it.date }, { it.createdAt })).forEach { r ->
            sb.line(
                r.date.toString(), r.source, r.description, num(r.amount),
                Money.formatPercent(r.percentages.living), num(r.split.living),
                Money.formatPercent(r.percentages.savings), num(r.split.savings),
                Money.formatPercent(r.percentages.investments), num(r.split.investments),
                Money.formatPercent(r.percentages.giving), num(r.split.giving),
            )
        }
    }

    private fun appendLedgerRows(sb: StringBuilder, rows: List<LedgerRecord>) {
        sb.line("ACCOUNT TRANSACTIONS")
        sb.line("Date", "Account", "Type", "Category / investment type", "Description", "Notes", "Money in", "Money out", "Recorded value")
        rows.sortedWith(compareBy({ it.date }, { it.createdAt })).forEach { r ->
            val isIn = r.signedAmount > 0
            sb.line(
                r.date.toString(), accountName(r.account), r.type.label,
                r.expenseCategory ?: r.investmentType, r.description, r.notes,
                if (isIn) num(r.amount) else "", if (!isIn) num(r.amount) else "",
                r.currentValue?.let { num(it) },
            )
        }
    }

    companion object {
        fun fileName(prefix: String, range: DateRange?, ext: String): String =
            if (range == null) "$prefix.$ext" else "${prefix}_${range.start}_to_${range.end}.$ext"
    }
}
