package com.babylon.moneytracker.domain

import java.math.BigDecimal
import java.math.RoundingMode
import java.time.LocalDate
import java.time.temporal.ChronoUnit

/*
 * LOANS: pure calculation rules (no Android code, fully unit-tested).
 *
 * A loan's outstanding balance is never stored. It is always recalculated from
 * the original principal, the interest terms and the recorded repayments.
 */

enum class LoanDirection { BORROWED, LENT }

enum class InterestPeriod(val label: String) {
    NONE("No interest"),
    MONTHLY("Per month"),
    ANNUAL("Per year"),
}

enum class RepaymentOrder(val label: String) {
    INTEREST_FIRST("Interest first, then principal"),
    PRINCIPAL_FIRST("Principal first, then interest"),
}

enum class LoanStatus {
    ACTIVE, PARTIAL, OVERDUE, SETTLED;

    fun label(direction: LoanDirection): String = when (this) {
        ACTIVE -> "Active"
        PARTIAL -> if (direction == LoanDirection.BORROWED) "Partially Paid" else "Partially Repaid"
        OVERDUE -> "Overdue"
        SETTLED -> if (direction == LoanDirection.BORROWED) "Fully Paid" else "Fully Repaid"
    }
}

/** One repayment (made or received). [id] is the linked account transaction id. */
data class LoanPayment(
    val id: Long,
    val amount: Long,
    val date: LocalDate,
    val account: AccountType,
    val notes: String?,
    val createdAt: Long = 0L,
)

data class LoanRecord(
    val id: Long,
    val direction: LoanDirection,
    val counterparty: String,
    val principal: Long,
    val date: LocalDate,
    val dueDate: LocalDate?,
    /** Account that received the borrowed money / that the lent money came from. */
    val account: AccountType,
    /** Simple-interest rate in basis points per [interestPeriod]: 500 = 5 %. */
    val interestRateBp: Int,
    val interestPeriod: InterestPeriod,
    val repaymentOrder: RepaymentOrder,
    val purpose: String?,
    val contact: String?,
    val notes: String?,
    val disbursementTxId: Long,
    val payments: List<LoanPayment>,
    val createdAt: Long = 0L,
) {
    val hasInterest: Boolean get() = interestPeriod != InterestPeriod.NONE && interestRateBp > 0
}

/** How one repayment was applied. */
data class PaymentLine(
    val payment: LoanPayment,
    val interestPart: Long,
    val principalPart: Long,
    /** Part of the payment that exceeded what was owed at that date (should always be 0). */
    val excess: Long,
    val balanceAfter: Long,
)

data class LoanState(
    val loan: LoanRecord,
    val asOf: LocalDate,
    val principalPaid: Long,
    val interestPaid: Long,
    val principalOutstanding: Long,
    /** All interest accrued from the loan date up to [asOf]. */
    val interestAccrued: Long,
    val interestOutstanding: Long,
    val excess: Long,
    val lines: List<PaymentLine>,
    val status: LoanStatus,
) {
    val totalPaid: Long get() = principalPaid + interestPaid
    val totalOutstanding: Long get() = principalOutstanding + interestOutstanding
    val isOverdue: Boolean get() = status == LoanStatus.OVERDUE
}

object LoanCalculator {

    /**
     * Number of interest periods between two dates, counting whole calendar
     * months/years plus the fraction of the next one. 1 Jan → 1 Feb = exactly 1 month.
     */
    fun periodsBetween(from: LocalDate, to: LocalDate, period: InterestPeriod): BigDecimal {
        if (!to.isAfter(from) || period == InterestPeriod.NONE) return BigDecimal.ZERO
        val unit = if (period == InterestPeriod.MONTHLY) ChronoUnit.MONTHS else ChronoUnit.YEARS
        val whole = unit.between(from, to)
        val anchor = from.plus(whole, unit)
        val next = from.plus(whole + 1, unit)
        val rem = ChronoUnit.DAYS.between(anchor, to)
        val len = ChronoUnit.DAYS.between(anchor, next).coerceAtLeast(1)
        return BigDecimal.valueOf(whole).add(
            BigDecimal.valueOf(rem).divide(BigDecimal.valueOf(len), 10, RoundingMode.HALF_UP)
        )
    }

    /** Simple interest on [principal] (never on interest) for the period, rounded to [unit]. */
    fun simpleInterest(
        principal: Long, rateBp: Int, period: InterestPeriod, from: LocalDate, to: LocalDate, unit: Long,
    ): Long {
        if (principal <= 0 || rateBp <= 0 || period == InterestPeriod.NONE) return 0
        val raw = BigDecimal.valueOf(principal)
            .multiply(BigDecimal.valueOf(rateBp.toLong()))
            .multiply(periodsBetween(from, to, period))
            .divide(BigDecimal.valueOf(Percentages.FULL.toLong()), 10, RoundingMode.HALF_UP)
        val u = BigDecimal.valueOf(unit.coerceAtLeast(1))
        return raw.divide(u, 0, RoundingMode.HALF_UP).toLong() * unit.coerceAtLeast(1)
    }

    /**
     * Replays the loan from its start date: interest accrues (simple, on the
     * principal still outstanding) between events, each repayment is split by
     * the loan's [RepaymentOrder], and the balance is carried forward.
     * Interest keeps accruing up to [asOf] while principal is outstanding.
     */
    fun compute(loan: LoanRecord, asOf: LocalDate, unit: Long = 1L, today: LocalDate = asOf): LoanState {
        var principal = loan.principal
        var interestDue = 0L
        var accrued = 0L
        var principalPaid = 0L
        var interestPaid = 0L
        var excess = 0L
        var last = loan.date
        val lines = mutableListOf<PaymentLine>()

        fun accrueTo(d: LocalDate) {
            if (d.isAfter(last)) {
                val i = if (loan.hasInterest) {
                    simpleInterest(principal, loan.interestRateBp, loan.interestPeriod, last, d, unit)
                } else 0L
                interestDue += i
                accrued += i
                last = d
            }
        }

        val sorted = loan.payments.filter { !it.date.isAfter(asOf) }
            .sortedWith(compareBy<LoanPayment> { it.date }.thenBy { it.createdAt }.thenBy { it.id })
        for (p in sorted) {
            accrueTo(p.date)
            var left = p.amount
            var toInterest: Long
            var toPrincipal: Long
            if (loan.repaymentOrder == RepaymentOrder.INTEREST_FIRST) {
                toInterest = minOf(left, interestDue); left -= toInterest
                toPrincipal = minOf(left, principal); left -= toPrincipal
            } else {
                toPrincipal = minOf(left, principal); left -= toPrincipal
                toInterest = minOf(left, interestDue); left -= toInterest
            }
            interestDue -= toInterest
            principal -= toPrincipal
            interestPaid += toInterest
            principalPaid += toPrincipal
            excess += left
            lines += PaymentLine(p, toInterest, toPrincipal, left, principal + interestDue)
        }
        if (principal > 0) accrueTo(asOf)

        val outstanding = principal + interestDue
        val status = when {
            outstanding <= 0 -> LoanStatus.SETTLED
            loan.dueDate != null && today.isAfter(loan.dueDate) -> LoanStatus.OVERDUE
            principalPaid + interestPaid > 0 -> LoanStatus.PARTIAL
            else -> LoanStatus.ACTIVE
        }
        return LoanState(
            loan = loan,
            asOf = asOf,
            principalPaid = principalPaid,
            interestPaid = interestPaid,
            principalOutstanding = principal,
            interestAccrued = accrued,
            interestOutstanding = interestDue,
            excess = excess,
            lines = lines,
            status = status,
        )
    }

    /** Amount still owed on [date] before any payment dated after the existing ones. */
    fun outstandingOn(loan: LoanRecord, date: LocalDate, unit: Long = 1L): Long =
        compute(loan, date, unit).totalOutstanding
}

/** Figures for the Loans page summary. */
data class LoanTotals(
    /** Outstanding money I owe (principal + interest). */
    val owed: Long,
    /** Outstanding money owed to me (principal + interest). */
    val receivable: Long,
    val repaymentsMade: Long,
    val repaymentsReceived: Long,
    val interestPaid: Long,
    val interestReceived: Long,
    val overdueOwed: Int,
    val overdueReceivable: Int,
) {
    val net: Long get() = receivable - owed

    companion object {
        val ZERO = LoanTotals(0, 0, 0, 0, 0, 0, 0, 0)

        fun of(states: List<LoanState>): LoanTotals {
            val b = states.filter { it.loan.direction == LoanDirection.BORROWED }
            val l = states.filter { it.loan.direction == LoanDirection.LENT }
            return LoanTotals(
                owed = b.sumOf { it.totalOutstanding },
                receivable = l.sumOf { it.totalOutstanding },
                repaymentsMade = b.sumOf { it.totalPaid },
                repaymentsReceived = l.sumOf { it.totalPaid },
                interestPaid = b.sumOf { it.interestPaid },
                interestReceived = l.sumOf { it.interestPaid },
                overdueOwed = b.count { it.isOverdue },
                overdueReceivable = l.count { it.isOverdue },
            )
        }
    }
}

// ----------------------------------------------------------------------------
// Reports
// ----------------------------------------------------------------------------

data class PersonLoanLine(
    val name: String,
    val loans: Int,
    val principal: Long,
    val paid: Long,
    val outstanding: Long,
    val nextDue: LocalDate?,
)

data class LoanSideReport(
    val direction: LoanDirection,
    /** Principal of loans that started inside the period. */
    val newPrincipal: Long,
    /** All repayments dated inside the period. */
    val repaidInPeriod: Long,
    val principalRepaidInPeriod: Long,
    val interestInPeriod: Long,
    /** Outstanding (principal + interest) on the last day of the period. */
    val outstandingAtEnd: Long,
    val principalOutstandingAtEnd: Long,
    val byPerson: List<PersonLoanLine>,
    /** Unsettled loans due within the next 30 days (as of today). */
    val upcoming: List<LoanState>,
    /** Unsettled loans past their expected date (as of today). */
    val overdue: List<LoanState>,
)

data class LoanReport(val borrowing: LoanSideReport, val lending: LoanSideReport) {
    val netPositionAtEnd: Long get() = lending.outstandingAtEnd - borrowing.outstandingAtEnd

    companion object {
        fun build(loans: List<LoanRecord>, range: DateRange, today: LocalDate, unit: Long = 1L): LoanReport =
            LoanReport(
                side(loans, LoanDirection.BORROWED, range, today, unit),
                side(loans, LoanDirection.LENT, range, today, unit),
            )

        private fun side(
            all: List<LoanRecord>, dir: LoanDirection, range: DateRange, today: LocalDate, unit: Long,
        ): LoanSideReport {
            val loans = all.filter { it.direction == dir && !it.date.isAfter(range.end) }
            val atEnd = loans.map { LoanCalculator.compute(it, range.end, unit, today) }
            val linesInRange = atEnd.flatMap { s -> s.lines.filter { it.payment.date in range } }
            val now = all.filter { it.direction == dir }.map { LoanCalculator.compute(it, today, unit, today) }
            return LoanSideReport(
                direction = dir,
                newPrincipal = loans.filter { it.date in range }.sumOf { it.principal },
                repaidInPeriod = linesInRange.sumOf { it.payment.amount },
                principalRepaidInPeriod = linesInRange.sumOf { it.principalPart },
                interestInPeriod = linesInRange.sumOf { it.interestPart },
                outstandingAtEnd = atEnd.sumOf { it.totalOutstanding },
                principalOutstandingAtEnd = atEnd.sumOf { it.principalOutstanding },
                byPerson = atEnd.groupBy { it.loan.counterparty.trim().lowercase() }.map { (_, states) ->
                    PersonLoanLine(
                        name = states.first().loan.counterparty.trim(),
                        loans = states.size,
                        principal = states.sumOf { it.loan.principal },
                        paid = states.sumOf { it.totalPaid },
                        outstanding = states.sumOf { it.totalOutstanding },
                        nextDue = states.filter { it.totalOutstanding > 0 }.mapNotNull { it.loan.dueDate }.minOrNull(),
                    )
                }.sortedByDescending { it.outstanding },
                upcoming = now.filter {
                    val d = it.loan.dueDate
                    it.totalOutstanding > 0 && d != null && !d.isBefore(today) && !d.isAfter(today.plusDays(30))
                }.sortedBy { it.loan.dueDate },
                overdue = now.filter { it.isOverdue }.sortedBy { it.loan.dueDate },
            )
        }
    }
}
