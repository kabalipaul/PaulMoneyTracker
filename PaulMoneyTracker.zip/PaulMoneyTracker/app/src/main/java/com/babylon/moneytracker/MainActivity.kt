package com.babylon.moneytracker

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.babylon.moneytracker.reminder.NotificationHelper
import com.babylon.moneytracker.ui.BabylonAppRoot

class MainActivity : ComponentActivity() {

    /** Set when the user taps the daily reminder: opens the Add Income screen. */
    private var openAddIncome by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        if (savedInstanceState == null) openAddIncome = wantsAddIncome(intent)
        setContent {
            BabylonAppRoot(openAddIncome = openAddIncome, onOpenHandled = { openAddIncome = false })
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (wantsAddIncome(intent)) openAddIncome = true
    }

    private fun wantsAddIncome(intent: Intent?): Boolean =
        intent?.getStringExtra(NotificationHelper.EXTRA_OPEN) == NotificationHelper.OPEN_ADD_INCOME
}
