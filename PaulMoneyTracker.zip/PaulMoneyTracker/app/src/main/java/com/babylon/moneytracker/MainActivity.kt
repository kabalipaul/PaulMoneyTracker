package com.babylon.moneytracker

import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.fragment.app.FragmentActivity
import com.babylon.moneytracker.reminder.NotificationHelper
import com.babylon.moneytracker.security.AppLock
import com.babylon.moneytracker.ui.BabylonAppRoot

/** FragmentActivity (a ComponentActivity) so the fingerprint dialog can be shown. */
class MainActivity : FragmentActivity() {

    /** Set when the user taps the daily reminder: opens the Add Income screen. */
    private var openAddIncome by mutableStateOf(false)

    /** True while the PIN / fingerprint screen must be shown. */
    private var locked by mutableStateOf(false)

    /** When the app last went to the background (elapsed realtime), 0 = never. */
    private var stoppedAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppLock.applyWindowFlags(this)
        enableEdgeToEdge()
        locked = AppLock.isEnabled(this) && (savedInstanceState?.getBoolean(KEY_LOCKED, true) ?: true)
        if (savedInstanceState == null) openAddIncome = wantsAddIncome(intent)
        setContent {
            BabylonAppRoot(
                openAddIncome = openAddIncome,
                onOpenHandled = { openAddIncome = false },
                locked = locked,
                onUnlocked = { locked = false },
            )
        }
    }

    override fun onStart() {
        super.onStart()
        AppLock.applyWindowFlags(this)
        val away = if (stoppedAt == 0L) 0L else SystemClock.elapsedRealtime() - stoppedAt
        if (AppLock.isEnabled(this) && stoppedAt != 0L && away >= AppLock.timeoutMs(this)) locked = true
    }

    override fun onStop() {
        super.onStop()
        stoppedAt = SystemClock.elapsedRealtime()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean(KEY_LOCKED, locked)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (wantsAddIncome(intent)) openAddIncome = true
    }

    private fun wantsAddIncome(intent: Intent?): Boolean =
        intent?.getStringExtra(NotificationHelper.EXTRA_OPEN) == NotificationHelper.OPEN_ADD_INCOME

    private companion object {
        const val KEY_LOCKED = "locked"
    }
}
