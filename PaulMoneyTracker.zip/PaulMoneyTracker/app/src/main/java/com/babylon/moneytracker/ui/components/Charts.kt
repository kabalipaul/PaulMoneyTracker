package com.babylon.moneytracker.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.babylon.moneytracker.domain.Money
import com.babylon.moneytracker.domain.NamedAmount
import com.babylon.moneytracker.domain.SeriesPoint

/*
 * Lightweight charts drawn with Compose Canvas: no third-party chart library,
 * so nothing can break on an Android update. All values are minor units.
 */

data class Slice(val label: String, val value: Long, val color: Color)

@Composable
fun DonutChart(
    slices: List<Slice>,
    modifier: Modifier = Modifier,
    size: Dp = 150.dp,
    thickness: Dp = 22.dp,
    centerContent: @Composable () -> Unit = {},
) {
    val track = MaterialTheme.colorScheme.surfaceVariant
    Box(modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = thickness.toPx()
            val arcSize = Size(this.size.minDimension - stroke, this.size.minDimension - stroke)
            val topLeft = Offset(stroke / 2, stroke / 2)
            val total = slices.sumOf { it.value.coerceAtLeast(0) }
            if (total <= 0L) {
                drawArc(track, 0f, 360f, false, topLeft, arcSize, style = Stroke(stroke))
            } else {
                var start = -90f
                slices.forEach { s ->
                    val sweep = 360f * (s.value.coerceAtLeast(0).toFloat() / total)
                    if (sweep > 0f) drawArc(s.color, start, sweep, false, topLeft, arcSize, style = Stroke(stroke))
                    start += sweep
                }
            }
        }
        centerContent()
    }
}

@Composable
fun Legend(slices: List<Slice>, fmt: (Long) -> String, modifier: Modifier = Modifier) {
    val total = slices.sumOf { it.value }
    Column(modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        slices.forEach { s ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(10.dp).clip(CircleShape).background(s.color))
                Spacer(Modifier.width(8.dp))
                Column {
                    Text(s.label, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    val pct = if (total > 0) (s.value * 1000 / total) / 10.0 else 0.0
                    Text(
                        "${fmt(s.value)} · $pct%",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

@Composable
private fun AxisLabels(points: List<SeriesPoint>) {
    if (points.isEmpty()) return
    val picks = when {
        points.size == 1 -> listOf(points.first().label)
        points.size <= 3 -> points.map { it.label }
        else -> listOf(points.first().label, points[points.size / 2].label, points.last().label)
    }
    Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        picks.forEach {
            Text(it, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun MaxLabel(max: Long) {
    Text(
        "Peak ${Money.compact(max)}",
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(bottom = 4.dp),
    )
}

@Composable
fun LineChart(points: List<SeriesPoint>, color: Color, modifier: Modifier = Modifier, height: Dp = 140.dp) {
    val grid = MaterialTheme.colorScheme.outlineVariant
    val max = points.maxOfOrNull { it.value }?.coerceAtLeast(1L) ?: 1L
    val min = minOf(0L, points.minOfOrNull { it.value } ?: 0L)
    Column(modifier.fillMaxWidth()) {
        MaxLabel(points.maxOfOrNull { it.value } ?: 0)
        Canvas(Modifier.fillMaxWidth().height(height)) {
            val w = size.width
            val h = size.height
            for (i in 0..3) {
                val y = h * i / 3f
                drawLine(grid, Offset(0f, y), Offset(w, y), strokeWidth = 1f)
            }
            if (points.isEmpty()) return@Canvas
            val span = (max - min).toFloat().coerceAtLeast(1f)
            fun px(i: Int) = if (points.size == 1) w / 2 else w * i / (points.size - 1)
            fun py(v: Long) = h - h * ((v - min) / span)
            val line = Path()
            points.forEachIndexed { i, p ->
                if (i == 0) line.moveTo(px(i), py(p.value)) else line.lineTo(px(i), py(p.value))
            }
            val area = Path().apply {
                addPath(line)
                lineTo(px(points.size - 1), h)
                lineTo(px(0), h)
                close()
            }
            drawPath(area, Brush.verticalGradient(listOf(color.copy(alpha = 0.25f), Color.Transparent)))
            drawPath(line, color, style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
            if (points.size <= 31) {
                points.forEachIndexed { i, p -> drawCircle(color, 3.dp.toPx(), Offset(px(i), py(p.value))) }
            }
        }
        AxisLabels(points)
    }
}

@Composable
fun BarChart(points: List<SeriesPoint>, color: Color, modifier: Modifier = Modifier, height: Dp = 140.dp) {
    val grid = MaterialTheme.colorScheme.outlineVariant
    val max = points.maxOfOrNull { it.value }?.coerceAtLeast(1L) ?: 1L
    Column(modifier.fillMaxWidth()) {
        MaxLabel(points.maxOfOrNull { it.value } ?: 0)
        Canvas(Modifier.fillMaxWidth().height(height)) {
            val w = size.width
            val h = size.height
            drawLine(grid, Offset(0f, h), Offset(w, h), strokeWidth = 1f)
            if (points.isEmpty()) return@Canvas
            val slot = w / points.size
            val barW = (slot * 0.65f).coerceAtMost(36.dp.toPx())
            points.forEachIndexed { i, p ->
                val bh = h * (p.value.coerceAtLeast(0).toFloat() / max)
                if (bh > 0f) {
                    drawRoundRect(
                        color,
                        topLeft = Offset(slot * i + (slot - barW) / 2, h - bh),
                        size = Size(barW, bh),
                        cornerRadius = CornerRadius(4.dp.toPx(), 4.dp.toPx()),
                    )
                }
            }
        }
        AxisLabels(points)
    }
}

/** Ranked horizontal bars, e.g. expenses by category. */
@Composable
fun HorizontalBars(items: List<NamedAmount>, color: Color, fmt: (Long) -> String, modifier: Modifier = Modifier) {
    val max = items.maxOfOrNull { it.amount }?.coerceAtLeast(1L) ?: 1L
    Column(modifier, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items.forEach { item ->
            Column {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(item.name, style = MaterialTheme.typography.bodyMedium)
                    Text(fmt(item.amount), style = MaterialTheme.typography.bodyMedium)
                }
                Spacer(Modifier.height(4.dp))
                ProgressBar(item.amount.toFloat() / max, color)
            }
        }
    }
}
