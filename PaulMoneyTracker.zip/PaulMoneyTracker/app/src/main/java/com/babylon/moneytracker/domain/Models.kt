package com.babylon.moneytracker.domain

import java.time.LocalDate

/**
 * Pure domain types. Nothing in this package depends on Android, so every
 * financial rule can be unit-tested on a plain JVM.
 *
 * MONEY REPRESENTATION
 * All amounts are Long "minor units" = currency amount x 100.
 * UGX 1,500,000 is stored as 150_000_000. Integer arithmetic means no
 * floating-point drift ever touches a balance.
 */

enum class AccountType(val id: Int, val defaultName: String) {
    LIVING(1, "Living Expenses"),
    SAVINGS(2, "Savings"),
    INVESTMENTS(3, "Investments"),
    GIVING(4, "Debt Repayment/Giving");

    companion object {
        fun fromId(id: Int): AccountType = entries.first { it.id == id }
    }
}

enum class TxDirection { IN, OUT }

/**
 * Every movement of money inside an envelope (other than the automatic income
 * allocation, which lives in the Allocation table).
 */
enum class TxType(val label: String, val direction: TxDirection, val accounts: Set<AccountType>) {
    EXPENSE("Expense", TxDirection.OUT, setOf(AccountType.LIVING)),

    WITHDRAWAL("Withdrawal", TxDirection.OUT, setOf(AccountType.SAVINGS)),
    DEPOSIT("Deposit from another source", TxDirection.IN, setOf(AccountType.SAVINGS)),

    INVESTMENT_CONTRIBUTION("Money invested", TxDirection.OUT, setOf(AccountType.INVESTMENTS)),
    INVESTMENT_RETURN("Investment return", TxDirection.IN, setOf(AccountType.INVESTMENTS)),
    INVESTMENT_CASHOUT("Investment cashed out (capital back)", TxDirection.IN, setOf(AccountType.INVESTMENTS)),

    DEBT_REPAYMENT("Debt repayment", TxDirection.OUT, setOf(AccountType.GIVING)),
    FAMILY_SUPPORT("Family support", TxDirection.OUT, setOf(AccountType.GIVING)),
    DONATION("Donation", TxDirection.OUT, setOf(AccountType.GIVING)),
    CHARITY("Charity", TxDirection.OUT, setOf(AccountType.GIVING)),
    OTHER_GIVING("Other giving", TxDirection.OUT, setOf(AccountType.GIVING)),

    TRANSFER_IN("Transfer in", TxDirection.IN, AccountType.entries.toSet()),
    TRANSFER_OUT("Transfer out", TxDirection.OUT, AccountType.entries.toSet());

    val isTransfer: Boolean get() = this == TRANSFER_IN || this == TRANSFER_OUT
    val isGiving: Boolean get() = this in GIVING_TYPES

    companion object {
        val GIVING_TYPES = setOf(DEBT_REPAYMENT, FAMILY_SUPPORT, DONATION, CHARITY, OTHER_GIVING)

        /** The "main use" of each envelope: what the dashboard calls Spent / Withdrawn / Invested / Used. */
        fun primaryUse(account: AccountType): Set<TxType> = when (account) {
            AccountType.LIVING -> setOf(EXPENSE)
            AccountType.SAVINGS -> setOf(WITHDRAWAL)
            AccountType.INVESTMENTS -> setOf(INVESTMENT_CONTRIBUTION)
            AccountType.GIVING -> GIVING_TYPES
        }

        /** Types a person can pick directly when recording into an envelope (transfers have their own flow). */
        fun manualTypesFor(account: AccountType): List<TxType> =
            entries.filter { account in it.accounts && !it.isTransfer }
    }
}

enum class GoalMetric(val label: String) {
    SAVINGS_BALANCE("Savings balance"),
    INVESTMENT_CONTRIBUTIONS("Total money invested"),
    INVESTMENT_VALUE("Recorded investment value"),
    TOTAL_ASSETS("Total tracked assets"),
    MANUAL("I'll update it myself"),
}

enum class ThemeMode { SYSTEM, LIGHT, DARK }

/** Allocation percentages in basis points: 7000 = 70.00 %. Must total exactly 10000. */
data class Percentages(val living: Int, val savings: Int, val investments: Int, val giving: Int) {
    val total: Int get() = living + savings + investments + giving
    val isValid: Boolean
        get() = listOf(living, savings, investments, giving).all { it in 0..FULL } && total == FULL

    fun of(type: AccountType): Int = when (type) {
        AccountType.LIVING -> living
        AccountType.SAVINGS -> savings
        AccountType.INVESTMENTS -> investments
        AccountType.GIVING -> giving
    }

    companion object {
        const val FULL = 10_000
        val DEFAULT = Percentages(7000, 1000, 1000, 1000)
    }
}

data class AllocationSplit(val living: Long, val savings: Long, val investments: Long, val giving: Long) {
    val total: Long get() = living + savings + investments + giving

    fun of(type: AccountType): Long = when (type) {
        AccountType.LIVING -> living
        AccountType.SAVINGS -> savings
        AccountType.INVESTMENTS -> investments
        AccountType.GIVING -> giving
    }

    operator fun plus(o: AllocationSplit) = AllocationSplit(
        living + o.living, savings + o.savings, investments + o.investments, giving + o.giving
    )

    companion object {
        val ZERO = AllocationSplit(0, 0, 0, 0)
    }
}

data class IncomeRecord(
    val id: Long,
    val amount: Long,
    val date: LocalDate,
    val source: String,
    val description: String?,
    val percentages: Percentages,
    val split: AllocationSplit,
    val createdAt: Long = 0L,
)

data class LedgerRecord(
    val id: Long,
    val account: AccountType,
    val type: TxType,
    val amount: Long,
    val date: LocalDate,
    val description: String,
    val notes: String? = null,
    val referenceId: String? = null,
    val expenseCategory: String? = null,
    val investmentType: String? = null,
    /** For investment contributions: the latest value the user recorded, if any. */
    val currentValue: Long? = null,
    val createdAt: Long = 0L,
) {
    /** Effect on the envelope's available balance. */
    val signedAmount: Long get() = if (type.direction == TxDirection.IN) amount else -amount
}

data class Goal(
    val id: Long,
    val name: String,
    val target: Long,
    val targetDate: LocalDate?,
    val metric: GoalMetric,
    val manualCurrent: Long,
)

object Categories {
    val INCOME_SOURCES = listOf("Salary", "Business", "Freelancing", "Agriculture", "Other")
    val EXPENSE = listOf(
        "Rent", "Food", "Transport", "Utilities", "Airtime and Internet",
        "Clothing", "Healthcare", "Family", "Other",
    )
    val INVESTMENT_TYPES = listOf(
        "Treasury Bills", "Treasury Bonds", "Agriculture", "Business", "Real Estate", "Other",
    )
}
