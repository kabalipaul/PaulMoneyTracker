package com.babylon.moneytracker.data.db

import androidx.room.Embedded
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation
import com.babylon.moneytracker.domain.AccountType
import com.babylon.moneytracker.domain.GoalMetric
import com.babylon.moneytracker.domain.InterestPeriod
import com.babylon.moneytracker.domain.LoanDirection
import com.babylon.moneytracker.domain.RepaymentOrder
import com.babylon.moneytracker.domain.ThemeMode
import com.babylon.moneytracker.domain.TxType

/*
 * Dates are stored as epoch days (LocalDate.toEpochDay()), so a "date received"
 * never shifts when the phone changes time zone. Timestamps (createdAt) are epoch millis.
 * Money is stored as Long minor units (amount x 100).
 */

/** The four virtual envelopes. Rows 1–4 are created on first launch and never deleted. */
@Entity(tableName = "accounts")
data class Account(
    @PrimaryKey val id: Int,
    val type: AccountType,
    val name: String,
    val sortOrder: Int,
)

@Entity(
    tableName = "income_transactions",
    indices = [Index("dateEpochDay")],
)
data class IncomeTransaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val amountMinor: Long,
    val dateEpochDay: Long,
    val source: String,
    val description: String?,
    // Percentages (basis points) in force when the entry was first recorded. Never rewritten.
    val livingBp: Int,
    val savingsBp: Int,
    val investmentsBp: Int,
    val givingBp: Int,
    val createdAt: Long,
    val updatedAt: Long,
)

/** One row per envelope per income entry. Deleted automatically with its income. */
@Entity(
    tableName = "allocations",
    foreignKeys = [
        ForeignKey(
            entity = IncomeTransaction::class,
            parentColumns = ["id"],
            childColumns = ["incomeId"],
            onDelete = ForeignKey.CASCADE,
        ),
        ForeignKey(entity = Account::class, parentColumns = ["id"], childColumns = ["accountId"]),
    ],
    indices = [Index("incomeId"), Index("accountId")],
)
data class Allocation(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val incomeId: Long,
    val accountId: Int,
    val percentBp: Int,
    val amountMinor: Long,
)

/** The ledger: every movement of money in an envelope other than income allocation. */
@Entity(
    tableName = "account_transactions",
    foreignKeys = [ForeignKey(entity = Account::class, parentColumns = ["id"], childColumns = ["accountId"])],
    indices = [Index("accountId"), Index("dateEpochDay"), Index("referenceId")],
)
data class AccountTransaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val accountId: Int,
    val type: TxType,
    val amountMinor: Long,
    val dateEpochDay: Long,
    val description: String,
    val notes: String?,
    /** Links the two legs of a transfer (shared UUID). */
    val referenceId: String?,
    val createdAt: Long,
    val updatedAt: Long,
)

/** Extra detail for a Living Expenses spend. */
@Entity(
    tableName = "expense_transactions",
    foreignKeys = [
        ForeignKey(
            entity = AccountTransaction::class,
            parentColumns = ["id"],
            childColumns = ["accountTransactionId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index(value = ["accountTransactionId"], unique = true)],
)
data class ExpenseTransaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val accountTransactionId: Long,
    val category: String,
)

/** Extra detail for an investment contribution, return or cash-out. */
@Entity(
    tableName = "investment_transactions",
    foreignKeys = [
        ForeignKey(
            entity = AccountTransaction::class,
            parentColumns = ["id"],
            childColumns = ["accountTransactionId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index(value = ["accountTransactionId"], unique = true)],
)
data class InvestmentTransaction(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val accountTransactionId: Long,
    val investmentType: String,
    /** Latest value the user recorded for a contribution; null = not provided. */
    val currentValueMinor: Long?,
)

@Entity(tableName = "savings_goals")
data class SavingsGoal(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val targetMinor: Long,
    val targetDateEpochDay: Long?,
    val metric: GoalMetric,
    val manualCurrentMinor: Long,
    val createdAt: Long,
)

@Entity(tableName = "app_settings")
data class AppSettings(
    @PrimaryKey val id: Int = 1,
    val currencyCode: String = "UGX",
    val currencySymbol: String = "UGX",
    val currencyDecimals: Int = 0,
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    val livingBp: Int = 7000,
    val savingsBp: Int = 1000,
    val investmentsBp: Int = 1000,
    val givingBp: Int = 1000,
    val savingsTargetMinor: Long? = null,
)

@Entity(tableName = "reminder_settings")
data class ReminderSettings(
    @PrimaryKey val id: Int = 1,
    val enabled: Boolean = true,
    val hour: Int = 20,
    val minute: Int = 0,
    /** When income is already recorded: true = send a short confirmation, false = stay silent. */
    val confirmWhenRecorded: Boolean = false,
)

data class IncomeWithAllocations(
    @Embedded val income: IncomeTransaction,
    @Relation(parentColumn = "id", entityColumn = "incomeId")
    val allocations: List<Allocation>,
)

data class AccountTransactionWithDetails(
    @Embedded val tx: AccountTransaction,
    @Relation(parentColumn = "id", entityColumn = "accountTransactionId")
    val expense: ExpenseTransaction?,
    @Relation(parentColumn = "id", entityColumn = "accountTransactionId")
    val investment: InvestmentTransaction?,
)

// ---------------------------------------------------------------------------
// Loans (database version 2)
// ---------------------------------------------------------------------------

/**
 * Money borrowed (creditor) or lent (debtor). The money that came in or went out
 * when the loan started is the linked ledger row [disbursementTxId].
 * Outstanding balances are never stored; they are calculated from the principal,
 * the interest terms and the linked repayments.
 */
@Entity(
    tableName = "loans",
    foreignKeys = [
        ForeignKey(entity = AccountTransaction::class, parentColumns = ["id"], childColumns = ["disbursementTxId"]),
    ],
    indices = [Index(value = ["disbursementTxId"], unique = true)],
)
data class Loan(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val direction: LoanDirection,
    val counterparty: String,
    val principalMinor: Long,
    val dateEpochDay: Long,
    val dueDateEpochDay: Long?,
    val interestRateBp: Int,
    val interestPeriod: InterestPeriod,
    val repaymentOrder: RepaymentOrder,
    val purpose: String?,
    val contact: String?,
    val notes: String?,
    val disbursementTxId: Long,
    val createdAt: Long,
    val updatedAt: Long,
)

/**
 * Links a loan to the ledger row of one repayment (made or received).
 * Amount, date and account live on that ledger row, so the account history
 * and the loan history can never disagree.
 */
@Entity(
    tableName = "loan_repayments",
    foreignKeys = [
        ForeignKey(
            entity = Loan::class,
            parentColumns = ["id"],
            childColumns = ["loanId"],
            onDelete = ForeignKey.CASCADE,
        ),
        ForeignKey(
            entity = AccountTransaction::class,
            parentColumns = ["id"],
            childColumns = ["accountTransactionId"],
            onDelete = ForeignKey.CASCADE,
        ),
    ],
    indices = [Index("loanId"), Index(value = ["accountTransactionId"], unique = true)],
)
data class LoanRepayment(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val loanId: Long,
    val accountTransactionId: Long,
    val createdAt: Long,
)
