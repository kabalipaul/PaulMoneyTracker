package com.babylon.moneytracker.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.babylon.moneytracker.domain.AccountType
import com.babylon.moneytracker.domain.ThemeMode

object Palette {
    val Forest = Color(0xFF164B35)
    val LightGreen = Color(0xFFE5F1E9)
    val Cream = Color(0xFFF8F6F0)
    val Gold = Color(0xFFD6A84B)
    val Charcoal = Color(0xFF252B27)
    val White = Color(0xFFFFFFFF)
    val Bronze = Color(0xFFA9792A)
    val Sage = Color(0xFF5E8C76)
    val Grey = Color(0xFF6B726E)
    val Danger = Color(0xFFB3261E)
    val Mint = Color(0xFF8FD3AE)
    /** Money owed (debts). */
    val Orange = Color(0xFFD9822B)
}

/** Green for everyday money and growth, gold tones for savings and investments. */
fun AccountType.color(): Color = when (this) {
    AccountType.LIVING -> Palette.Forest
    AccountType.SAVINGS -> Palette.Gold
    AccountType.INVESTMENTS -> Palette.Bronze
    AccountType.GIVING -> Palette.Sage
}

/** Same as [color] but keeps Living Expenses readable in dark mode. */
@Composable
fun AccountType.uiColor(): Color =
    if (this == AccountType.LIVING) MaterialTheme.colorScheme.primary else color()

private val LightColors = lightColorScheme(
    primary = Palette.Forest,
    onPrimary = Palette.White,
    primaryContainer = Palette.LightGreen,
    onPrimaryContainer = Palette.Forest,
    secondary = Palette.Gold,
    onSecondary = Palette.Charcoal,
    secondaryContainer = Color(0xFFF5E7C6),
    onSecondaryContainer = Color(0xFF4A3A12),
    background = Palette.Cream,
    onBackground = Palette.Charcoal,
    surface = Palette.Cream,
    onSurface = Palette.Charcoal,
    surfaceVariant = Palette.LightGreen,
    onSurfaceVariant = Color(0xFF47504B),
    surfaceContainerLowest = Palette.White,
    surfaceContainerLow = Palette.White,
    surfaceContainer = Color(0xFFF1EFE7),
    surfaceContainerHigh = Color(0xFFECEAE2),
    surfaceContainerHighest = Color(0xFFE6E4DC),
    outline = Color(0xFFC9CEC9),
    outlineVariant = Color(0xFFDCE0DB),
    error = Palette.Danger,
)

private val DarkColors = darkColorScheme(
    primary = Palette.Mint,
    onPrimary = Color(0xFF0B2A1D),
    primaryContainer = Color(0xFF1F5A41),
    onPrimaryContainer = Palette.LightGreen,
    secondary = Palette.Gold,
    onSecondary = Palette.Charcoal,
    secondaryContainer = Color(0xFF5A4719),
    onSecondaryContainer = Color(0xFFF5E7C6),
    background = Color(0xFF121614),
    onBackground = Color(0xFFE4E7E3),
    surface = Color(0xFF121614),
    onSurface = Color(0xFFE4E7E3),
    surfaceVariant = Color(0xFF26302B),
    onSurfaceVariant = Color(0xFFBFC7C1),
    surfaceContainerLowest = Color(0xFF0E1210),
    surfaceContainerLow = Color(0xFF1A1F1C),
    surfaceContainer = Color(0xFF1E2420),
    surfaceContainerHigh = Color(0xFF252B27),
    surfaceContainerHighest = Color(0xFF2E3530),
    outline = Color(0xFF5B645F),
    outlineVariant = Color(0xFF3A423D),
    error = Color(0xFFF2B8B5),
)

private val AppTypography = Typography().let { base ->
    base.copy(
        headlineMedium = base.headlineMedium.copy(fontWeight = FontWeight.SemiBold),
        headlineSmall = base.headlineSmall.copy(fontWeight = FontWeight.SemiBold),
        titleLarge = base.titleLarge.copy(fontWeight = FontWeight.SemiBold),
        titleMedium = base.titleMedium.copy(fontWeight = FontWeight.SemiBold),
        labelLarge = base.labelLarge.copy(fontWeight = FontWeight.SemiBold),
    )
}

val MoneyLarge = TextStyle(fontSize = 30.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.5).sp)

@Composable
fun BabylonTheme(mode: ThemeMode, content: @Composable () -> Unit) {
    val dark = when (mode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    MaterialTheme(
        colorScheme = if (dark) DarkColors else LightColors,
        typography = AppTypography,
        content = content,
    )
}
