package com.babylon.moneytracker.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.CompareArrows
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.babylon.moneytracker.domain.AccountType
import com.babylon.moneytracker.domain.Money
import com.babylon.moneytracker.domain.TxDirection
import com.babylon.moneytracker.domain.TxType
import com.babylon.moneytracker.ui.AppState
import com.babylon.moneytracker.ui.MainViewModel
import com.babylon.moneytracker.ui.Routes
import com.babylon.moneytracker.ui.components.AmountField
import com.babylon.moneytracker.ui.components.DateShort
import com.babylon.moneytracker.ui.components.EmptyNote
import com.babylon.moneytracker.ui.components.LabelValue
import com.babylon.moneytracker.ui.components.LocalMoney
import com.babylon.moneytracker.ui.components.ProgressBar
import com.babylon.moneytracker.ui.components.ScreenTopBar
import com.babylon.moneytracker.ui.components.SectionCard
import com.babylon.moneytracker.ui.components.TxRow
import com.babylon.moneytracker.ui.theme.uiColor
import java.time.LocalDate

@Composable
fun AccountsScreen(state: AppState, nav: NavController) {
    Column(Modifier.fillMaxSize()) {
        ScreenTopBar("My Accounts")
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                "Every amount you record as income is divided into these four accounts automatically. " +
                    "They are tracking envelopes, not bank accounts.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            AccountType.entries.forEach { t ->
                AccountCard(
                    summary = state.overview.account(t),
                    name = state.name(t),
                    percentBp = when (t) {
                        AccountType.LIVING -> state.settings.livingBp
                        AccountType.SAVINGS -> state.settings.savingsBp
                        AccountType.INVESTMENTS -> state.settings.investmentsBp
                        AccountType.GIVING -> state.settings.givingBp
                    },
                    onClick = { nav.navigate(Routes.account(t)) },
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            OutlinedButton(onClick = { nav.navigate(Routes.transfer()) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.AutoMirrored.Filled.CompareArrows, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Move money between accounts")
            }
            Spacer(Modifier.height(88.dp))
        }
    }
}

/** One line in an account's history: either an income allocation or a ledger transaction. */
private data class HistoryItem(
    val date: LocalDate,
    val sortKey: Long,
    val title: String,
    val subtitle: String,
    val signed: Long,
    val onClick: () -> Unit,
)

@Composable
fun AccountDetailScreen(state: AppState, vm: MainViewModel, nav: NavController, type: AccountType) {
    val fmt = LocalMoney.current
    val context = LocalContext.current
    val s = state.overview.account(type)
    val color = type.uiColor()
    var renaming by remember { mutableStateOf(false) }
    var editingTarget by remember { mutableStateOf(false) }

    val history = buildList {
        state.incomes.forEach { r ->
            val amt = r.split.of(type)
            if (amt > 0) add(
                HistoryItem(
                    r.date, r.createdAt, "Income allocation",
                    "${r.date.format(DateShort)} · ${r.source} · ${Money.formatPercent(r.percentages.of(type))}%",
                    amt,
                ) { nav.navigate(Routes.income(id = r.id)) }
            )
        }
        state.ledger.filter { it.account == type }.forEach { l ->
            val detail = l.expenseCategory ?: l.investmentType
            add(
                HistoryItem(
                    l.date, l.createdAt, l.description.ifBlank { l.type.label },
                    listOfNotNull(l.date.format(DateShort), l.type.label, detail?.takeIf { it != l.description })
                        .joinToString(" · "),
                    l.signedAmount,
                ) {
                    val ref = l.referenceId
                    val loanId = state.loanIdByTx[l.id]
                    when {
                        l.type.isLoan && loanId != null -> nav.navigate(Routes.loan(loanId))
                        l.type.isLoan -> Unit
                        l.type.isTransfer && ref != null -> nav.navigate(Routes.transfer(ref = ref))
                        else -> nav.navigate(Routes.entry(type, id = l.id))
                    }
                }
            )
        }
    }.sortedWith(compareByDescending<HistoryItem> { it.date }.thenByDescending { it.sortKey })

    Column(Modifier.fillMaxSize()) {
        ScreenTopBar(
            title = state.name(type),
            onBack = { nav.popBackStack() },
            actions = {
                IconButton(onClick = { renaming = true }) { Icon(Icons.Filled.Edit, contentDescription = "Rename account") }
            },
        )
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            SectionCard {
                Text(
                    if (type == AccountType.LIVING || type == AccountType.GIVING) "Remaining" else "Current balance",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Text(
                    fmt(s.balance),
                    style = MaterialTheme.typography.headlineMedium,
                    color = if (s.balance < 0) MaterialTheme.colorScheme.error else color,
                )
                Spacer(Modifier.height(10.dp))
                ProgressBar(s.usedFraction, color)
                Spacer(Modifier.height(10.dp))
                LabelValue("Allocated from income", fmt(s.allocated))
                LabelValue(usedLabel(type), fmt(s.used))
                if (s.otherIn > 0) LabelValue("Other money in (transfers, deposits, returns, loans)", fmt(s.otherIn))
                if (s.otherOut > 0) LabelValue("Other money out (transfers, loans)", fmt(s.otherOut))
                if (s.balance < 0) {
                    Text(
                        "This account is overspent. Consider moving money in from another account.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                }
            }

            if (type == AccountType.SAVINGS) {
                SectionCard(title = "Savings target") {
                    val target = state.settings.savingsTargetMinor
                    if (target != null && target > 0) {
                        LabelValue("Target", fmt(target))
                        LabelValue("Progress", "${(s.balance.coerceAtLeast(0) * 100 / target)}%")
                        ProgressBar((s.balance.toFloat() / target).coerceIn(0f, 1f), color)
                    } else {
                        EmptyNote("No savings target set yet.")
                    }
                    TextButton(onClick = { editingTarget = true }) { Text(if (target == null) "Set target" else "Change target") }
                }
            }

            if (type == AccountType.INVESTMENTS) {
                SectionCard(title = "Investment tracking") {
                    LabelValue("Total contributions", fmt(state.overview.investmentContributions))
                    LabelValue("Total returns recorded", fmt(state.overview.investmentReturns))
                    LabelValue("Capital cashed out", fmt(state.overview.investmentCashouts))
                    LabelValue("Recorded investment value", fmt(state.overview.investmentHoldingsValue), emphasize = true)
                    Text(
                        "Contributions are not profit. Record returns separately when an investment pays you. " +
                            "To update what an investment is worth now, open the contribution and enter its current value.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            // Actions for this envelope
            val actions = TxType.manualTypesFor(type)
            actions.chunked(2).forEach { pair ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    pair.forEach { t ->
                        FilledTonalButton(
                            onClick = { nav.navigate(Routes.entry(type, t)) },
                            modifier = Modifier.weight(1f),
                        ) { Text(actionLabel(t), maxLines = 1) }
                    }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
            OutlinedButton(onClick = { nav.navigate(Routes.transfer(from = type)) }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.AutoMirrored.Filled.CompareArrows, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Transfer to another account")
            }

            SectionCard(title = "Transaction history") {
                if (history.isEmpty()) EmptyNote("Nothing recorded in this account yet.")
                history.forEachIndexed { i, h ->
                    if (i > 0) HorizontalDivider()
                    TxRow(
                        title = h.title,
                        subtitle = h.subtitle,
                        amount = (if (h.signed >= 0) "+" else "−") + fmt(kotlin.math.abs(h.signed)),
                        amountColor = if (h.signed >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                        onClick = h.onClick,
                    )
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (renaming) {
        var name by remember { mutableStateOf(state.name(type)) }
        AlertDialog(
            onDismissRequest = { renaming = false },
            title = { Text("Rename account") },
            text = { OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, label = { Text("Name") }) },
            confirmButton = {
                TextButton(onClick = {
                    vm.renameAccount(type, name) { err -> if (err != null) Toast.makeText(context, err, Toast.LENGTH_SHORT).show() }
                    renaming = false
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { renaming = false }) { Text("Cancel") } },
        )
    }

    if (editingTarget) {
        val decimals = state.settings.currencyDecimals
        var text by remember {
            mutableStateOf(state.settings.savingsTargetMinor?.let { Money.toInput(it, decimals) } ?: "")
        }
        AlertDialog(
            onDismissRequest = { editingTarget = false },
            title = { Text("Savings target") },
            text = {
                Column {
                    AmountField(text, { text = it }, "Target amount", decimals = decimals, optional = true)
                    Text("Leave empty to remove the target.", style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.setSavingsTarget(text) { err ->
                        if (err != null) Toast.makeText(context, err, Toast.LENGTH_SHORT).show() else editingTarget = false
                    }
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { editingTarget = false }) { Text("Cancel") } },
        )
    }
}

fun actionLabel(t: TxType): String = when (t) {
    TxType.EXPENSE -> "Record expense"
    TxType.WITHDRAWAL -> "Withdraw"
    TxType.DEPOSIT -> "Add deposit"
    TxType.INVESTMENT_CONTRIBUTION -> "Invest money"
    TxType.INVESTMENT_RETURN -> "Record return"
    TxType.INVESTMENT_CASHOUT -> "Cash out"
    TxType.DEBT_REPAYMENT -> "Repay debt"
    TxType.FAMILY_SUPPORT -> "Family support"
    TxType.DONATION -> "Donation"
    TxType.CHARITY -> "Charity"
    TxType.OTHER_GIVING -> "Other giving"
    else -> t.label
}

/** Signed display helper used by forms. */
fun TxType.isMoneyIn(): Boolean = direction == TxDirection.IN
