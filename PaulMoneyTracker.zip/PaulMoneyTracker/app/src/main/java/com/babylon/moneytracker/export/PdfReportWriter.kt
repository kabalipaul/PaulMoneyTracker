package com.babylon.moneytracker.export

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.babylon.moneytracker.domain.AccountType
import com.babylon.moneytracker.domain.FullReport
import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Builds an A4 PDF report with Android's built-in PdfDocument (no third-party library). */
class PdfReportWriter(
    private val money: (Long) -> String,
    private val accountName: (AccountType) -> String,
) {
    private val forest = Color.rgb(0x16, 0x4B, 0x35)
    private val gold = Color.rgb(0xD6, 0xA8, 0x4B)
    private val charcoal = Color.rgb(0x25, 0x2B, 0x27)
    private val lightGreen = Color.rgb(0xE5, 0xF1, 0xE9)
    private val grey = Color.rgb(0x6B, 0x72, 0x6E)
    private val accountColors = mapOf(
        AccountType.LIVING to forest,
        AccountType.SAVINGS to gold,
        AccountType.INVESTMENTS to Color.rgb(0x4E, 0x8F, 0x6A),
        AccountType.GIVING to Color.rgb(0x9C, 0x7A, 0x3C),
    )

    fun write(report: FullReport, file: File) {
        val doc = PdfDocument()
        val w = PageWriter(doc)
        val r = report

        w.title("PaulMoneyTracker", "Financial report · ${r.range.label()}")

        val pos = r.position.end
        w.heading("Statement of financial position · ${pos.date.format(DateTimeFormatter.ofPattern("d MMM yyyy", Locale.US))}")
        w.subheading("What you own (assets)")
        AccountType.entries.forEach { w.row("Money in ${accountName(it)}", money(pos.cashIn(it))) }
        w.row("Investments held (recorded value)", money(pos.investmentsHeld))
        w.row("Money owed to me", money(pos.receivables))
        w.row("Total assets", money(pos.totalAssets), bold = true)
        w.subheading("What you owe (liabilities)")
        w.row("Loans and debts outstanding", money(pos.liabilities))
        w.row("Total liabilities", money(pos.liabilities), bold = true)
        w.space()
        w.row("NET WORTH", money(pos.netWorth), bold = true)
        w.row("Net worth at start of period", money(r.position.start.netWorth))
        w.row("Change over the period", money(r.position.netWorthChange))
        w.row("Debt compared with assets", "${(pos.debtRatio * 100).toInt()}%")

        w.heading("Overall financial progress")
        w.row("Total income", money(r.overall.totalIncome), bold = true)
        w.row("Living expenses", money(r.overall.livingExpenses))
        w.row("Allocated to savings", money(r.overall.savingsAllocated))
        w.row("Investment contributions", money(r.overall.investmentContributions))
        w.row("Debt repayment / giving", money(r.overall.giving))
        w.row("Wealth at start of period", money(r.overall.wealthAtStart))
        w.row("Wealth at end of period", money(r.overall.wealthAtEnd), bold = true)
        w.note("Wealth = savings balance + uninvested investment cash + recorded investment value.")
        w.space()
        w.subheading("Balances at end of period")
        AccountType.entries.forEach { w.row(accountName(it), money(r.overall.balancesAtEnd[it] ?: 0)) }

        w.heading("Income")
        w.row("Total income received", money(r.income.total), bold = true)
        w.row("Number of income transactions", r.income.count.toString())
        w.row("Average per transaction", money(r.income.averagePerTransaction))
        val df = DateTimeFormatter.ofPattern("d MMM yyyy", Locale.US)
        w.row("Highest income day", r.income.highestDay?.let { "${it.date.format(df)} · ${money(it.amount)}" } ?: "—")
        w.row("Lowest income day", r.income.lowestDay?.let { "${it.date.format(df)} · ${money(it.amount)}" } ?: "—")
        if (r.income.bySource.isNotEmpty()) {
            w.subheading("Income by source")
            w.bars(r.income.bySource.map { it.name to it.amount }, forest)
        }
        if (r.income.monthly.size > 1) {
            w.subheading("Monthly income")
            w.bars(r.income.monthly.map { it.label to it.value }, forest)
        }

        w.heading("Allocation")
        w.allocationBar(AccountType.entries.map { r.allocation.split.of(it) }, AccountType.entries.map { accountColors.getValue(it) })
        AccountType.entries.forEach {
            val pct = (r.allocation.shares[it] ?: 0f) * 100
            w.row("${accountName(it)} (${String.format(Locale.US, "%.1f", pct)}%)", money(r.allocation.split.of(it)))
        }

        w.heading("Expenditure (living expenses)")
        w.row("Total expenses", money(r.expenditure.total), bold = true)
        w.row("Living allocation received in period", money(r.expenditure.livingAllocatedInPeriod))
        w.row("Remaining from period's allocation", money(r.expenditure.remainingInPeriod))
        w.row("Living Expenses balance at end", money(r.expenditure.livingBalanceAtEnd))
        if (r.expenditure.byCategory.isNotEmpty()) {
            w.subheading("Expenses by category")
            w.bars(r.expenditure.byCategory.map { it.name to it.amount }, gold)
        }

        w.heading("Savings")
        w.row("Contributions (allocations, deposits, transfers in)", money(r.savings.contributions))
        w.row("Withdrawals and transfers out", money(r.savings.withdrawals))
        w.row("Savings balance at end", money(r.savings.balanceAtEnd), bold = true)
        r.savings.target?.let { t ->
            w.row("Savings target", money(t))
            w.row("Progress towards target", "${((r.savings.targetProgress ?: 0f) * 100).toInt()}%")
        }

        w.heading("Investments")
        w.row("Contributions (money invested)", money(r.investment.contributions), bold = true)
        w.row("Returns recorded (profit / interest)", money(r.investment.returns))
        w.row("Capital cashed out", money(r.investment.cashouts))
        w.row("Recorded investment value at end", money(r.investment.holdingsValueAtEnd))
        w.note(
            "Contributions are money you put in; returns are what the investments paid you. " +
                "${r.investment.contributionsWithValue} of ${r.investment.totalContributionsCount} contributions " +
                "in this period have an updated value recorded; the rest are counted at cost."
        )
        if (r.investment.byType.isNotEmpty()) {
            w.subheading("Contributions by type")
            w.bars(r.investment.byType.map { it.name to it.amount }, accountColors.getValue(AccountType.INVESTMENTS))
        }

        // ---------- Loans ----------
        val lr = r.loans
        val df2 = DateTimeFormatter.ofPattern("d MMM yyyy", Locale.US)
        w.heading("Loans and debts")
        w.row("Outstanding debts (I owe)", money(lr.borrowing.outstandingAtEnd), bold = true)
        w.row("Outstanding receivables (owed to me)", money(lr.lending.outstandingAtEnd), bold = true)
        w.row("Net loan position", money(lr.netPositionAtEnd))
        w.row("Money borrowed in period", money(lr.borrowing.newPrincipal))
        w.row("Repayments made in period", money(lr.borrowing.repaidInPeriod))
        w.row("Money lent in period", money(lr.lending.newPrincipal))
        w.row("Repayments received in period", money(lr.lending.repaidInPeriod))
        if (lr.lending.interestInPeriod > 0) w.row("Interest earned in period", money(lr.lending.interestInPeriod))
        if (lr.borrowing.interestInPeriod > 0) w.row("Interest paid in period", money(lr.borrowing.interestInPeriod))
        w.note("Borrowed money is not income and lent money is not an expense; repayments are not counted as spending.")
        listOf("By creditor" to lr.borrowing, "By debtor" to lr.lending).forEach { (label, side) ->
            if (side.byPerson.isNotEmpty()) {
                w.subheading(label)
                side.byPerson.forEach { p ->
                    w.row(
                        p.name + (p.nextDue?.let { " (due ${it.format(df2)})" } ?: ""),
                        "${money(p.outstanding)} of ${money(p.principal)}",
                    )
                }
            }
        }
        val overdue = lr.borrowing.overdue + lr.lending.overdue
        if (overdue.isNotEmpty()) {
            w.subheading("Overdue")
            overdue.forEach { s ->
                w.row("${s.loan.counterparty} (due ${s.loan.dueDate?.format(df2) ?: "-"})", money(s.totalOutstanding))
            }
        }

        w.finish()
        file.parentFile?.mkdirs()
        file.outputStream().use { doc.writeTo(it) }
        doc.close()
    }

    private inner class PageWriter(private val doc: PdfDocument) {
        private val pageW = 595
        private val pageH = 842
        private val margin = 40f
        private val contentW = pageW - margin * 2
        private var pageNo = 0
        private var page: PdfDocument.Page? = null
        private lateinit var canvas: Canvas
        private var y = 0f

        private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = charcoal; textSize = 10.5f }
        private val bold = Paint(text).apply { typeface = Typeface.DEFAULT_BOLD }
        private val small = Paint(text).apply { color = grey; textSize = 8.5f }
        private val fill = Paint(Paint.ANTI_ALIAS_FLAG)

        init {
            newPage()
        }

        private fun newPage() {
            page?.let { doc.finishPage(it) }
            pageNo++
            val p = doc.startPage(PdfDocument.PageInfo.Builder(pageW, pageH, pageNo).create())
            page = p
            canvas = p.canvas
            y = margin
            val generated = LocalDateTime.now().format(DateTimeFormatter.ofPattern("d MMM yyyy HH:mm", Locale.US))
            canvas.drawText("Generated $generated · page $pageNo", margin, pageH - 20f, small)
        }

        private fun ensure(h: Float) {
            if (y + h > pageH - margin) newPage()
        }

        fun title(main: String, sub: String) {
            fill.color = forest
            canvas.drawRect(0f, 0f, pageW.toFloat(), 86f, fill)
            canvas.drawText(main, margin, 44f, Paint(bold).apply { color = Color.WHITE; textSize = 20f })
            canvas.drawText(sub, margin, 66f, Paint(text).apply { color = lightGreen; textSize = 11f })
            y = 112f
        }

        fun heading(t: String) {
            ensure(60f)
            y += 10f
            canvas.drawText(t, margin, y, Paint(bold).apply { color = forest; textSize = 14f })
            y += 6f
            fill.color = gold
            canvas.drawRect(margin, y, margin + 40f, y + 2f, fill)
            y += 16f
        }

        fun subheading(t: String) {
            ensure(30f)
            y += 4f
            canvas.drawText(t, margin, y, Paint(bold).apply { textSize = 11f })
            y += 14f
        }

        fun row(label: String, value: String, bold: Boolean = false) {
            ensure(16f)
            val p = if (bold) this.bold else text
            canvas.drawText(fit(label, contentW * 0.6f, p), margin, y, p)
            canvas.drawText(value, pageW - margin - p.measureText(value), y, p)
            y += 16f
        }

        fun note(t: String) {
            wrap(t, contentW, small).forEach { line ->
                ensure(12f); canvas.drawText(line, margin, y, small); y += 12f
            }
            y += 2f
        }

        fun space() {
            y += 6f
        }

        fun bars(items: List<Pair<String, Long>>, color: Int) {
            val max = items.maxOfOrNull { it.second }?.takeIf { it > 0 } ?: return
            val labelW = 130f
            val valueW = 110f
            val barMax = contentW - labelW - valueW
            items.forEach { (label, v) ->
                ensure(18f)
                canvas.drawText(fit(label, labelW - 6f, text), margin, y, text)
                fill.color = lightGreen
                canvas.drawRoundRect(RectF(margin + labelW, y - 9f, margin + labelW + barMax, y + 1f), 3f, 3f, fill)
                fill.color = color
                val bw = (barMax * (v.toDouble() / max)).toFloat().coerceAtLeast(2f)
                canvas.drawRoundRect(RectF(margin + labelW, y - 9f, margin + labelW + bw, y + 1f), 3f, 3f, fill)
                val s = money(v)
                canvas.drawText(s, pageW - margin - text.measureText(s), y, text)
                y += 18f
            }
            y += 4f
        }

        fun allocationBar(values: List<Long>, colors: List<Int>) {
            val total = values.sum()
            ensure(28f)
            var x = margin
            if (total <= 0) {
                fill.color = lightGreen
                canvas.drawRect(margin, y - 10f, margin + contentW, y + 4f, fill)
            } else {
                values.forEachIndexed { i, v ->
                    val w = (contentW * (v.toDouble() / total)).toFloat()
                    fill.color = colors[i]
                    canvas.drawRect(x, y - 10f, x + w, y + 4f, fill)
                    x += w
                }
            }
            y += 22f
        }

        fun finish() {
            page?.let { doc.finishPage(it) }
            page = null
        }

        private fun fit(s: String, maxW: Float, p: Paint): String {
            if (p.measureText(s) <= maxW) return s
            var t = s
            while (t.isNotEmpty() && p.measureText("$t…") > maxW) t = t.dropLast(1)
            return "$t…"
        }

        private fun wrap(s: String, maxW: Float, p: Paint): List<String> {
            val lines = mutableListOf<String>()
            var cur = ""
            s.split(" ").forEach { word ->
                val next = if (cur.isEmpty()) word else "$cur $word"
                if (p.measureText(next) > maxW && cur.isNotEmpty()) {
                    lines += cur; cur = word
                } else cur = next
            }
            if (cur.isNotEmpty()) lines += cur
            return lines
        }
    }
}
