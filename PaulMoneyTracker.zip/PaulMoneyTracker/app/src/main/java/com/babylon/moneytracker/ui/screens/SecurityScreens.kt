package com.babylon.moneytracker.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.navigation.NavController
import com.babylon.moneytracker.security.AppLock
import com.babylon.moneytracker.security.PinHasher
import com.babylon.moneytracker.security.PinResult
import com.babylon.moneytracker.ui.components.ScreenTopBar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Shows the system fingerprint / face dialog. */
fun showBiometricPrompt(activity: FragmentActivity, onSuccess: () -> Unit) {
    val prompt = BiometricPrompt(
        activity,
        ContextCompat.getMainExecutor(activity),
        object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                onSuccess()
            }
        },
    )
    val info = BiometricPrompt.PromptInfo.Builder()
        .setTitle("Unlock PaulMoneyTracker")
        .setSubtitle("Use your fingerprint or face")
        .setNegativeButtonText("Use PIN")
        .setAllowedAuthenticators(BIOMETRIC_WEAK)
        .build()
    prompt.authenticate(info)
}

@Composable
private fun PinDots(length: Int, filled: Int) {
    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
        repeat(length) { i ->
            Box(
                Modifier
                    .size(14.dp)
                    .clip(CircleShape)
                    .then(
                        if (i < filled) Modifier.background(MaterialTheme.colorScheme.primary)
                        else Modifier.border(1.5.dp, MaterialTheme.colorScheme.outline, CircleShape)
                    )
            )
        }
    }
}

@Composable
private fun PadKey(modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        modifier
            .size(72.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.surfaceContainerHigh)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { content() }
}

/** Number pad. [leftKey] fills the bottom-left slot (fingerprint or OK button). */
@Composable
private fun PinPad(
    enabled: Boolean,
    onDigit: (Char) -> Unit,
    onDelete: () -> Unit,
    leftKey: (@Composable () -> Unit)? = null,
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        listOf("123", "456", "789").forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                row.forEach { d ->
                    PadKey(enabled = enabled, onClick = { onDigit(d) }) {
                        Text(d.toString(), fontSize = 26.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(22.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(72.dp), contentAlignment = Alignment.Center) { leftKey?.invoke() }
            PadKey(enabled = enabled, onClick = { onDigit('0') }) {
                Text("0", fontSize = 26.sp, fontWeight = FontWeight.Medium)
            }
            Box(Modifier.size(72.dp).clip(CircleShape).clickable(enabled = enabled, onClick = onDelete), contentAlignment = Alignment.Center) {
                Icon(Icons.AutoMirrored.Filled.Backspace, contentDescription = "Delete")
            }
        }
    }
}

private fun secondsText(ms: Long): String {
    val s = (ms + 999) / 1000
    return if (s >= 60) "${s / 60} min ${s % 60} s" else "$s s"
}

// =====================================================================
// Lock screen shown when the app opens or returns from the background
// =====================================================================

@Composable
fun LockScreen(onUnlocked: () -> Unit) {
    val context = LocalContext.current
    val activity = context as? FragmentActivity
    val scope = rememberCoroutineScope()
    val length = remember { AppLock.pinLength(context) }
    val bio = remember { activity != null && AppLock.biometricEnabled(context) }
    var pin by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var checking by remember { mutableStateOf(false) }
    var lockLeft by remember { mutableLongStateOf(AppLock.lockoutRemaining(context)) }
    var showForgot by remember { mutableStateOf(false) }

    BackHandler { activity?.moveTaskToBack(true) }

    LaunchedEffect(lockLeft > 0) {
        while (lockLeft > 0) {
            delay(1_000)
            lockLeft = AppLock.lockoutRemaining(context)
        }
    }
    LaunchedEffect(Unit) {
        if (bio && activity != null && lockLeft == 0L) showBiometricPrompt(activity, onUnlocked)
    }

    fun submit(entered: String) {
        checking = true
        scope.launch {
            val r = withContext(Dispatchers.Default) { AppLock.verify(context, entered) }
            checking = false
            pin = ""
            when (r) {
                PinResult.Success -> onUnlocked()
                is PinResult.Wrong -> message = "Wrong PIN. ${r.attemptsLeftBeforePause} more tries before a short pause."
                is PinResult.LockedOut -> {
                    message = null
                    lockLeft = r.millisLeft
                }
            }
        }
    }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Icon(Icons.Filled.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(40.dp))
            Spacer(Modifier.height(12.dp))
            Text("PaulMoneyTracker", style = MaterialTheme.typography.titleLarge)
            Text("Enter your PIN", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(20.dp))
            PinDots(length, pin.length)
            Spacer(Modifier.height(12.dp))
            Text(
                when {
                    lockLeft > 0 -> "Too many wrong tries. Try again in ${secondsText(lockLeft)}."
                    message != null -> message!!
                    else -> " "
                },
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(16.dp))
            PinPad(
                enabled = !checking && lockLeft == 0L,
                onDigit = { d ->
                    if (pin.length < length) {
                        pin += d
                        if (pin.length == length) submit(pin)
                    }
                },
                onDelete = { pin = pin.dropLast(1) },
                leftKey = if (bio && activity != null) {
                    {
                        PadKey(onClick = { showBiometricPrompt(activity, onUnlocked) }) {
                            Icon(Icons.Filled.Fingerprint, contentDescription = "Use fingerprint")
                        }
                    }
                } else null,
            )
            Spacer(Modifier.height(16.dp))
            TextButton(onClick = { showForgot = true }) { Text("Forgot PIN?") }
        }
    }

    if (showForgot) {
        AlertDialog(
            onDismissRequest = { showForgot = false },
            title = { Text("Forgot your PIN?") },
            text = {
                Text(
                    "For your protection the PIN cannot be recovered or bypassed. To start again, clear the app's " +
                        "data: Android Settings → Apps → PaulMoneyTracker → Storage → Clear data. This deletes every " +
                        "record on this phone. Then open the app and restore your latest encrypted backup."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    showForgot = false
                    context.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }) { Text("Open app settings") }
            },
            dismissButton = { TextButton(onClick = { showForgot = false }) { Text("Close") } },
        )
    }
}

// =====================================================================
// Set up, change or remove the PIN
// =====================================================================

/** [mode]: "set", "change" or "remove". */
@Composable
fun PinSetupScreen(nav: NavController, mode: String) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    // Steps: verify (current PIN) -> new -> confirm
    var step by remember { mutableStateOf(if (mode == "set" || !AppLock.isEnabled(context)) "new" else "verify") }
    var pin by remember { mutableStateOf("") }
    var firstPin by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    val currentLength = remember { AppLock.pinLength(context) }

    fun finishWith(text: String) {
        Toast.makeText(context, text, Toast.LENGTH_SHORT).show()
        nav.popBackStack()
    }

    fun verifyCurrent(entered: String) {
        busy = true
        scope.launch {
            val r = withContext(Dispatchers.Default) { AppLock.verify(context, entered) }
            busy = false
            pin = ""
            when (r) {
                PinResult.Success -> {
                    if (mode == "remove") {
                        AppLock.removePin(context)
                        finishWith("App lock turned off")
                    } else {
                        step = "new"; message = null
                    }
                }
                is PinResult.Wrong -> message = "Wrong PIN. ${r.attemptsLeftBeforePause} more tries before a pause."
                is PinResult.LockedOut -> message = "Too many wrong tries. Try again in ${secondsText(r.millisLeft)}."
            }
        }
    }

    fun confirmNew() {
        if (pin != firstPin) {
            message = "The PINs didn't match. Start again."
            pin = ""; firstPin = ""; step = "new"
            return
        }
        busy = true
        val chosen = pin
        scope.launch {
            withContext(Dispatchers.Default) { AppLock.setPin(context, chosen) }
            busy = false
            finishWith(if (mode == "change") "PIN changed" else "App lock is on")
        }
    }

    val title = when (mode) {
        "remove" -> "Turn off app lock"
        "change" -> "Change PIN"
        else -> "Set up app lock"
    }
    val prompt = when (step) {
        "verify" -> "Enter your current PIN"
        "new" -> "Choose a new PIN (4–6 digits)"
        else -> "Enter the new PIN again"
    }
    val dots = when (step) {
        "verify" -> currentLength
        "confirm" -> firstPin.length
        else -> maxOf(4, pin.length)
    }

    Column(Modifier.fillMaxSize()) {
        ScreenTopBar(title, onBack = { nav.popBackStack() })
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(prompt, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(20.dp))
            PinDots(dots, pin.length)
            Spacer(Modifier.height(12.dp))
            Text(
                message ?: " ",
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(16.dp))
            PinPad(
                enabled = !busy,
                onDigit = { d ->
                    when (step) {
                        "verify" -> if (pin.length < currentLength) {
                            pin += d
                            if (pin.length == currentLength) verifyCurrent(pin)
                        }
                        "new" -> if (pin.length < 6) pin += d
                        else -> if (pin.length < firstPin.length) {
                            pin += d
                            if (pin.length == firstPin.length) confirmNew()
                        }
                    }
                },
                onDelete = { pin = pin.dropLast(1) },
                leftKey = if (step == "new") {
                    {
                        PadKey(enabled = PinHasher.isValidPin(pin), onClick = {
                            firstPin = pin; pin = ""; message = null; step = "confirm"
                        }) { Text("OK", fontWeight = FontWeight.Bold) }
                    }
                } else null,
            )
            Spacer(Modifier.height(16.dp))
            if (step == "new") {
                Text(
                    "Avoid easy PINs like 1234 or your birth year. If you forget it, the only way back in is to clear the " +
                        "app's data and restore a backup.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().width(320.dp),
                )
            }
        }
    }
}
