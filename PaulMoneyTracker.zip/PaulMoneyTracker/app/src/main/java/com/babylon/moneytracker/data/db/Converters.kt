package com.babylon.moneytracker.data.db

import androidx.room.TypeConverter
import com.babylon.moneytracker.domain.AccountType
import com.babylon.moneytracker.domain.GoalMetric
import com.babylon.moneytracker.domain.InterestPeriod
import com.babylon.moneytracker.domain.LoanDirection
import com.babylon.moneytracker.domain.RepaymentOrder
import com.babylon.moneytracker.domain.ThemeMode
import com.babylon.moneytracker.domain.TxType

/** Enums are stored by name so the database stays readable and reorder-safe. */
class Converters {
    @TypeConverter fun accountTypeToString(v: AccountType): String = v.name
    @TypeConverter fun stringToAccountType(v: String): AccountType = AccountType.valueOf(v)

    @TypeConverter fun txTypeToString(v: TxType): String = v.name
    @TypeConverter fun stringToTxType(v: String): TxType = TxType.valueOf(v)

    @TypeConverter fun goalMetricToString(v: GoalMetric): String = v.name
    @TypeConverter fun stringToGoalMetric(v: String): GoalMetric = GoalMetric.valueOf(v)

    @TypeConverter fun themeToString(v: ThemeMode): String = v.name
    @TypeConverter fun stringToTheme(v: String): ThemeMode = ThemeMode.valueOf(v)

    @TypeConverter fun loanDirectionToString(v: LoanDirection): String = v.name
    @TypeConverter fun stringToLoanDirection(v: String): LoanDirection = LoanDirection.valueOf(v)

    @TypeConverter fun interestPeriodToString(v: InterestPeriod): String = v.name
    @TypeConverter fun stringToInterestPeriod(v: String): InterestPeriod = InterestPeriod.valueOf(v)

    @TypeConverter fun repaymentOrderToString(v: RepaymentOrder): String = v.name
    @TypeConverter fun stringToRepaymentOrder(v: String): RepaymentOrder = RepaymentOrder.valueOf(v)
}
