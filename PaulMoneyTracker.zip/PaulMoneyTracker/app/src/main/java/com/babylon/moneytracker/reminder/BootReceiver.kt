package com.babylon.moneytracker.reminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.babylon.moneytracker.container
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** Re-aligns the daily reminder after a reboot, app update, or clock/time-zone change. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                ReminderScheduler.reschedule(context, context.container.settings.currentReminder())
            } finally {
                pending.finish()
            }
        }
    }
}
