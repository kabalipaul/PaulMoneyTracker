package com.babylon.moneytracker.data

import com.babylon.moneytracker.data.db.AppDatabase
import com.babylon.moneytracker.data.db.AppSettings
import com.babylon.moneytracker.data.db.ReminderSettings
import com.babylon.moneytracker.domain.Percentages
import com.babylon.moneytracker.domain.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class SettingsRepository(db: AppDatabase) {
    private val dao = db.settingsDao()

    val settings: Flow<AppSettings> = dao.observeSettings().map { it ?: AppSettings() }
    val reminder: Flow<ReminderSettings> = dao.observeReminder().map { it ?: ReminderSettings() }

    suspend fun current(): AppSettings = dao.getSettings() ?: AppSettings()
    suspend fun currentReminder(): ReminderSettings = dao.getReminder() ?: ReminderSettings()

    /** Applies to income recorded from now on only; existing entries keep their own percentages. */
    suspend fun setPercentages(p: Percentages) {
        require(p.isValid) { "Percentages must total exactly 100%" }
        dao.saveSettings(
            current().copy(livingBp = p.living, savingsBp = p.savings, investmentsBp = p.investments, givingBp = p.giving)
        )
    }

    suspend fun setCurrency(code: String, symbol: String, decimals: Int) {
        dao.saveSettings(
            current().copy(
                currencyCode = code.trim().uppercase().ifBlank { "UGX" },
                currencySymbol = symbol.trim(),
                currencyDecimals = decimals.coerceIn(0, 2),
            )
        )
    }

    suspend fun setTheme(mode: ThemeMode) = dao.saveSettings(current().copy(themeMode = mode))

    suspend fun setSavingsTarget(target: Long?) =
        dao.saveSettings(current().copy(savingsTargetMinor = target?.takeIf { it > 0 }))

    suspend fun saveReminder(r: ReminderSettings) = dao.saveReminder(r.copy(id = 1))
}
