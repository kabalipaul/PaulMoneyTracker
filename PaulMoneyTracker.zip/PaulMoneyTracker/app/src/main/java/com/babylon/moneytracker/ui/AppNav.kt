package com.babylon.moneytracker.ui

import android.Manifest
import android.content.Context
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.babylon.moneytracker.domain.AccountType
import com.babylon.moneytracker.domain.LoanDirection
import com.babylon.moneytracker.domain.TxType
import com.babylon.moneytracker.reminder.NotificationHelper
import com.babylon.moneytracker.ui.components.LocalMoney
import com.babylon.moneytracker.ui.components.MoneyFmt
import com.babylon.moneytracker.ui.screens.AccountDetailScreen
import com.babylon.moneytracker.ui.screens.AccountsScreen
import com.babylon.moneytracker.ui.screens.AllocationSettingsScreen
import com.babylon.moneytracker.ui.screens.CalendarScreen
import com.babylon.moneytracker.ui.screens.EntryFormScreen
import com.babylon.moneytracker.ui.screens.GoalsScreen
import com.babylon.moneytracker.ui.screens.HomeScreen
import com.babylon.moneytracker.ui.screens.IncomeFormScreen
import com.babylon.moneytracker.ui.screens.LoanDetailScreen
import com.babylon.moneytracker.ui.screens.LoanFormScreen
import com.babylon.moneytracker.ui.screens.LoanPaymentScreen
import com.babylon.moneytracker.ui.screens.LoansScreen
import com.babylon.moneytracker.ui.screens.LockScreen
import com.babylon.moneytracker.ui.screens.PinSetupScreen
import com.babylon.moneytracker.ui.screens.ReportsScreen
import com.babylon.moneytracker.ui.screens.SettingsScreen
import com.babylon.moneytracker.ui.screens.TransferScreen
import com.babylon.moneytracker.ui.theme.BabylonTheme
import java.time.LocalDate

object Routes {
    const val HOME = "home"
    const val CALENDAR = "calendar"
    const val ACCOUNTS = "accounts"
    const val REPORTS = "reports"
    const val GOALS = "goals"
    const val SETTINGS = "settings"
    const val ALLOCATION = "settings/allocation"
    const val INCOME = "income?id={id}&date={date}"
    const val ACCOUNT = "account/{type}"
    const val ENTRY = "entry/{account}?type={type}&id={id}"
    const val TRANSFER = "transfer?from={from}&ref={ref}"
    const val PIN_SETUP = "security/pin/{mode}"
    const val LOANS = "loans"
    const val LOAN = "loan/{id}"
    const val LOAN_FORM = "loanform/{direction}?id={id}"
    const val LOAN_PAYMENT = "loanpay/{loanId}?txId={txId}"

    fun pinSetup(mode: String) = "security/pin/$mode"
    fun loan(id: Long) = "loan/$id"
    fun loanForm(direction: LoanDirection, id: Long? = null) = "loanform/${direction.name}?id=${id ?: -1L}"
    fun loanPayment(loanId: Long, txId: Long? = null) = "loanpay/$loanId?txId=${txId ?: -1L}"

    fun income(id: Long? = null, date: LocalDate? = null): String =
        "income?id=${id ?: -1L}" + (date?.let { "&date=$it" } ?: "")

    fun account(type: AccountType) = "account/${type.name}"

    fun entry(account: AccountType, type: TxType? = null, id: Long? = null): String =
        "entry/${account.name}?id=${id ?: -1L}" + (type?.let { "&type=${it.name}" } ?: "")

    fun transfer(from: AccountType? = null, ref: String? = null): String {
        val params = listOfNotNull(from?.let { "from=${it.name}" }, ref?.let { "ref=$it" })
        return "transfer" + if (params.isEmpty()) "" else "?" + params.joinToString("&")
    }
}

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val tabs = listOf(
    Tab(Routes.HOME, "Home", Icons.Filled.Home),
    Tab(Routes.CALENDAR, "Calendar", Icons.Filled.CalendarMonth),
    Tab(Routes.ACCOUNTS, "Accounts", Icons.Filled.AccountBalanceWallet),
    Tab(Routes.LOANS, "Loans", Icons.Filled.Payments),
    Tab(Routes.REPORTS, "Reports", Icons.Filled.BarChart),
    Tab(Routes.GOALS, "Goals", Icons.Filled.Flag),
)

@Composable
fun BabylonAppRoot(
    openAddIncome: Boolean,
    onOpenHandled: () -> Unit,
    locked: Boolean = false,
    onUnlocked: () -> Unit = {},
) {
    val vm: MainViewModel = viewModel(factory = AppViewModels.Factory)
    val state by vm.state.collectAsStateWithLifecycle()

    BabylonTheme(state.settings.themeMode) {
        CompositionLocalProvider(
            LocalMoney provides MoneyFmt(state.settings.currencySymbol, state.settings.currencyDecimals)
        ) {
            val nav = rememberNavController()
            val backStack by nav.currentBackStackEntryAsState()
            val route = backStack?.destination?.route
            val onTab = tabs.any { it.route == route }
            // The Loans tab has its own "Add Loan / Add Debtor" button instead of "Add Income".
            val showIncomeFab = onTab && route != Routes.LOANS

            NotificationPermissionOnce(remindersOn = state.loaded && state.reminder.enabled && !locked)

            // A tapped reminder opens Add Income, but only once the app is unlocked.
            LaunchedEffect(openAddIncome, locked) {
                if (openAddIncome && !locked) {
                    nav.navigate(Routes.income())
                    onOpenHandled()
                }
            }

            Box(Modifier.fillMaxSize()) {
            // While locked, the app stays underneath (so you return to where you were)
            // but is hidden from screen readers and fully covered by the lock screen.
            Box(if (locked) Modifier.fillMaxSize().clearAndSetSemantics { } else Modifier.fillMaxSize()) {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                contentWindowInsets = WindowInsets.navigationBars,
                bottomBar = {
                    if (onTab) {
                        NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest) {
                            tabs.forEach { tab ->
                                NavigationBarItem(
                                    selected = route == tab.route,
                                    onClick = { nav.navigateTab(tab.route) },
                                    icon = { Icon(tab.icon, contentDescription = null) },
                                    label = { Text(tab.label, maxLines = 1, style = MaterialTheme.typography.labelSmall) },
                                )
                            }
                        }
                    }
                },
                floatingActionButton = {
                    if (showIncomeFab) {
                        ExtendedFloatingActionButton(
                            onClick = { nav.navigate(Routes.income()) },
                            icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                            text = { Text("Add Income") },
                            containerColor = MaterialTheme.colorScheme.primary,
                            contentColor = MaterialTheme.colorScheme.onPrimary,
                        )
                    }
                },
            ) { padding ->
                NavHost(nav, startDestination = Routes.HOME, modifier = Modifier.padding(padding)) {
                    composable(Routes.HOME) { HomeScreen(state, nav) }
                    composable(Routes.CALENDAR) { CalendarScreen(state, nav) }
                    composable(Routes.ACCOUNTS) { AccountsScreen(state, nav) }
                    composable(
                        Routes.PIN_SETUP,
                        arguments = listOf(navArgument("mode") { type = NavType.StringType }),
                    ) { entry -> PinSetupScreen(nav, entry.arguments?.getString("mode") ?: "set") }
                    composable(Routes.LOANS) { LoansScreen(state, nav) }
                    composable(
                        Routes.LOAN,
                        arguments = listOf(navArgument("id") { type = NavType.LongType }),
                    ) { entry ->
                        LoanDetailScreen(state, nav, entry.arguments?.getLong("id") ?: -1L)
                    }
                    composable(
                        Routes.LOAN_FORM,
                        arguments = listOf(
                            navArgument("direction") { type = NavType.StringType },
                            navArgument("id") { type = NavType.LongType; defaultValue = -1L },
                        ),
                    ) { entry ->
                        val dir = LoanDirection.valueOf(entry.arguments?.getString("direction") ?: LoanDirection.BORROWED.name)
                        val id = entry.arguments?.getLong("id")?.takeIf { it > 0 }
                        LoanFormScreen(state, vm, nav, dir, id)
                    }
                    composable(
                        Routes.LOAN_PAYMENT,
                        arguments = listOf(
                            navArgument("loanId") { type = NavType.LongType },
                            navArgument("txId") { type = NavType.LongType; defaultValue = -1L },
                        ),
                    ) { entry ->
                        val loanId = entry.arguments?.getLong("loanId") ?: -1L
                        val txId = entry.arguments?.getLong("txId")?.takeIf { it > 0 }
                        LoanPaymentScreen(state, vm, nav, loanId, txId)
                    }
                    composable(Routes.REPORTS) { ReportsScreen(state, nav) }
                    composable(Routes.GOALS) { GoalsScreen(state, vm) }
                    composable(Routes.SETTINGS) { SettingsScreen(state, nav) }
                    composable(Routes.ALLOCATION) { AllocationSettingsScreen(state, nav) }
                    composable(
                        Routes.INCOME,
                        arguments = listOf(
                            navArgument("id") { type = NavType.LongType; defaultValue = -1L },
                            navArgument("date") { type = NavType.StringType; nullable = true; defaultValue = null },
                        ),
                    ) { entry ->
                        val id = entry.arguments?.getLong("id")?.takeIf { it > 0 }
                        val date = entry.arguments?.getString("date")?.let { LocalDate.parse(it) }
                        IncomeFormScreen(state, vm, nav, id, date)
                    }
                    composable(
                        Routes.ACCOUNT,
                        arguments = listOf(navArgument("type") { type = NavType.StringType }),
                    ) { entry ->
                        val type = AccountType.valueOf(entry.arguments?.getString("type") ?: AccountType.LIVING.name)
                        AccountDetailScreen(state, vm, nav, type)
                    }
                    composable(
                        Routes.ENTRY,
                        arguments = listOf(
                            navArgument("account") { type = NavType.StringType },
                            navArgument("type") { type = NavType.StringType; nullable = true; defaultValue = null },
                            navArgument("id") { type = NavType.LongType; defaultValue = -1L },
                        ),
                    ) { entry ->
                        val account = AccountType.valueOf(entry.arguments?.getString("account") ?: AccountType.LIVING.name)
                        val txType = entry.arguments?.getString("type")?.let { TxType.valueOf(it) }
                        val id = entry.arguments?.getLong("id")?.takeIf { it > 0 }
                        EntryFormScreen(state, vm, nav, account, txType, id)
                    }
                    composable(
                        Routes.TRANSFER,
                        arguments = listOf(
                            navArgument("from") { type = NavType.StringType; nullable = true; defaultValue = null },
                            navArgument("ref") { type = NavType.StringType; nullable = true; defaultValue = null },
                        ),
                    ) { entry ->
                        val from = entry.arguments?.getString("from")?.let { AccountType.valueOf(it) }
                        val ref = entry.arguments?.getString("ref")
                        TransferScreen(state, vm, nav, from, ref)
                    }
                }
            }
            }
            if (locked) LockScreen(onUnlocked)
            }
        }
    }
}

private fun NavHostController.navigateTab(route: String) {
    navigate(route) {
        popUpTo(graph.findStartDestination().id) { saveState = true }
        launchSingleTop = true
        restoreState = true
    }
}

/** Asks for notification permission once on Android 13+, so daily reminders can be shown. */
@Composable
private fun NotificationPermissionOnce(remindersOn: Boolean) {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(remindersOn) {
        val prefs = context.getSharedPreferences("ui_flags", Context.MODE_PRIVATE)
        if (remindersOn && !NotificationHelper.canPost(context) && !prefs.getBoolean("asked_notifications", false)) {
            prefs.edit().putBoolean("asked_notifications", true).apply()
            launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}
