package com.babylon.moneytracker.reminder

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.babylon.moneytracker.container
import java.time.Duration
import java.time.LocalDate
import java.time.LocalTime

class ReminderWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val ctx = applicationContext
        val reminder = ctx.container.settings.currentReminder()
        if (!reminder.enabled) return Result.success()

        // If the phone was off and the job runs much later than planned, don't nag at the wrong time.
        val now = LocalTime.now()
        val target = LocalTime.of(reminder.hour, reminder.minute)
        val lateBy = Duration.between(target, now)
        val onTime = !lateBy.isNegative && lateBy.toHours() < 3

        if (onTime) {
            val recordedToday = ctx.container.finance.incomeCountOn(LocalDate.now()) > 0
            if (!recordedToday) {
                NotificationHelper.show(
                    ctx,
                    title = "Record today's income",
                    text = "A part of all you earn is yours to keep. Tap to record what you earned today.",
                    openAddIncome = true,
                )
            } else if (reminder.confirmWhenRecorded) {
                NotificationHelper.show(
                    ctx,
                    title = "Today's income is recorded",
                    text = "Well done. Your money has been divided into your four accounts.",
                    openAddIncome = false,
                )
            }
        }

        ReminderScheduler.scheduleNextFromWorker(ctx, reminder)
        return Result.success()
    }
}
