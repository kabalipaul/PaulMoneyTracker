package com.babylon.moneytracker.security

import java.nio.ByteBuffer
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.AEADBadTagException
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

class WrongPasswordException : Exception("Wrong password, or the backup file is damaged.")

/**
 * Password-protected backups. Pure JVM code, unit-tested.
 *
 * File layout (all integers big-endian):
 *   "PMTBAK" (6 bytes) | version (1) | iterations (4) | salt (16) | iv (12) | AES-256-GCM ciphertext + 16-byte tag
 *
 * The key is derived from the password with PBKDF2-HMAC-SHA256. Everything before
 * the ciphertext is authenticated too, so any change to the file is detected.
 * The password is never stored anywhere.
 */
object BackupCrypto {
    private val MAGIC = "PMTBAK".toByteArray(Charsets.US_ASCII)
    private const val VERSION: Byte = 1
    const val ITERATIONS = 150_000
    private const val SALT_LEN = 16
    private const val IV_LEN = 12
    private const val HEADER_LEN = 6 + 1 + 4 + SALT_LEN + IV_LEN
    const val MIN_PASSWORD = 6

    private val random = SecureRandom()

    fun isEncrypted(header: ByteArray): Boolean =
        header.size >= MAGIC.size && header.copyOfRange(0, MAGIC.size).contentEquals(MAGIC)

    private fun key(password: CharArray, salt: ByteArray, iterations: Int): SecretKeySpec {
        val spec = PBEKeySpec(password, salt, iterations, 256)
        try {
            val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
            return SecretKeySpec(bytes, "AES")
        } finally {
            spec.clearPassword()
        }
    }

    fun encrypt(plain: ByteArray, password: CharArray, iterations: Int = ITERATIONS): ByteArray {
        require(password.size >= MIN_PASSWORD) { "Use a password of at least $MIN_PASSWORD characters" }
        val salt = ByteArray(SALT_LEN).also { random.nextBytes(it) }
        val iv = ByteArray(IV_LEN).also { random.nextBytes(it) }
        val header = ByteBuffer.allocate(HEADER_LEN)
            .put(MAGIC).put(VERSION).putInt(iterations).put(salt).put(iv).array()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key(password, salt, iterations), GCMParameterSpec(128, iv))
        cipher.updateAAD(header)
        return header + cipher.doFinal(plain)
    }

    fun decrypt(data: ByteArray, password: CharArray): ByteArray {
        if (!isEncrypted(data) || data.size < HEADER_LEN + 16) throw WrongPasswordException()
        val buf = ByteBuffer.wrap(data)
        buf.position(MAGIC.size)
        val version = buf.get()
        if (version != VERSION) throw IllegalArgumentException("This backup was made by a newer version of the app.")
        val iterations = buf.getInt()
        if (iterations !in 10_000..5_000_000) throw WrongPasswordException()
        val salt = ByteArray(SALT_LEN).also { buf.get(it) }
        val iv = ByteArray(IV_LEN).also { buf.get(it) }
        val header = data.copyOfRange(0, HEADER_LEN)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(password, salt, iterations), GCMParameterSpec(128, iv))
        cipher.updateAAD(header)
        return try {
            cipher.doFinal(data, HEADER_LEN, data.size - HEADER_LEN)
        } catch (e: AEADBadTagException) {
            throw WrongPasswordException()
        }
    }
}

/** Slow, salted hashing for the app-lock PIN. The PIN itself is never stored. */
object PinHasher {
    const val ITERATIONS = 60_000
    private val random = SecureRandom()

    fun newSalt(): ByteArray = ByteArray(16).also { random.nextBytes(it) }

    fun hash(pin: String, salt: ByteArray, iterations: Int = ITERATIONS): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, iterations, 256)
        try {
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }

    /** Constant-time comparison so timing can't reveal how close a guess was. */
    fun matches(pin: String, salt: ByteArray, expected: ByteArray, iterations: Int = ITERATIONS): Boolean =
        MessageDigest.isEqual(hash(pin, salt, iterations), expected)

    fun isValidPin(pin: String): Boolean = pin.length in 4..6 && pin.all { it.isDigit() }
}
