package com.babylon.moneytracker.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.babylon.moneytracker.data.percentages
import com.babylon.moneytracker.domain.AccountType
import com.babylon.moneytracker.domain.AllocationCalculator
import com.babylon.moneytracker.domain.Categories
import com.babylon.moneytracker.domain.LedgerCalculator
import com.babylon.moneytracker.domain.Money
import com.babylon.moneytracker.domain.ParseResult
import com.babylon.moneytracker.domain.TxDirection
import com.babylon.moneytracker.domain.TxType
import com.babylon.moneytracker.ui.AppState
import com.babylon.moneytracker.ui.MainViewModel
import com.babylon.moneytracker.ui.components.AmountField
import com.babylon.moneytracker.ui.components.ChipRow
import com.babylon.moneytracker.ui.components.ConfirmDialog
import com.babylon.moneytracker.ui.components.DateField
import com.babylon.moneytracker.ui.components.LabelValue
import com.babylon.moneytracker.ui.components.LocalMoney
import com.babylon.moneytracker.ui.components.ScreenTopBar
import com.babylon.moneytracker.ui.components.SectionCard
import com.babylon.moneytracker.ui.components.SelectField
import com.babylon.moneytracker.ui.theme.uiColor
import java.time.LocalDate

@Composable
private fun FormColumn(content: @Composable () -> Unit) {
    Column(
        Modifier
            .fillMaxSize()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        content()
        Spacer(Modifier.height(24.dp))
    }
}

// =====================================================================
// Income
// =====================================================================

@Composable
fun IncomeFormScreen(state: AppState, vm: MainViewModel, nav: NavController, id: Long?, initialDate: LocalDate?) {
    val context = LocalContext.current
    val fmt = LocalMoney.current
    val decimals = state.settings.currencyDecimals
    val existing = id?.let { eid -> state.incomes.firstOrNull { it.id == eid } }

    var loaded by rememberSaveable { mutableStateOf(id == null) }
    var amount by rememberSaveable { mutableStateOf("") }
    var dateText by rememberSaveable { mutableStateOf((initialDate ?: state.today).toString()) }
    var source by rememberSaveable { mutableStateOf(Categories.INCOME_SOURCES.first()) }
    var description by rememberSaveable { mutableStateOf("") }
    var saving by rememberSaveable { mutableStateOf(false) }
    var confirmDelete by rememberSaveable { mutableStateOf(false) }

    // Fill the form once the entry being edited has loaded.
    LaunchedEffect(existing?.id) {
        if (!loaded && existing != null) {
            amount = Money.toInput(existing.amount, decimals)
            dateText = existing.date.toString()
            source = existing.source
            description = existing.description ?: ""
            loaded = true
        }
    }

    // Editing keeps the percentages the entry was recorded with; new entries use current settings.
    val percentages = existing?.percentages ?: state.settings.percentages()
    val parsed = Money.parse(amount, decimals)
    val preview = (parsed as? ParseResult.Ok)?.let {
        AllocationCalculator.allocate(it.minor, percentages, Money.allocationUnit(decimals))
    }

    Column(Modifier.fillMaxSize()) {
        ScreenTopBar(
            title = if (id == null) "Add income" else "Edit income",
            onBack = { nav.popBackStack() },
            actions = {
                if (id != null) {
                    IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, contentDescription = "Delete") }
                }
            },
        )
        FormColumn {
            AmountField(amount, { amount = it }, "Amount received", decimals = decimals)
            DateField("Date received", LocalDate.parse(dateText), { dateText = it.toString() })
            Text("Source of income", style = MaterialTheme.typography.labelLarge)
            val sources = (Categories.INCOME_SOURCES + listOfNotNull(source.takeIf { it !in Categories.INCOME_SOURCES }))
            ChipRow(sources, source, { it }, { source = it })
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Description or notes (optional)") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2,
            )

            SectionCard(title = "Automatic allocation") {
                AccountType.entries.forEach { t ->
                    LabelValue(
                        "${state.name(t)} · ${Money.formatPercent(percentages.of(t))}%",
                        preview?.let { fmt(it.of(t)) } ?: "—",
                        valueColor = t.uiColor(),
                    )
                }
                if (existing != null && existing.percentages != state.settings.percentages()) {
                    Text(
                        "This entry keeps the percentages it was recorded with.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            Button(
                onClick = {
                    saving = true
                    vm.saveIncome(id, amount, LocalDate.parse(dateText), source, description) { err ->
                        saving = false
                        if (err != null) {
                            Toast.makeText(context, err, Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(context, "Income saved and allocated", Toast.LENGTH_SHORT).show()
                            nav.popBackStack()
                        }
                    }
                },
                enabled = !saving && preview != null && loaded,
                modifier = Modifier.fillMaxWidth().height(52.dp),
            ) { Text(if (id == null) "Save income" else "Save changes") }
        }
    }

    if (confirmDelete && id != null) {
        ConfirmDialog(
            title = "Delete this income?",
            text = "Its allocations will be removed from all four accounts and every balance and report will update.",
            confirmLabel = "Delete",
            destructive = true,
            onConfirm = {
                vm.deleteIncome(id) { err ->
                    if (err != null) Toast.makeText(context, err, Toast.LENGTH_LONG).show() else nav.popBackStack()
                }
            },
            onDismiss = { confirmDelete = false },
        )
    }
}

// =====================================================================
// Envelope transactions (expenses, withdrawals, investments, giving …)
// =====================================================================

@Composable
fun EntryFormScreen(
    state: AppState,
    vm: MainViewModel,
    nav: NavController,
    account: AccountType,
    initialType: TxType?,
    id: Long?,
) {
    val context = LocalContext.current
    val fmt = LocalMoney.current
    val decimals = state.settings.currencyDecimals
    val existing = id?.let { eid -> state.ledger.firstOrNull { it.id == eid } }
    val types = TxType.manualTypesFor(account)

    var loaded by rememberSaveable { mutableStateOf(id == null) }
    var typeName by rememberSaveable { mutableStateOf((initialType?.takeIf { it in types } ?: types.first()).name) }
    var amount by rememberSaveable { mutableStateOf("") }
    var dateText by rememberSaveable { mutableStateOf(state.today.toString()) }
    var category by rememberSaveable { mutableStateOf(Categories.EXPENSE.first()) }
    var investmentType by rememberSaveable { mutableStateOf(Categories.INVESTMENT_TYPES.first()) }
    var description by rememberSaveable { mutableStateOf("") }
    var notes by rememberSaveable { mutableStateOf("") }
    var currentValue by rememberSaveable { mutableStateOf("") }
    var saving by rememberSaveable { mutableStateOf(false) }
    var confirmDelete by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(existing?.id) {
        if (!loaded && existing != null) {
            typeName = existing.type.name
            amount = Money.toInput(existing.amount, decimals)
            dateText = existing.date.toString()
            existing.expenseCategory?.let { category = it }
            existing.investmentType?.let { investmentType = it }
            description = existing.description
            notes = existing.notes ?: ""
            currentValue = existing.currentValue?.let { Money.toInput(it, decimals) } ?: ""
            loaded = true
        }
    }

    val type = TxType.valueOf(typeName)
    val available = LedgerCalculator.balanceOf(account, state.incomes, state.ledger, excludeLedgerId = id)
    val parsed = (Money.parse(amount, decimals) as? ParseResult.Ok)?.minor

    Column(Modifier.fillMaxSize()) {
        ScreenTopBar(
            title = (if (id == null) "" else "Edit · ") + state.name(account),
            onBack = { nav.popBackStack() },
            actions = {
                if (id != null) {
                    IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, contentDescription = "Delete") }
                }
            },
        )
        FormColumn {
            if (types.size > 1) {
                Text("Type", style = MaterialTheme.typography.labelLarge)
                ChipRow(types, type, { actionLabel(it) }, { typeName = it.name })
            }
            Text(
                helpText(type),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            AmountField(amount, { amount = it }, amountLabel(type), decimals = decimals)
            Text(
                "Available in ${state.name(account)}: ${fmt(available)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (type.direction == TxDirection.OUT && parsed != null && parsed > available) {
                Text(
                    "This is more than the available balance by ${fmt(parsed - available)}. " +
                        "You can still save it; the account will show as overspent.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error,
                )
            }
            DateField("Date", LocalDate.parse(dateText), { dateText = it.toString() })

            if (type == TxType.EXPENSE) {
                SelectField("Expense category", Categories.EXPENSE, category, { it }, { category = it })
            }
            if (account == AccountType.INVESTMENTS) {
                SelectField("Investment type", Categories.INVESTMENT_TYPES, investmentType, { it }, { investmentType = it })
            }
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Description") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = notes,
                onValueChange = { notes = it },
                label = { Text("Notes (optional)") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 2,
            )
            if (type == TxType.INVESTMENT_CONTRIBUTION) {
                AmountField(currentValue, { currentValue = it }, "Current value (optional)", decimals = decimals, optional = true)
                Text(
                    "Update this whenever you know what the investment is worth now. If empty, it is counted at the amount invested.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            Button(
                onClick = {
                    saving = true
                    vm.saveLedger(
                        id = id,
                        account = account,
                        type = type,
                        amountText = amount,
                        date = LocalDate.parse(dateText),
                        description = description,
                        notes = notes,
                        category = if (type == TxType.EXPENSE) category else null,
                        investmentType = if (account == AccountType.INVESTMENTS) investmentType else null,
                        currentValueText = currentValue,
                    ) { err ->
                        saving = false
                        if (err != null) Toast.makeText(context, err, Toast.LENGTH_LONG).show()
                        else nav.popBackStack()
                    }
                },
                enabled = !saving && parsed != null && loaded,
                modifier = Modifier.fillMaxWidth().height(52.dp),
            ) { Text("Save") }
        }
    }

    if (confirmDelete && id != null) {
        ConfirmDialog(
            title = "Delete this transaction?",
            text = "The account balance and reports will be recalculated.",
            confirmLabel = "Delete",
            destructive = true,
            onConfirm = {
                vm.deleteLedger(id) { err ->
                    if (err != null) Toast.makeText(context, err, Toast.LENGTH_LONG).show() else nav.popBackStack()
                }
            },
            onDismiss = { confirmDelete = false },
        )
    }
}

private fun amountLabel(t: TxType) = when (t) {
    TxType.EXPENSE -> "Amount spent"
    TxType.WITHDRAWAL -> "Amount withdrawn"
    TxType.DEPOSIT -> "Amount deposited"
    TxType.INVESTMENT_CONTRIBUTION -> "Amount invested"
    TxType.INVESTMENT_RETURN -> "Return received"
    TxType.INVESTMENT_CASHOUT -> "Capital received back"
    else -> "Amount"
}

private fun helpText(t: TxType) = when (t) {
    TxType.EXPENSE -> "Money spent from your living-expenses allocation."
    TxType.WITHDRAWAL -> "Money taken out of savings."
    TxType.DEPOSIT -> "Money added to savings from outside your recorded income (for example, a gift you choose to save). It is not counted as income."
    TxType.INVESTMENT_CONTRIBUTION -> "Money moved from this account into an investment. It is not an expense and not a profit."
    TxType.INVESTMENT_RETURN -> "Profit, interest or dividends an investment paid you. Added to this account, reported separately, not counted as income."
    TxType.INVESTMENT_CASHOUT -> "Original capital returned when an investment matures or is sold. Reduces the recorded investment value."
    else -> "Money used from your debt repayment / giving allocation."
}

// =====================================================================
// Transfers between envelopes
// =====================================================================

@Composable
fun TransferScreen(state: AppState, vm: MainViewModel, nav: NavController, initialFrom: AccountType?, ref: String?) {
    val context = LocalContext.current
    val fmt = LocalMoney.current
    val decimals = state.settings.currencyDecimals
    val legs = ref?.let { r -> state.ledger.filter { it.referenceId == r } }.orEmpty()
    val outLeg = legs.firstOrNull { it.type == TxType.TRANSFER_OUT }
    val inLeg = legs.firstOrNull { it.type == TxType.TRANSFER_IN }

    var loaded by rememberSaveable { mutableStateOf(ref == null) }
    var fromName by rememberSaveable { mutableStateOf((initialFrom ?: AccountType.LIVING).name) }
    var toName by rememberSaveable {
        mutableStateOf((if (initialFrom == AccountType.SAVINGS) AccountType.LIVING else AccountType.SAVINGS).name)
    }
    var amount by rememberSaveable { mutableStateOf("") }
    var dateText by rememberSaveable { mutableStateOf(state.today.toString()) }
    var description by rememberSaveable { mutableStateOf("") }
    var saving by rememberSaveable { mutableStateOf(false) }
    var confirmDelete by rememberSaveable { mutableStateOf(false) }

    LaunchedEffect(outLeg?.id, inLeg?.id) {
        if (!loaded && outLeg != null && inLeg != null) {
            fromName = outLeg.account.name
            toName = inLeg.account.name
            amount = Money.toInput(outLeg.amount, decimals)
            dateText = outLeg.date.toString()
            description = outLeg.description
            loaded = true
        }
    }

    val from = AccountType.valueOf(fromName)
    val to = AccountType.valueOf(toName)
    val available = LedgerCalculator.balanceOf(from, state.incomes, state.ledger.filter { it.referenceId == null || it.referenceId != ref })
    val parsed = (Money.parse(amount, decimals) as? ParseResult.Ok)?.minor

    Column(Modifier.fillMaxSize()) {
        ScreenTopBar(
            title = if (ref == null) "Move money" else "Edit transfer",
            onBack = { nav.popBackStack() },
            actions = {
                if (ref != null) {
                    IconButton(onClick = { confirmDelete = true }) { Icon(Icons.Filled.Delete, contentDescription = "Delete") }
                }
            },
        )
        FormColumn {
            Text(
                "Moves money between your own accounts. It is never counted as new income or as spending.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            if (ref == null) {
                SelectField("From", AccountType.entries, from, { state.name(it) }, { picked ->
                    fromName = picked.name
                    if (picked.name == toName) toName = AccountType.entries.first { it != picked }.name
                })
                SelectField("To", AccountType.entries.filter { it != from }, to, { state.name(it) }, { toName = it.name })
            } else {
                LabelValue("From", state.name(from))
                LabelValue("To", state.name(to))
            }
            AmountField(amount, { amount = it }, "Amount", decimals = decimals)
            Text(
                "Available in ${state.name(from)}: ${fmt(available)}",
                style = MaterialTheme.typography.bodySmall,
                color = if (parsed != null && parsed > available) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
            )
            DateField("Date", LocalDate.parse(dateText), { dateText = it.toString() })
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Reason (optional)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            Button(
                onClick = {
                    saving = true
                    vm.saveTransfer(ref, from, to, amount, LocalDate.parse(dateText), description) { err ->
                        saving = false
                        if (err != null) Toast.makeText(context, err, Toast.LENGTH_LONG).show() else nav.popBackStack()
                    }
                },
                enabled = !saving && parsed != null && from != to && loaded,
                modifier = Modifier.fillMaxWidth().height(52.dp),
            ) { Text("Save transfer") }
        }
    }

    if (confirmDelete && outLeg != null) {
        ConfirmDialog(
            title = "Delete this transfer?",
            text = "Both sides of the transfer will be removed.",
            confirmLabel = "Delete",
            destructive = true,
            onConfirm = {
                vm.deleteLedger(outLeg.id) { err ->
                    if (err != null) Toast.makeText(context, err, Toast.LENGTH_LONG).show() else nav.popBackStack()
                }
            },
            onDismiss = { confirmDelete = false },
        )
    }
}
