package com.babylon.moneytracker.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.babylon.moneytracker.BabylonApp
import com.babylon.moneytracker.data.FinanceRepository
import com.babylon.moneytracker.data.SettingsRepository
import com.babylon.moneytracker.data.db.ReminderSettings
import com.babylon.moneytracker.domain.AccountType
import com.babylon.moneytracker.domain.DateRange
import com.babylon.moneytracker.domain.FullReport
import com.babylon.moneytracker.domain.Money
import com.babylon.moneytracker.domain.Percentages
import com.babylon.moneytracker.domain.ReportCalculator
import com.babylon.moneytracker.domain.ReportPeriod
import com.babylon.moneytracker.domain.ThemeMode
import com.babylon.moneytracker.export.CsvExporter
import com.babylon.moneytracker.export.FileActions
import com.babylon.moneytracker.export.PdfReportWriter
import com.babylon.moneytracker.reminder.ReminderScheduler
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDate

enum class ExportKind(val ext: String, val mime: String) {
    PDF("pdf", "application/pdf"),
    CSV("csv", "text/csv"),
}

class ReportsViewModel(
    private val app: Application,
    private val finance: FinanceRepository,
    private val settingsRepo: SettingsRepository,
) : ViewModel() {

    val period = MutableStateFlow(ReportPeriod.THIS_MONTH)
    val customRange = MutableStateFlow(LocalDate.now().let { DateRange(it.withDayOfMonth(1), it) })

    /** The range currently being reported on. */
    val range: StateFlow<DateRange> = combine(period, customRange) { p, c -> p.range(LocalDate.now()) ?: c }
        .stateIn(viewModelScope, SharingStarted.Eagerly, ReportPeriod.THIS_MONTH.range(LocalDate.now())!!)

    /** Always built from stored transactions; an empty period simply shows zeroes. */
    val report: StateFlow<FullReport?> =
        combine(finance.incomes, finance.ledger, finance.loans, settingsRepo.settings, range) { inc, led, loans, s, r ->
            ReportCalculator.build(
                inc, led, r, s.savingsTargetMinor,
                loans = loans, today = LocalDate.now(), unit = Money.allocationUnit(s.currencyDecimals),
            )
        }.flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    fun selectPeriod(p: ReportPeriod) {
        period.value = p
    }

    fun setCustomRange(start: LocalDate, end: LocalDate) {
        customRange.value = if (end.isBefore(start)) DateRange(end, start) else DateRange(start, end)
        period.value = ReportPeriod.CUSTOM
    }

    /** Writes the report to the app's cache folder and hands back the file for sharing or saving. */
    fun export(kind: ExportKind, onDone: (File?, String?) -> Unit) {
        viewModelScope.launch {
            try {
                val file = withContext(Dispatchers.IO) {
                    val s = settingsRepo.current()
                    val names = finance.accountNames.first()
                    val nameOf: (AccountType) -> String = { names[it] ?: it.defaultName }
                    val incomes = finance.incomes.first()
                    val ledger = finance.ledger.first()
                    val r = range.value
                    val report = ReportCalculator.build(
                        incomes, ledger, r, s.savingsTargetMinor,
                        loans = finance.loans.first(), today = LocalDate.now(),
                        unit = Money.allocationUnit(s.currencyDecimals),
                    )
                    val out = File(FileActions.reportsDir(app), CsvExporter.fileName("paul_report", r, kind.ext))
                    when (kind) {
                        ExportKind.PDF -> PdfReportWriter(
                            money = { Money.format(it, s.currencySymbol, s.currencyDecimals) },
                            accountName = nameOf,
                        ).write(report, out)
                        ExportKind.CSV -> CsvExporter(s.currencyCode, s.currencyDecimals, nameOf)
                            .writeReport(report, incomes, ledger, out)
                    }
                    out
                }
                onDone(file, null)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                onDone(null, e.message ?: "Export failed")
            }
        }
    }
}

class SettingsViewModel(
    private val app: Application,
    private val finance: FinanceRepository,
    private val settingsRepo: SettingsRepository,
) : ViewModel() {

    private fun act(onResult: (String?) -> Unit, block: suspend () -> Unit) {
        viewModelScope.launch {
            val err = try {
                block(); null
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                e.message ?: "Something went wrong"
            }
            onResult(err)
        }
    }

    fun setPercentages(p: Percentages, onResult: (String?) -> Unit) = act(onResult) { settingsRepo.setPercentages(p) }

    fun setCurrency(code: String, symbol: String, decimals: Int, onResult: (String?) -> Unit) =
        act(onResult) { settingsRepo.setCurrency(code, symbol, decimals) }

    fun setTheme(mode: ThemeMode) = act({}) { settingsRepo.setTheme(mode) }

    fun renameAccounts(names: Map<AccountType, String>, onResult: (String?) -> Unit) = act(onResult) {
        names.forEach { (t, n) -> finance.renameAccount(t, n) }
    }

    fun saveReminder(r: ReminderSettings, onResult: (String?) -> Unit = {}) = act(onResult) {
        settingsRepo.saveReminder(r)
        ReminderScheduler.reschedule(app, r)
    }

    /** Builds a password-protected backup file, ready to share or save. */
    fun createBackup(password: String, onDone: (File?, String?) -> Unit) {
        viewModelScope.launch {
            try {
                onDone(FileActions.createEncryptedBackup(app, password.toCharArray()), null)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                onDone(null, e.message ?: "Backup failed")
            }
        }
    }

    fun checkBackupType(source: Uri, onDone: (encrypted: Boolean?, error: String?) -> Unit) {
        viewModelScope.launch {
            try {
                onDone(FileActions.isEncryptedBackup(app, source), null)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                onDone(null, e.message ?: "Could not read the file")
            }
        }
    }

    /** On success the caller must restart the app. */
    fun restore(source: Uri, password: String?, onResult: (String?) -> Unit) = act(onResult) {
        FileActions.restoreDatabase(app, source, password?.toCharArray())
    }

    fun exportAll(onDone: (File?, String?) -> Unit) {
        viewModelScope.launch {
            try {
                val file = withContext(Dispatchers.IO) {
                    val s = settingsRepo.current()
                    val names = finance.accountNames.first()
                    val out = File(FileActions.reportsDir(app), "paul_all_records_${LocalDate.now()}.csv")
                    CsvExporter(s.currencyCode, s.currencyDecimals) { names[it] ?: it.defaultName }
                        .writeAll(finance.incomes.first(), finance.ledger.first(), out)
                    out
                }
                onDone(file, null)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                onDone(null, e.message ?: "Export failed")
            }
        }
    }
}

object AppViewModels {
    val Factory = viewModelFactory {
        initializer {
            val app = this[APPLICATION_KEY] as BabylonApp
            MainViewModel(app.container.finance, app.container.settings)
        }
        initializer {
            val app = this[APPLICATION_KEY] as BabylonApp
            ReportsViewModel(app, app.container.finance, app.container.settings)
        }
        initializer {
            val app = this[APPLICATION_KEY] as BabylonApp
            SettingsViewModel(app, app.container.finance, app.container.settings)
        }
    }
}
