package com.babylon.moneytracker.data

import com.babylon.moneytracker.data.db.AccountTransactionWithDetails
import com.babylon.moneytracker.data.db.AppSettings
import com.babylon.moneytracker.data.db.IncomeTransaction
import com.babylon.moneytracker.data.db.IncomeWithAllocations
import com.babylon.moneytracker.data.db.SavingsGoal
import com.babylon.moneytracker.domain.AccountType
import com.babylon.moneytracker.domain.AllocationSplit
import com.babylon.moneytracker.domain.Goal
import com.babylon.moneytracker.domain.IncomeRecord
import com.babylon.moneytracker.domain.LedgerRecord
import com.babylon.moneytracker.domain.Money
import com.babylon.moneytracker.domain.Percentages
import java.time.LocalDate

fun IncomeTransaction.percentages() = Percentages(livingBp, savingsBp, investmentsBp, givingBp)

fun AppSettings.percentages() = Percentages(livingBp, savingsBp, investmentsBp, givingBp)

fun AppSettings.allocationUnit(): Long = Money.allocationUnit(currencyDecimals)

fun IncomeWithAllocations.toRecord(): IncomeRecord {
    fun amountFor(t: AccountType) = allocations.filter { it.accountId == t.id }.sumOf { it.amountMinor }
    return IncomeRecord(
        id = income.id,
        amount = income.amountMinor,
        date = LocalDate.ofEpochDay(income.dateEpochDay),
        source = income.source,
        description = income.description,
        percentages = income.percentages(),
        split = AllocationSplit(
            living = amountFor(AccountType.LIVING),
            savings = amountFor(AccountType.SAVINGS),
            investments = amountFor(AccountType.INVESTMENTS),
            giving = amountFor(AccountType.GIVING),
        ),
        createdAt = income.createdAt,
    )
}

fun AccountTransactionWithDetails.toRecord() = LedgerRecord(
    id = tx.id,
    account = AccountType.fromId(tx.accountId),
    type = tx.type,
    amount = tx.amountMinor,
    date = LocalDate.ofEpochDay(tx.dateEpochDay),
    description = tx.description,
    notes = tx.notes,
    referenceId = tx.referenceId,
    expenseCategory = expense?.category,
    investmentType = investment?.investmentType,
    currentValue = investment?.currentValueMinor,
    createdAt = tx.createdAt,
)

fun SavingsGoal.toGoal() = Goal(
    id = id,
    name = name,
    target = targetMinor,
    targetDate = targetDateEpochDay?.let { LocalDate.ofEpochDay(it) },
    metric = metric,
    manualCurrent = manualCurrentMinor,
)
