package com.babylon.moneytracker.reminder

import android.content.Context
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.babylon.moneytracker.data.db.ReminderSettings
import java.time.Duration
import java.time.ZonedDateTime
import java.util.concurrent.TimeUnit

/**
 * Daily reminder scheduling.
 *
 * A one-time WorkManager job is set for the next occurrence of the chosen time.
 * When it runs, it queues the following day's job (see ReminderWorker), so the
 * reminder keeps its clock time even across daylight-saving or time-zone changes.
 * WorkManager stores jobs on disk and restores them after the app is closed or
 * the phone restarts; BootReceiver also re-aligns the job after a reboot or clock change.
 */
object ReminderScheduler {
    const val WORK_NAME = "daily_income_reminder"

    /** Replaces any scheduled reminder. Call from the UI, app start, or BootReceiver. */
    fun reschedule(context: Context, settings: ReminderSettings) {
        val wm = WorkManager.getInstance(context)
        if (!settings.enabled) {
            wm.cancelUniqueWork(WORK_NAME)
            return
        }
        wm.enqueueUniqueWork(WORK_NAME, ExistingWorkPolicy.REPLACE, request(settings))
    }

    /**
     * Called from inside the running worker. APPEND_OR_REPLACE queues the next run
     * after the current one finishes instead of cancelling the job that is running.
     */
    fun scheduleNextFromWorker(context: Context, settings: ReminderSettings) {
        if (!settings.enabled) return
        WorkManager.getInstance(context)
            .enqueueUniqueWork(WORK_NAME, ExistingWorkPolicy.APPEND_OR_REPLACE, request(settings))
    }

    private fun request(settings: ReminderSettings) =
        OneTimeWorkRequestBuilder<ReminderWorker>()
            .setInitialDelay(millisUntilNext(settings.hour, settings.minute, ZonedDateTime.now()), TimeUnit.MILLISECONDS)
            .addTag(WORK_NAME)
            .build()

    fun millisUntilNext(hour: Int, minute: Int, now: ZonedDateTime): Long {
        var next = now.withHour(hour).withMinute(minute).withSecond(0).withNano(0)
        if (!next.isAfter(now.plusSeconds(30))) next = next.plusDays(1)
        return Duration.between(now, next).toMillis()
    }
}
