package com.babylon.moneytracker.domain

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.temporal.TemporalAdjusters

/**
 * One envelope's position, rebuilt from transactions every time.
 *
 * balance = allocated + otherIn - used - otherOut
 */
data class AccountSummary(
    val type: AccountType,
    /** From income allocations. */
    val allocated: Long,
    /** Spent / Withdrawn / Invested / Used: the envelope's main purpose. */
    val used: Long,
    /** Transfers in, deposits, investment returns and capital cashed out. */
    val otherIn: Long,
    /** Transfers out. */
    val otherOut: Long,
) {
    val balance: Long get() = allocated + otherIn - used - otherOut
    val totalIn: Long get() = allocated + otherIn

    /** Share of the money that came in that has been used, 0..1. */
    val usedFraction: Float
        get() = if (totalIn <= 0) 0f else (used.toDouble() / totalIn).toFloat().coerceIn(0f, 1f)

    companion object {
        fun empty(type: AccountType) = AccountSummary(type, 0, 0, 0, 0)
    }
}

data class FinancialOverview(
    val totalIncome: Long,
    val totalAllocated: AllocationSplit,
    val accounts: Map<AccountType, AccountSummary>,
    /** Living-expense spending + debt repayment/giving. Investments and transfers are NOT expenditure. */
    val totalExpenditure: Long,
    val livingExpenses: Long,
    val givingUsed: Long,
    val savingsBalance: Long,
    val investmentContributions: Long,
    val investmentReturns: Long,
    val investmentCashouts: Long,
    /** Value of money currently invested: the latest recorded value of each contribution, minus capital cashed out. */
    val investmentHoldingsValue: Long,
) {
    fun account(type: AccountType): AccountSummary = accounts[type] ?: AccountSummary.empty(type)

    /** Savings + uninvested investment cash + investment holdings. */
    val wealthBuilt: Long
        get() = savingsBalance + account(AccountType.INVESTMENTS).balance + investmentHoldingsValue

    /** Every envelope balance plus investment holdings. */
    val totalAssets: Long
        get() = accounts.values.sumOf { it.balance } + investmentHoldingsValue

    /** Share of everything earned that has been kept as savings or investments, 0..1. */
    val wealthProgress: Float
        get() = if (totalIncome <= 0) 0f else (wealthBuilt.toDouble() / totalIncome).toFloat().coerceIn(0f, 1f)
}

data class IncomeTotals(val today: Long, val week: Long, val month: Long, val allTime: Long)

data class GoalProgress(val goal: Goal, val current: Long) {
    val fraction: Float
        get() = if (goal.target <= 0) 0f else (current.toDouble() / goal.target).toFloat().coerceIn(0f, 1f)
    val percent: Int get() = (fraction * 100).toInt()
    val isComplete: Boolean get() = goal.target in 1..current
}

object LedgerCalculator {

    /**
     * Rebuilds every balance from stored records. When [upTo] is given, only
     * records dated on or before that day are counted (used for "balance at end
     * of report period").
     */
    fun overview(
        incomes: List<IncomeRecord>,
        ledger: List<LedgerRecord>,
        upTo: LocalDate? = null,
    ): FinancialOverview {
        val inc = if (upTo == null) incomes else incomes.filter { !it.date.isAfter(upTo) }
        val led = if (upTo == null) ledger else ledger.filter { !it.date.isAfter(upTo) }

        val allocated = inc.fold(AllocationSplit.ZERO) { acc, r -> acc + r.split }

        val accounts = AccountType.entries.associateWith { type ->
            val rows = led.filter { it.account == type }
            val primary = TxType.primaryUse(type)
            AccountSummary(
                type = type,
                allocated = allocated.of(type),
                used = rows.filter { it.type in primary }.sumOf { it.amount },
                otherIn = rows.filter { it.type.direction == TxDirection.IN }.sumOf { it.amount },
                otherOut = rows.filter { it.type.direction == TxDirection.OUT && it.type !in primary }
                    .sumOf { it.amount },
            )
        }

        val living = led.filter { it.type == TxType.EXPENSE }.sumOf { it.amount }
        val giving = led.filter { it.type.isGiving }.sumOf { it.amount }
        val contributions = led.filter { it.type == TxType.INVESTMENT_CONTRIBUTION }
        val cashouts = led.filter { it.type == TxType.INVESTMENT_CASHOUT }.sumOf { it.amount }
        val holdings = (contributions.sumOf { it.currentValue ?: it.amount } - cashouts).coerceAtLeast(0)

        return FinancialOverview(
            totalIncome = inc.sumOf { it.amount },
            totalAllocated = allocated,
            accounts = accounts,
            totalExpenditure = living + giving,
            livingExpenses = living,
            givingUsed = giving,
            savingsBalance = accounts.getValue(AccountType.SAVINGS).balance,
            investmentContributions = contributions.sumOf { it.amount },
            investmentReturns = led.filter { it.type == TxType.INVESTMENT_RETURN }.sumOf { it.amount },
            investmentCashouts = cashouts,
            investmentHoldingsValue = holdings,
        )
    }

    fun incomeTotals(
        incomes: List<IncomeRecord>,
        today: LocalDate,
        weekStart: DayOfWeek = DayOfWeek.MONDAY,
    ): IncomeTotals {
        val startOfWeek = today.with(TemporalAdjusters.previousOrSame(weekStart))
        val endOfWeek = startOfWeek.plusDays(6)
        return IncomeTotals(
            today = incomes.filter { it.date == today }.sumOf { it.amount },
            week = incomes.filter { !it.date.isBefore(startOfWeek) && !it.date.isAfter(endOfWeek) }.sumOf { it.amount },
            month = incomes.filter { it.date.year == today.year && it.date.month == today.month }.sumOf { it.amount },
            allTime = incomes.sumOf { it.amount },
        )
    }

    fun goalProgress(goal: Goal, overview: FinancialOverview): GoalProgress {
        val current = when (goal.metric) {
            GoalMetric.SAVINGS_BALANCE -> overview.savingsBalance
            GoalMetric.INVESTMENT_CONTRIBUTIONS -> overview.investmentContributions
            GoalMetric.INVESTMENT_VALUE -> overview.investmentHoldingsValue
            GoalMetric.TOTAL_ASSETS -> overview.totalAssets
            GoalMetric.MANUAL -> goal.manualCurrent
        }
        return GoalProgress(goal, current.coerceAtLeast(0))
    }

    /** Balance of one envelope, optionally excluding one record (used to warn about overspending while editing). */
    fun balanceOf(
        type: AccountType,
        incomes: List<IncomeRecord>,
        ledger: List<LedgerRecord>,
        excludeLedgerId: Long? = null,
    ): Long = overview(incomes, ledger.filter { it.id != excludeLedgerId }).account(type).balance
}
