package com.babylon.moneytracker.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.babylon.moneytracker.domain.AccountType

@Database(
    entities = [
        Account::class,
        IncomeTransaction::class,
        Allocation::class,
        AccountTransaction::class,
        ExpenseTransaction::class,
        InvestmentTransaction::class,
        SavingsGoal::class,
        AppSettings::class,
        ReminderSettings::class,
    ],
    version = 1,
    exportSchema = true,
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun accountDao(): AccountDao
    abstract fun incomeDao(): IncomeDao
    abstract fun ledgerDao(): LedgerDao
    abstract fun goalDao(): GoalDao
    abstract fun settingsDao(): SettingsDao

    companion object {
        const val NAME = "babylon_money.db"

        fun build(context: Context): AppDatabase =
            Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, NAME)
                .addCallback(SeedCallback)
                .build()
    }

    /** Creates the four envelopes and default settings the first time the database is made. */
    private object SeedCallback : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            AccountType.entries.forEach { t ->
                db.execSQL(
                    "INSERT OR IGNORE INTO accounts (id, type, name, sortOrder) VALUES (?, ?, ?, ?)",
                    arrayOf<Any>(t.id, t.name, t.defaultName, t.id),
                )
            }
            db.execSQL(
                "INSERT OR IGNORE INTO app_settings (id, currencyCode, currencySymbol, currencyDecimals, themeMode, " +
                    "livingBp, savingsBp, investmentsBp, givingBp, savingsTargetMinor) " +
                    "VALUES (1, 'UGX', 'UGX', 0, 'SYSTEM', 7000, 1000, 1000, 1000, NULL)"
            )
            db.execSQL(
                "INSERT OR IGNORE INTO reminder_settings (id, enabled, hour, minute, confirmWhenRecorded) " +
                    "VALUES (1, 1, 20, 0, 0)"
            )
        }
    }
}
