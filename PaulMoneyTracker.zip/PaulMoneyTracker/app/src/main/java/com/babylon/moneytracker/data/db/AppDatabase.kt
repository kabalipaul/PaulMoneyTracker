package com.babylon.moneytracker.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.babylon.moneytracker.domain.AccountType

@Database(
    entities = [
        Account::class,
        IncomeTransaction::class,
        Allocation::class,
        AccountTransaction::class,
        ExpenseTransaction::class,
        InvestmentTransaction::class,
        SavingsGoal::class,
        AppSettings::class,
        ReminderSettings::class,
        Loan::class,
        LoanRepayment::class,
    ],
    version = 2,
    exportSchema = true,
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun accountDao(): AccountDao
    abstract fun incomeDao(): IncomeDao
    abstract fun ledgerDao(): LedgerDao
    abstract fun goalDao(): GoalDao
    abstract fun settingsDao(): SettingsDao
    abstract fun loanDao(): LoanDao

    companion object {
        const val NAME = "babylon_money.db"

        fun build(context: Context): AppDatabase =
            Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, NAME)
                .addCallback(SeedCallback)
                .addMigrations(MIGRATION_1_2)
                .build()

        /**
         * Version 1 -> 2: adds the Loans module. Only creates two new tables;
         * every existing income, allocation, transaction, goal and setting is kept as it is.
         */
        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `loans` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`direction` TEXT NOT NULL, " +
                        "`counterparty` TEXT NOT NULL, " +
                        "`principalMinor` INTEGER NOT NULL, " +
                        "`dateEpochDay` INTEGER NOT NULL, " +
                        "`dueDateEpochDay` INTEGER, " +
                        "`interestRateBp` INTEGER NOT NULL, " +
                        "`interestPeriod` TEXT NOT NULL, " +
                        "`repaymentOrder` TEXT NOT NULL, " +
                        "`purpose` TEXT, " +
                        "`contact` TEXT, " +
                        "`notes` TEXT, " +
                        "`disbursementTxId` INTEGER NOT NULL, " +
                        "`createdAt` INTEGER NOT NULL, " +
                        "`updatedAt` INTEGER NOT NULL, " +
                        "FOREIGN KEY(`disbursementTxId`) REFERENCES `account_transactions`(`id`) " +
                        "ON UPDATE NO ACTION ON DELETE NO ACTION )"
                )
                db.execSQL(
                    "CREATE UNIQUE INDEX IF NOT EXISTS `index_loans_disbursementTxId` ON `loans` (`disbursementTxId`)"
                )
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `loan_repayments` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`loanId` INTEGER NOT NULL, " +
                        "`accountTransactionId` INTEGER NOT NULL, " +
                        "`createdAt` INTEGER NOT NULL, " +
                        "FOREIGN KEY(`loanId`) REFERENCES `loans`(`id`) ON UPDATE NO ACTION ON DELETE CASCADE , " +
                        "FOREIGN KEY(`accountTransactionId`) REFERENCES `account_transactions`(`id`) " +
                        "ON UPDATE NO ACTION ON DELETE CASCADE )"
                )
                db.execSQL(
                    "CREATE INDEX IF NOT EXISTS `index_loan_repayments_loanId` ON `loan_repayments` (`loanId`)"
                )
                db.execSQL(
                    "CREATE UNIQUE INDEX IF NOT EXISTS `index_loan_repayments_accountTransactionId` " +
                        "ON `loan_repayments` (`accountTransactionId`)"
                )
            }
        }
    }

    /** Creates the four envelopes and default settings the first time the database is made. */
    private object SeedCallback : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            AccountType.entries.forEach { t ->
                db.execSQL(
                    "INSERT OR IGNORE INTO accounts (id, type, name, sortOrder) VALUES (?, ?, ?, ?)",
                    arrayOf<Any>(t.id, t.name, t.defaultName, t.id),
                )
            }
            db.execSQL(
                "INSERT OR IGNORE INTO app_settings (id, currencyCode, currencySymbol, currencyDecimals, themeMode, " +
                    "livingBp, savingsBp, investmentsBp, givingBp, savingsTargetMinor) " +
                    "VALUES (1, 'UGX', 'UGX', 0, 'SYSTEM', 7000, 1000, 1000, 1000, NULL)"
            )
            db.execSQL(
                "INSERT OR IGNORE INTO reminder_settings (id, enabled, hour, minute, confirmWhenRecorded) " +
                    "VALUES (1, 1, 20, 0, 0)"
            )
        }
    }
}
