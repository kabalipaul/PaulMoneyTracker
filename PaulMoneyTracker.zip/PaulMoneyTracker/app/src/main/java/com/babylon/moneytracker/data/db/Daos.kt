package com.babylon.moneytracker.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AccountDao {
    @Query("SELECT * FROM accounts ORDER BY sortOrder")
    fun observeAll(): Flow<List<Account>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(accounts: List<Account>)

    @Query("UPDATE accounts SET name = :name WHERE id = :id")
    suspend fun rename(id: Int, name: String)
}

@Dao
interface IncomeDao {
    @Transaction
    @Query("SELECT * FROM income_transactions ORDER BY dateEpochDay DESC, createdAt DESC")
    fun observeAll(): Flow<List<IncomeWithAllocations>>

    @Query("SELECT * FROM income_transactions WHERE id = :id")
    suspend fun getById(id: Long): IncomeTransaction?

    @Query("SELECT COUNT(*) FROM income_transactions WHERE dateEpochDay = :epochDay")
    suspend fun countOn(epochDay: Long): Int

    @Insert
    suspend fun insert(income: IncomeTransaction): Long

    @Update
    suspend fun update(income: IncomeTransaction)

    @Query("DELETE FROM income_transactions WHERE id = :id")
    suspend fun delete(id: Long)

    @Insert
    suspend fun insertAllocations(allocations: List<Allocation>)

    @Query("DELETE FROM allocations WHERE incomeId = :incomeId")
    suspend fun deleteAllocations(incomeId: Long)
}

@Dao
interface LedgerDao {
    @Transaction
    @Query("SELECT * FROM account_transactions ORDER BY dateEpochDay DESC, createdAt DESC")
    fun observeAll(): Flow<List<AccountTransactionWithDetails>>

    @Transaction
    @Query("SELECT * FROM account_transactions WHERE id = :id")
    suspend fun getById(id: Long): AccountTransactionWithDetails?

    @Query("SELECT * FROM account_transactions WHERE referenceId = :ref")
    suspend fun getByReference(ref: String): List<AccountTransaction>

    @Insert
    suspend fun insert(tx: AccountTransaction): Long

    @Update
    suspend fun update(tx: AccountTransaction)

    @Query("DELETE FROM account_transactions WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM account_transactions WHERE referenceId = :ref")
    suspend fun deleteByReference(ref: String)

    @Insert
    suspend fun insertExpense(e: ExpenseTransaction)

    @Query("DELETE FROM expense_transactions WHERE accountTransactionId = :txId")
    suspend fun deleteExpenseFor(txId: Long)

    @Insert
    suspend fun insertInvestment(i: InvestmentTransaction)

    @Query("DELETE FROM investment_transactions WHERE accountTransactionId = :txId")
    suspend fun deleteInvestmentFor(txId: Long)
}

@Dao
interface GoalDao {
    @Query("SELECT * FROM savings_goals ORDER BY createdAt")
    fun observeAll(): Flow<List<SavingsGoal>>

    @Insert
    suspend fun insert(goal: SavingsGoal): Long

    @Update
    suspend fun update(goal: SavingsGoal)

    @Query("DELETE FROM savings_goals WHERE id = :id")
    suspend fun delete(id: Long)
}

@Dao
interface SettingsDao {
    @Query("SELECT * FROM app_settings WHERE id = 1")
    fun observeSettings(): Flow<AppSettings?>

    @Query("SELECT * FROM app_settings WHERE id = 1")
    suspend fun getSettings(): AppSettings?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveSettings(settings: AppSettings)

    @Query("SELECT * FROM reminder_settings WHERE id = 1")
    fun observeReminder(): Flow<ReminderSettings?>

    @Query("SELECT * FROM reminder_settings WHERE id = 1")
    suspend fun getReminder(): ReminderSettings?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveReminder(settings: ReminderSettings)
}
