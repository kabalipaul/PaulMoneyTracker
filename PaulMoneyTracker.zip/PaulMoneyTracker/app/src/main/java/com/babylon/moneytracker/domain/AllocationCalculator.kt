package com.babylon.moneytracker.domain

import java.math.BigInteger

object AllocationCalculator {

    /**
     * Splits [amount] (minor units) according to [percentages].
     *
     * Savings, Investments and Debt/Giving are each rounded DOWN to a multiple of
     * [unit]; Living Expenses receives whatever is left. The four parts therefore
     * always add up to exactly [amount], and any rounding remainder goes to the
     * Living Expenses (70 %) envelope as required.
     */
    fun allocate(amount: Long, percentages: Percentages, unit: Long = 1L): AllocationSplit {
        require(amount >= 0) { "Amount cannot be negative" }
        require(percentages.isValid) { "Percentages must total 100%" }
        require(unit > 0) { "Unit must be positive" }

        val big = BigInteger.valueOf(amount)
        val full = BigInteger.valueOf(Percentages.FULL.toLong())
        val u = BigInteger.valueOf(unit)

        fun share(bp: Int): Long =
            big.multiply(BigInteger.valueOf(bp.toLong())).divide(full).divide(u).multiply(u).toLong()

        val savings = share(percentages.savings)
        val investments = share(percentages.investments)
        val giving = share(percentages.giving)
        val living = amount - savings - investments - giving
        return AllocationSplit(living, savings, investments, giving)
    }
}
