package com.babylon.moneytracker.security

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.util.Base64
import android.view.WindowManager
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK

sealed interface PinResult {
    data object Success : PinResult
    data class Wrong(val attemptsLeftBeforePause: Int) : PinResult
    data class LockedOut(val millisLeft: Long) : PinResult
}

/**
 * App-lock settings, stored in the app's private storage.
 * Only a salted PBKDF2 hash of the PIN is kept; the PIN itself is never saved.
 */
object AppLock {
    private const val PREFS = "security"
    private const val K_HASH = "pin_hash"
    private const val K_SALT = "pin_salt"
    private const val K_LEN = "pin_len"
    private const val K_FAILS = "pin_fails"
    private const val K_LOCK_UNTIL = "pin_lock_until"
    private const val K_BIO = "biometric"
    private const val K_TIMEOUT = "timeout_ms"
    private const val K_HIDE = "hide_content"
    private const val K_LAST_BACKUP = "last_backup_at"

    private const val ATTEMPTS_PER_PAUSE = 5

    val TIMEOUT_OPTIONS: List<Pair<Long, String>> = listOf(
        30_000L to "30 seconds",
        60_000L to "1 minute",
        300_000L to "5 minutes",
        900_000L to "15 minutes",
    )

    private fun prefs(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun b64(bytes: ByteArray) = Base64.encodeToString(bytes, Base64.NO_WRAP)
    private fun unb64(s: String): ByteArray = Base64.decode(s, Base64.NO_WRAP)

    fun isEnabled(ctx: Context): Boolean = prefs(ctx).contains(K_HASH)

    fun pinLength(ctx: Context): Int = prefs(ctx).getInt(K_LEN, 4)

    fun setPin(ctx: Context, pin: String) {
        require(PinHasher.isValidPin(pin)) { "The PIN must be 4 to 6 digits" }
        val salt = PinHasher.newSalt()
        prefs(ctx).edit()
            .putString(K_SALT, b64(salt))
            .putString(K_HASH, b64(PinHasher.hash(pin, salt)))
            .putInt(K_LEN, pin.length)
            .putInt(K_FAILS, 0)
            .putLong(K_LOCK_UNTIL, 0)
            .apply()
    }

    fun removePin(ctx: Context) {
        prefs(ctx).edit()
            .remove(K_HASH).remove(K_SALT).remove(K_LEN).remove(K_FAILS).remove(K_LOCK_UNTIL)
            .putBoolean(K_BIO, false)
            .apply()
    }

    fun lockoutRemaining(ctx: Context): Long =
        (prefs(ctx).getLong(K_LOCK_UNTIL, 0) - System.currentTimeMillis()).coerceAtLeast(0)

    /**
     * Checks a PIN. After every 5 wrong tries the app pauses: 30 s, then 1 min,
     * 2 min… up to 30 min, which makes guessing impractical.
     */
    fun verify(ctx: Context, pin: String): PinResult {
        val p = prefs(ctx)
        val left = lockoutRemaining(ctx)
        if (left > 0) return PinResult.LockedOut(left)
        val hash = p.getString(K_HASH, null) ?: return PinResult.Success
        val salt = p.getString(K_SALT, null) ?: return PinResult.Success
        if (PinHasher.matches(pin, unb64(salt), unb64(hash))) {
            p.edit().putInt(K_FAILS, 0).putLong(K_LOCK_UNTIL, 0).apply()
            return PinResult.Success
        }
        val fails = p.getInt(K_FAILS, 0) + 1
        val editor = p.edit().putInt(K_FAILS, fails)
        return if (fails % ATTEMPTS_PER_PAUSE == 0) {
            val round = (fails / ATTEMPTS_PER_PAUSE - 1).coerceIn(0, 6)
            val pause = (30_000L shl round).coerceAtMost(30 * 60_000L)
            editor.putLong(K_LOCK_UNTIL, System.currentTimeMillis() + pause).apply()
            PinResult.LockedOut(pause)
        } else {
            editor.apply()
            PinResult.Wrong(ATTEMPTS_PER_PAUSE - fails % ATTEMPTS_PER_PAUSE)
        }
    }

    /**
     * Fingerprint / face unlock is offered on Android 9+ when the phone has one set up.
     * (Older versions need a different dialog style that this app does not use.)
     */
    fun biometricAvailable(ctx: Context): Boolean =
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.P &&
            BiometricManager.from(ctx).canAuthenticate(BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS

    fun biometricEnabled(ctx: Context): Boolean =
        isEnabled(ctx) && prefs(ctx).getBoolean(K_BIO, false) && biometricAvailable(ctx)

    fun setBiometric(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean(K_BIO, on).apply()

    fun timeoutMs(ctx: Context): Long = prefs(ctx).getLong(K_TIMEOUT, 30_000L)
    fun setTimeout(ctx: Context, ms: Long) = prefs(ctx).edit().putLong(K_TIMEOUT, ms).apply()

    /** Hide the app in the recent-apps screen and block screenshots. On by default. */
    fun hideContent(ctx: Context): Boolean = prefs(ctx).getBoolean(K_HIDE, true)

    fun setHideContent(activity: Activity, on: Boolean) {
        prefs(activity).edit().putBoolean(K_HIDE, on).apply()
        applyWindowFlags(activity)
    }

    fun applyWindowFlags(activity: Activity) {
        if (hideContent(activity)) {
            activity.window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        } else {
            activity.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }
    }

    fun lastBackupAt(ctx: Context): Long = prefs(ctx).getLong(K_LAST_BACKUP, 0L)
    fun markBackedUp(ctx: Context) = prefs(ctx).edit().putLong(K_LAST_BACKUP, System.currentTimeMillis()).apply()
}
