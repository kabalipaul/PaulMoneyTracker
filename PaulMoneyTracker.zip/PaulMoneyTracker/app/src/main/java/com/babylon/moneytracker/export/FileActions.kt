package com.babylon.moneytracker.export

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import androidx.core.content.FileProvider
import com.babylon.moneytracker.container
import com.babylon.moneytracker.data.db.AppDatabase
import com.babylon.moneytracker.security.AppLock
import com.babylon.moneytracker.security.BackupCrypto
import com.babylon.moneytracker.security.WrongPasswordException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/** Sharing, saving and database backup/restore. All file work runs off the main thread. */
object FileActions {

    fun reportsDir(context: Context): File = File(context.cacheDir, "reports").apply { mkdirs() }

    /** Opens Android's share sheet for a generated file. */
    fun share(context: Context, file: File, mime: String) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, file.name)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(
            Intent.createChooser(send, "Share ${file.name}").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    /** Copies a generated file to a location the user picked with the system file picker. */
    suspend fun copyToUri(context: Context, file: File, target: Uri) = withContext(Dispatchers.IO) {
        val out = context.contentResolver.openOutputStream(target) ?: error("Could not open the selected location")
        out.use { o -> file.inputStream().use { it.copyTo(o) } }
    }

    /** Deletes exported reports and backups left in the app's private cache. Called when the app starts. */
    fun cleanTempFiles(context: Context) {
        reportsDir(context).listFiles()?.forEach { it.delete() }
        File(context.cacheDir, "restore_candidate.db").delete()
    }

    // ---------------- Backup & restore ----------------

    /**
     * Creates a password-protected copy of all records (AES-256). The file is put in
     * the app's private cache, ready to be shared (email, Google Drive, WhatsApp)
     * or saved; the password is never stored.
     */
    suspend fun createEncryptedBackup(context: Context, password: CharArray): File = withContext(Dispatchers.IO) {
        val db = context.container.database
        // Flush the write-ahead log into the main file so the copy is complete.
        db.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").use { it.moveToFirst() }
        val plain = context.getDatabasePath(AppDatabase.NAME).readBytes()
        val encrypted = BackupCrypto.encrypt(plain, password)
        plain.fill(0)
        val stamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HHmm", Locale.US))
        val out = File(reportsDir(context), "PaulMoneyTracker_backup_$stamp.pmtbackup")
        out.writeBytes(encrypted)
        AppLock.markBackedUp(context)
        out
    }

    /** True if the chosen file is a password-protected backup (false for older plain backups). */
    suspend fun isEncryptedBackup(context: Context, source: Uri): Boolean = withContext(Dispatchers.IO) {
        val header = ByteArray(8)
        val input = context.contentResolver.openInputStream(source) ?: error("Could not open the backup file")
        input.use { it.read(header) }
        BackupCrypto.isEncrypted(header)
    }

    /**
     * Replaces the database with a backup (password-protected, or a plain .db from version 1.0/1.1).
     * The file is decrypted and validated first; if anything is wrong, nothing is changed.
     * The caller must restart the app afterwards (see [restartApp]).
     */
    suspend fun restoreDatabase(context: Context, source: Uri, password: CharArray?) = withContext(Dispatchers.IO) {
        val input = context.contentResolver.openInputStream(source) ?: error("Could not open the backup file")
        val raw = input.use { it.readBytes() }
        val plain = if (BackupCrypto.isEncrypted(raw)) {
            requireNotNull(password) { "Enter the backup password" }
            try {
                BackupCrypto.decrypt(raw, password)
            } catch (e: WrongPasswordException) {
                throw IllegalArgumentException(e.message)
            }
        } else raw

        val tmp = File(context.cacheDir, "restore_candidate.db")
        tmp.writeBytes(plain)
        plain.fill(0)
        try {
            validateBackup(tmp)
            context.container.database.close()
            val dbFile = context.getDatabasePath(AppDatabase.NAME)
            File(dbFile.path + "-wal").delete()
            File(dbFile.path + "-shm").delete()
            tmp.copyTo(dbFile, overwrite = true)
        } finally {
            tmp.delete()
        }
    }

    private fun validateBackup(file: File) {
        val header = ByteArray(16)
        file.inputStream().use { it.read(header) }
        require(String(header, Charsets.US_ASCII).startsWith("SQLite format 3")) {
            "That file is not a PaulMoneyTracker backup."
        }
        val db = SQLiteDatabase.openDatabase(file.path, null, SQLiteDatabase.OPEN_READONLY)
        try {
            val required = listOf("accounts", "income_transactions", "allocations", "account_transactions")
            required.forEach { table ->
                db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name=?", arrayOf(table)).use {
                    require(it.moveToFirst()) { "That file is not a PaulMoneyTracker backup." }
                }
            }
            require(db.version <= DB_VERSION) {
                "This backup was made by a newer version of the app. Update the app, then restore."
            }
        } finally {
            db.close()
        }
    }

    /** Restarts the app so it opens the restored database cleanly. */
    fun restartApp(activity: Activity) {
        val launch = activity.packageManager.getLaunchIntentForPackage(activity.packageName) ?: return
        val restart = Intent.makeRestartActivityTask(launch.component)
        activity.startActivity(restart)
        Runtime.getRuntime().exit(0)
    }

    private const val DB_VERSION = 2
}
