package com.babylon.moneytracker.export

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import androidx.core.content.FileProvider
import com.babylon.moneytracker.container
import com.babylon.moneytracker.data.db.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Sharing, saving and database backup/restore. All file work runs off the main thread. */
object FileActions {

    fun reportsDir(context: Context): File = File(context.cacheDir, "reports").apply { mkdirs() }

    /** Opens Android's share sheet for a generated file. */
    fun share(context: Context, file: File, mime: String) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, file.name)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(
            Intent.createChooser(send, "Share ${file.name}").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    /** Copies a generated file to a location the user picked with the system file picker. */
    suspend fun copyToUri(context: Context, file: File, target: Uri) = withContext(Dispatchers.IO) {
        val out = context.contentResolver.openOutputStream(target) ?: error("Could not open the selected location")
        out.use { o -> file.inputStream().use { it.copyTo(o) } }
    }

    // ---------------- Backup & restore ----------------

    /** Writes a complete copy of the database to [target]. */
    suspend fun backupDatabase(context: Context, target: Uri) = withContext(Dispatchers.IO) {
        val db = context.container.database
        // Flush the write-ahead log into the main file so the copy is complete.
        db.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").use { it.moveToFirst() }
        val dbFile = context.getDatabasePath(AppDatabase.NAME)
        val out = context.contentResolver.openOutputStream(target) ?: error("Could not open the selected location")
        out.use { o -> dbFile.inputStream().use { it.copyTo(o) } }
    }

    /**
     * Replaces the database with a backup file. The file is validated first;
     * if it is not a PaulMoneyTracker backup, nothing is changed.
     * The caller must restart the app afterwards (see [restartApp]).
     */
    suspend fun restoreDatabase(context: Context, source: Uri) = withContext(Dispatchers.IO) {
        val tmp = File(context.cacheDir, "restore_candidate.db")
        val input = context.contentResolver.openInputStream(source) ?: error("Could not open the backup file")
        input.use { i -> tmp.outputStream().use { i.copyTo(it) } }

        validateBackup(tmp)

        context.container.database.close()
        val dbFile = context.getDatabasePath(AppDatabase.NAME)
        File(dbFile.path + "-wal").delete()
        File(dbFile.path + "-shm").delete()
        tmp.copyTo(dbFile, overwrite = true)
        tmp.delete()
    }

    private fun validateBackup(file: File) {
        val header = ByteArray(16)
        file.inputStream().use { it.read(header) }
        require(String(header, Charsets.US_ASCII).startsWith("SQLite format 3")) {
            "That file is not a PaulMoneyTracker backup."
        }
        val db = SQLiteDatabase.openDatabase(file.path, null, SQLiteDatabase.OPEN_READONLY)
        try {
            val required = listOf("accounts", "income_transactions", "allocations", "account_transactions")
            required.forEach { table ->
                db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name=?", arrayOf(table)).use {
                    require(it.moveToFirst()) { "That file is not a PaulMoneyTracker backup." }
                }
            }
            require(db.version <= DB_VERSION) {
                "This backup was made by a newer version of the app. Update the app, then restore."
            }
        } finally {
            db.close()
        }
    }

    /** Restarts the app so it opens the restored database cleanly. */
    fun restartApp(activity: Activity) {
        val launch = activity.packageManager.getLaunchIntentForPackage(activity.packageName) ?: return
        val restart = Intent.makeRestartActivityTask(launch.component)
        activity.startActivity(restart)
        Runtime.getRuntime().exit(0)
    }

    private const val DB_VERSION = 2
}
