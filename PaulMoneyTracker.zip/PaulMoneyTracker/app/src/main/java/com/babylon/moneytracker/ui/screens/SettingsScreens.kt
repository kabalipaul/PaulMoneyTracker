package com.babylon.moneytracker.ui.screens

import android.Manifest
import android.app.Activity
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.babylon.moneytracker.BuildConfig
import com.babylon.moneytracker.data.percentages
import com.babylon.moneytracker.domain.AccountType
import com.babylon.moneytracker.domain.AllocationCalculator
import com.babylon.moneytracker.domain.Money
import com.babylon.moneytracker.domain.Percentages
import com.babylon.moneytracker.domain.ThemeMode
import com.babylon.moneytracker.export.FileActions
import com.babylon.moneytracker.reminder.NotificationHelper
import com.babylon.moneytracker.security.AppLock
import com.babylon.moneytracker.security.BackupCrypto
import com.babylon.moneytracker.ui.AppState
import com.babylon.moneytracker.ui.AppViewModels
import com.babylon.moneytracker.ui.Routes
import com.babylon.moneytracker.ui.SettingsViewModel
import com.babylon.moneytracker.ui.components.ChipRow
import com.babylon.moneytracker.ui.components.ConfirmDialog
import com.babylon.moneytracker.ui.components.LabelValue
import com.babylon.moneytracker.ui.components.LocalMoney
import com.babylon.moneytracker.ui.components.ScreenTopBar
import com.babylon.moneytracker.ui.components.SectionCard
import com.babylon.moneytracker.ui.theme.uiColor
import kotlinx.coroutines.launch
import java.io.File
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun SettingsScreen(state: AppState, nav: NavController) {
    val vm: SettingsViewModel = viewModel(factory = AppViewModels.Factory)
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val s = state.settings
    val r = state.reminder
    fun toast(msg: String) = Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

    // ----- notification permission state (re-checked whenever the screen resumes) -----
    var canNotify by remember { mutableStateOf(NotificationHelper.canPost(context)) }
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    LaunchedEffect(lifecycle) {
        lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED) { canNotify = NotificationHelper.canPost(context) }
    }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        canNotify = NotificationHelper.canPost(context)
        if (!granted) toast("Notifications are off. You can turn them on in Android settings.")
    }

    // ----- backup / restore / export -----
    /** A file ready to share or save, with its type. */
    var pendingFile by remember { mutableStateOf<Pair<File, String>?>(null) }
    var askBackupPassword by remember { mutableStateOf(false) }
    var working by remember { mutableStateOf(false) }
    var restoreUri by remember { mutableStateOf<android.net.Uri?>(null) }
    var restoreEncrypted by remember { mutableStateOf(false) }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            vm.checkBackupType(uri) { encrypted, err ->
                if (encrypted == null) toast(err ?: "Could not read the file")
                else {
                    restoreEncrypted = encrypted
                    restoreUri = uri
                }
            }
        }
    }
    val saveFileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri ->
        val f = pendingFile?.first
        if (uri != null && f != null) scope.launch {
            try {
                FileActions.copyToUri(context, f, uri); toast("Saved ${f.name}")
            } catch (e: Exception) {
                toast(e.message ?: "Could not save")
            }
            pendingFile = null
        }
    }

    // ----- security -----
    val activity = context as? Activity
    var lockOn by remember { mutableStateOf(AppLock.isEnabled(context)) }
    var bioOn by remember { mutableStateOf(AppLock.biometricEnabled(context)) }
    var hideOn by remember { mutableStateOf(AppLock.hideContent(context)) }
    var timeout by remember { mutableStateOf(AppLock.timeoutMs(context)) }
    val bioAvailable = remember { AppLock.biometricAvailable(context) }
    // Refresh after returning from the PIN setup screen.
    LaunchedEffect(lifecycle) {
        lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED) {
            lockOn = AppLock.isEnabled(context)
            bioOn = AppLock.biometricEnabled(context)
        }
    }
    val lastBackup = remember(pendingFile) { AppLock.lastBackupAt(context) }

    // ----- editable fields -----
    var code by rememberSaveable(s.currencyCode) { mutableStateOf(s.currencyCode) }
    var symbol by rememberSaveable(s.currencySymbol) { mutableStateOf(s.currencySymbol) }
    var decimals by rememberSaveable(s.currencyDecimals) { mutableIntStateOf(s.currencyDecimals) }
    val names = AccountType.entries.associateWith { t ->
        rememberSaveable(state.name(t)) { mutableStateOf(state.name(t)) }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenTopBar("Settings", onBack = { nav.popBackStack() })
        Column(
            Modifier
                .fillMaxSize()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            // Security
            SectionCard(title = "Security and privacy") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("App lock (PIN)")
                        Text(
                            if (lockOn) "A PIN is needed to open the app." else "Anyone holding your unlocked phone can open the app.",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (lockOn) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.error,
                        )
                    }
                    Switch(
                        checked = lockOn,
                        onCheckedChange = { on -> nav.navigate(Routes.pinSetup(if (on) "set" else "remove")) },
                    )
                }
                if (lockOn) {
                    TextButton(onClick = { nav.navigate(Routes.pinSetup("change")) }) { Text("Change PIN") }
                    if (bioAvailable) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Unlock with fingerprint or face", modifier = Modifier.weight(1f))
                            Switch(checked = bioOn, onCheckedChange = {
                                AppLock.setBiometric(context, it); bioOn = AppLock.biometricEnabled(context)
                            })
                        }
                    }
                    Text("Lock again after the app is in the background for", style = MaterialTheme.typography.bodySmall)
                    ChipRow(
                        AppLock.TIMEOUT_OPTIONS.map { it.first }, timeout,
                        { ms -> AppLock.TIMEOUT_OPTIONS.first { it.first == ms }.second },
                        { AppLock.setTimeout(context, it); timeout = it },
                    )
                }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Hide in recent apps and block screenshots")
                        Text(
                            "Stops your balances from showing in the app switcher or in screenshots.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(checked = hideOn, onCheckedChange = { on ->
                        activity?.let { AppLock.setHideContent(it, on) }; hideOn = on
                    })
                }
                Spacer(Modifier.height(8.dp))
                Text(
                    "Your records stay only on this phone. The app has no internet access, so it cannot send data " +
                        "anywhere, and it is excluded from Google's automatic cloud backup. Use the encrypted backup below " +
                        "to keep a copy safe.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            // Allocation
            SectionCard(title = "Allocation percentages", onClick = { nav.navigate(Routes.ALLOCATION) }) {
                AccountType.entries.forEach { t ->
                    LabelValue(state.name(t), "${Money.formatPercent(s.percentages().of(t))}%", valueColor = t.uiColor())
                }
                Text("Tap to change", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
            }

            // Reminders
            SectionCard(title = "Daily reminder") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Remind me to record income")
                        Text(
                            "Sent only if you haven't recorded income that day.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(checked = r.enabled, onCheckedChange = { vm.saveReminder(r.copy(enabled = it)) })
                }
                Spacer(Modifier.height(8.dp))
                val time = LocalTime.of(r.hour, r.minute).format(DateTimeFormatter.ofPattern("h:mm a", Locale.US))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Reminder time", modifier = Modifier.weight(1f))
                    TextButton(enabled = r.enabled, onClick = {
                        TimePickerDialog(context, { _, h, m ->
                            vm.saveReminder(r.copy(hour = h, minute = m)) { err -> if (err != null) toast(err) }
                        }, r.hour, r.minute, false).show()
                    }) { Text(time) }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Confirm when already recorded")
                        Text(
                            "Send a short “well done” instead of staying silent.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(
                        checked = r.confirmWhenRecorded,
                        enabled = r.enabled,
                        onCheckedChange = { vm.saveReminder(r.copy(confirmWhenRecorded = it)) },
                    )
                }
                if (!canNotify) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Notifications are blocked, so reminders can't appear.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                    FilledTonalButton(onClick = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                            (context as? Activity)?.shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS) != false
                        ) {
                            permission.launch(Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            context.startActivity(
                                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                                    .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                    }) { Text("Allow notifications") }
                }
            }

            // Currency
            SectionCard(title = "Currency") {
                Text("Quick choice", style = MaterialTheme.typography.labelLarge)
                ChipRow(
                    CURRENCY_PRESETS, CURRENCY_PRESETS.firstOrNull { it.first == code && it.second == symbol && it.third == decimals },
                    { it.first },
                    { code = it.first; symbol = it.second; decimals = it.third },
                )
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(code, { code = it.take(5) }, label = { Text("Code") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(symbol, { symbol = it.take(5) }, label = { Text("Symbol") }, singleLine = true, modifier = Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
                Text("Decimal places", style = MaterialTheme.typography.labelLarge)
                ChipRow(listOf(0, 2), decimals, { if (it == 0) "None (e.g. UGX 3,500)" else "2 (e.g. $ 3.98)" }, { decimals = it })
                Spacer(Modifier.height(4.dp))
                Text(
                    "Example: ${Money.format(398, symbol, decimals)} · ${Money.format(150_000_000, symbol, decimals)}. " +
                        "With 2 decimal places every amount field accepts cents, such as 3.98. Changing currency only " +
                        "changes how amounts are shown and typed; it does not convert existing records.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(8.dp))
                Button(onClick = { vm.setCurrency(code, symbol, decimals) { err -> toast(err ?: "Currency saved") } }) {
                    Text("Save currency")
                }
            }

            // Account names
            SectionCard(title = "Account names") {
                AccountType.entries.forEach { t ->
                    val st = names.getValue(t)
                    OutlinedTextField(
                        value = st.value,
                        onValueChange = { st.value = it.take(40) },
                        label = { Text(t.defaultName) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    )
                }
                Button(onClick = {
                    vm.renameAccounts(names.mapValues { it.value.value }) { err -> toast(err ?: "Names saved") }
                }) { Text("Save names") }
            }

            // Theme
            SectionCard(title = "Appearance") {
                ChipRow(
                    ThemeMode.entries, s.themeMode,
                    { when (it) { ThemeMode.SYSTEM -> "Follow system"; ThemeMode.LIGHT -> "Light"; ThemeMode.DARK -> "Dark" } },
                    { vm.setTheme(it) },
                )
            }

            // Data
            SectionCard(title = "Backup and moving to a new phone") {
                Text(
                    if (lastBackup == 0L) "You have not made a backup yet."
                    else "Last backup: ${java.time.Instant.ofEpochMilli(lastBackup).atZone(java.time.ZoneId.systemDefault()).toLocalDate().format(DateTimeFormatter.ofPattern("d MMM yyyy", Locale.US))}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (lastBackup == 0L) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    "A backup is a single file locked with a password you choose (AES-256 encryption). Send it to your " +
                        "email or Google Drive so you can recover everything if this phone is lost. To move to a new phone: " +
                        "install PaulMoneyTracker there, then use Restore with this file and its password.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(10.dp))
                Button(onClick = { askBackupPassword = true }, enabled = !working, modifier = Modifier.fillMaxWidth()) {
                    Text(if (working) "Working…" else "Create encrypted backup")
                }
                OutlinedButton(onClick = { restoreLauncher.launch(arrayOf("*/*")) }, enabled = !working, modifier = Modifier.fillMaxWidth()) {
                    Text("Restore from backup")
                }
                OutlinedButton(onClick = {
                    vm.exportAll { file, err ->
                        if (file != null) pendingFile = file to "text/csv" else toast(err ?: "Export failed")
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("Export all records (CSV)") }
                Text(
                    "CSV exports are not encrypted: anyone who opens the file can read it.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }

            // About
            SectionCard(title = "About") {
                LabelValue("Version", BuildConfig.VERSION_NAME)
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                Text(
                    "PaulMoneyTracker follows the lessons of “The Richest Man in Babylon” by George S. Clason: " +
                        "keep a part of all you earn, control your spending, make your savings work, and pay what you owe. " +
                        "Works fully offline. No account, no bank connection.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    pendingFile?.let { (file, mime) ->
        val isBackup = file.name.endsWith(".pmtbackup")
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { pendingFile = null },
            title = { Text(if (isBackup) "Backup ready" else "Export ready") },
            text = {
                Text(
                    if (isBackup) "${file.name}\n\nTap Share and choose Gmail (send it to yourself) or Google Drive, so the " +
                        "backup is safe even if this phone is lost. Keep the password somewhere safe too: without it the " +
                        "backup cannot be opened."
                    else file.name
                )
            },
            confirmButton = {
                TextButton(onClick = { FileActions.share(context, file, mime); pendingFile = null }) { Text("Share") }
            },
            dismissButton = { TextButton(onClick = { saveFileLauncher.launch(file.name) }) { Text("Save to phone") } },
        )
    }

    if (askBackupPassword) {
        BackupPasswordDialog(
            confirm = true,
            title = "Protect your backup",
            onDismiss = { askBackupPassword = false },
            onPassword = { pw ->
                askBackupPassword = false
                working = true
                vm.createBackup(pw) { file, err ->
                    working = false
                    if (file != null) pendingFile = file to "application/octet-stream" else toast(err ?: "Backup failed")
                }
            },
        )
    }

    restoreUri?.let { uri ->
        if (restoreEncrypted) {
            BackupPasswordDialog(
                confirm = false,
                title = "Restore backup",
                note = "All records currently in the app will be replaced by the backup, and the app will restart.",
                onDismiss = { restoreUri = null },
                onPassword = { pw ->
                    working = true
                    vm.restore(uri, pw) { err ->
                        working = false
                        if (err != null) toast(err)
                        else {
                            restoreUri = null
                            activity?.let { FileActions.restartApp(it) }
                        }
                    }
                },
            )
        } else {
            ConfirmDialog(
                title = "Restore this backup?",
                text = "This is an older backup without a password. All records currently in the app will be replaced by " +
                    "it and the app will restart.",
                confirmLabel = "Restore",
                destructive = true,
                onConfirm = {
                    vm.restore(uri, null) { err ->
                        if (err != null) toast(err) else activity?.let { FileActions.restartApp(it) }
                    }
                },
                onDismiss = { restoreUri = null },
            )
        }
    }
}

private val CURRENCY_PRESETS = listOf(
    Triple("UGX", "UGX", 0),
    Triple("USD", "$", 2),
    Triple("EUR", "€", 2),
    Triple("GBP", "£", 2),
    Triple("KES", "KSh", 2),
    Triple("TZS", "TSh", 0),
    Triple("RWF", "FRw", 0),
)

/** Asks for a backup password (twice when [confirm] is true). */
@Composable
private fun BackupPasswordDialog(
    confirm: Boolean,
    title: String,
    onDismiss: () -> Unit,
    onPassword: (String) -> Unit,
    note: String? = null,
) {
    var pw by remember { mutableStateOf("") }
    var pw2 by remember { mutableStateOf("") }
    var show by remember { mutableStateOf(false) }
    val longEnough = pw.length >= BackupCrypto.MIN_PASSWORD
    val same = !confirm || pw == pw2
    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                note?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                OutlinedTextField(
                    value = pw, onValueChange = { pw = it }, singleLine = true,
                    label = { Text("Backup password") },
                    visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth(),
                )
                if (confirm) {
                    OutlinedTextField(
                        value = pw2, onValueChange = { pw2 = it }, singleLine = true,
                        label = { Text("Repeat password") },
                        isError = pw2.isNotEmpty() && !same,
                        visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Text(
                        "At least ${BackupCrypto.MIN_PASSWORD} characters. It cannot be recovered: if you forget it, the backup " +
                            "cannot be opened. Don't reuse your app PIN.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = show, onCheckedChange = { show = it })
                    Spacer(Modifier.width(8.dp))
                    Text("Show password", style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onPassword(pw) }, enabled = longEnough && same) {
                Text(if (confirm) "Create backup" else "Restore")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun AllocationSettingsScreen(state: AppState, nav: NavController) {
    val vm: SettingsViewModel = viewModel(factory = AppViewModels.Factory)
    val context = LocalContext.current
    val fmt = LocalMoney.current
    val current = state.settings.percentages()
    val fields = AccountType.entries.associateWith { t ->
        rememberSaveable { mutableStateOf(Money.formatPercent(current.of(t))) }
    }
    var confirm by remember { mutableStateOf(false) }

    val parsed = AccountType.entries.associateWith { Money.parsePercent(fields.getValue(it).value) }
    val allValid = parsed.values.all { it != null }
    val p = if (allValid) Percentages(
        parsed.getValue(AccountType.LIVING)!!, parsed.getValue(AccountType.SAVINGS)!!,
        parsed.getValue(AccountType.INVESTMENTS)!!, parsed.getValue(AccountType.GIVING)!!,
    ) else null
    val total = parsed.values.sumOf { it ?: 0 }
    val ok = p != null && p.isValid

    Column(Modifier.fillMaxSize()) {
        ScreenTopBar("Allocation percentages", onBack = { nav.popBackStack() })
        Column(
            Modifier
                .fillMaxSize()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                "New percentages apply only to income you record from now on. Income already recorded keeps the split it was given.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            AccountType.entries.forEach { t ->
                val st = fields.getValue(t)
                OutlinedTextField(
                    value = st.value,
                    onValueChange = { v -> st.value = v.filter { it.isDigit() || it == '.' }.take(6) },
                    label = { Text(state.name(t)) },
                    suffix = { Text("%") },
                    singleLine = true,
                    isError = parsed.getValue(t) == null,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            Text(
                "Total: ${Money.formatPercent(total)}%" + if (total != Percentages.FULL) " — must be exactly 100%" else " ✓",
                style = MaterialTheme.typography.titleMedium,
                color = if (ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
            )
            if (ok && p != null) {
                SectionCard(title = "Preview on ${fmt(10_000_000)}") {
                    val split = AllocationCalculator.allocate(10_000_000, p, Money.allocationUnit(state.settings.currencyDecimals))
                    AccountType.entries.forEach { t -> LabelValue(state.name(t), fmt(split.of(t)), valueColor = t.uiColor()) }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = {
                    AccountType.entries.forEach { t -> fields.getValue(t).value = Money.formatPercent(Percentages.DEFAULT.of(t)) }
                }, modifier = Modifier.weight(1f)) { Text("Reset to 70-10-10-10") }
                Button(onClick = { confirm = true }, enabled = ok && p != current, modifier = Modifier.weight(1f)) {
                    Text("Apply")
                }
            }
        }
    }

    if (confirm && p != null) {
        ConfirmDialog(
            title = "Apply new percentages?",
            text = AccountType.entries.joinToString("\n") { "${state.name(it)}: ${Money.formatPercent(p.of(it))}%" } +
                "\n\nOnly income recorded from now on will use these. Your existing records will not change.",
            confirmLabel = "Apply",
            onConfirm = {
                vm.setPercentages(p) { err ->
                    if (err != null) Toast.makeText(context, err, Toast.LENGTH_LONG).show()
                    else {
                        Toast.makeText(context, "New percentages saved", Toast.LENGTH_SHORT).show()
                        nav.popBackStack()
                    }
                }
            },
            onDismiss = { confirm = false },
        )
    }
}
