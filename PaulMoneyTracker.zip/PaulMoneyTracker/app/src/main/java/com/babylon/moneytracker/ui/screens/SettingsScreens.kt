package com.babylon.moneytracker.ui.screens

import android.Manifest
import android.app.Activity
import android.app.TimePickerDialog
import android.content.Intent
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.babylon.moneytracker.BuildConfig
import com.babylon.moneytracker.data.percentages
import com.babylon.moneytracker.domain.AccountType
import com.babylon.moneytracker.domain.AllocationCalculator
import com.babylon.moneytracker.domain.Money
import com.babylon.moneytracker.domain.Percentages
import com.babylon.moneytracker.domain.ThemeMode
import com.babylon.moneytracker.export.FileActions
import com.babylon.moneytracker.reminder.NotificationHelper
import com.babylon.moneytracker.ui.AppState
import com.babylon.moneytracker.ui.AppViewModels
import com.babylon.moneytracker.ui.Routes
import com.babylon.moneytracker.ui.SettingsViewModel
import com.babylon.moneytracker.ui.components.ChipRow
import com.babylon.moneytracker.ui.components.ConfirmDialog
import com.babylon.moneytracker.ui.components.LabelValue
import com.babylon.moneytracker.ui.components.LocalMoney
import com.babylon.moneytracker.ui.components.ScreenTopBar
import com.babylon.moneytracker.ui.components.SectionCard
import com.babylon.moneytracker.ui.theme.uiColor
import kotlinx.coroutines.launch
import java.io.File
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun SettingsScreen(state: AppState, nav: NavController) {
    val vm: SettingsViewModel = viewModel(factory = AppViewModels.Factory)
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val s = state.settings
    val r = state.reminder
    fun toast(msg: String) = Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

    // ----- notification permission state (re-checked whenever the screen resumes) -----
    var canNotify by remember { mutableStateOf(NotificationHelper.canPost(context)) }
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    LaunchedEffect(lifecycle) {
        lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED) { canNotify = NotificationHelper.canPost(context) }
    }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        canNotify = NotificationHelper.canPost(context)
        if (!granted) toast("Notifications are off. You can turn them on in Android settings.")
    }

    // ----- backup / restore / export -----
    var pendingExport by remember { mutableStateOf<File?>(null) }
    var restoreUri by remember { mutableStateOf<android.net.Uri?>(null) }
    val backupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        if (uri != null) vm.backup(uri) { err -> toast(err ?: "Backup saved") }
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) restoreUri = uri
    }
    val saveCsvLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri ->
        val f = pendingExport
        if (uri != null && f != null) scope.launch {
            try {
                FileActions.copyToUri(context, f, uri); toast("Saved ${f.name}")
            } catch (e: Exception) {
                toast(e.message ?: "Could not save")
            }
            pendingExport = null
        }
    }

    // ----- editable fields -----
    var code by rememberSaveable(s.currencyCode) { mutableStateOf(s.currencyCode) }
    var symbol by rememberSaveable(s.currencySymbol) { mutableStateOf(s.currencySymbol) }
    var decimals by rememberSaveable(s.currencyDecimals) { mutableIntStateOf(s.currencyDecimals) }
    val names = AccountType.entries.associateWith { t ->
        rememberSaveable(state.name(t)) { mutableStateOf(state.name(t)) }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenTopBar("Settings", onBack = { nav.popBackStack() })
        Column(
            Modifier
                .fillMaxSize()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            // Allocation
            SectionCard(title = "Allocation percentages", onClick = { nav.navigate(Routes.ALLOCATION) }) {
                AccountType.entries.forEach { t ->
                    LabelValue(state.name(t), "${Money.formatPercent(s.percentages().of(t))}%", valueColor = t.uiColor())
                }
                Text("Tap to change", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
            }

            // Reminders
            SectionCard(title = "Daily reminder") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Remind me to record income")
                        Text(
                            "Sent only if you haven't recorded income that day.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(checked = r.enabled, onCheckedChange = { vm.saveReminder(r.copy(enabled = it)) })
                }
                Spacer(Modifier.height(8.dp))
                val time = LocalTime.of(r.hour, r.minute).format(DateTimeFormatter.ofPattern("h:mm a", Locale.US))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Reminder time", modifier = Modifier.weight(1f))
                    TextButton(enabled = r.enabled, onClick = {
                        TimePickerDialog(context, { _, h, m ->
                            vm.saveReminder(r.copy(hour = h, minute = m)) { err -> if (err != null) toast(err) }
                        }, r.hour, r.minute, false).show()
                    }) { Text(time) }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Confirm when already recorded")
                        Text(
                            "Send a short “well done” instead of staying silent.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(
                        checked = r.confirmWhenRecorded,
                        enabled = r.enabled,
                        onCheckedChange = { vm.saveReminder(r.copy(confirmWhenRecorded = it)) },
                    )
                }
                if (!canNotify) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Notifications are blocked, so reminders can't appear.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                    )
                    FilledTonalButton(onClick = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                            (context as? Activity)?.shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS) != false
                        ) {
                            permission.launch(Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            context.startActivity(
                                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                                    .putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                    }) { Text("Allow notifications") }
                }
            }

            // Currency
            SectionCard(title = "Currency") {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(code, { code = it.take(5) }, label = { Text("Code") }, singleLine = true, modifier = Modifier.weight(1f))
                    OutlinedTextField(symbol, { symbol = it.take(5) }, label = { Text("Symbol") }, singleLine = true, modifier = Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
                Text("Decimal places", style = MaterialTheme.typography.labelLarge)
                ChipRow(listOf(0, 2), decimals, { if (it == 0) "None (UGX)" else "2 (cents)" }, { decimals = it })
                Spacer(Modifier.height(4.dp))
                Text(
                    "Example: ${Money.format(150_000_000, symbol, decimals)}. Changing currency only changes how amounts are shown; " +
                        "it does not convert existing records.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(8.dp))
                Button(onClick = { vm.setCurrency(code, symbol, decimals) { err -> toast(err ?: "Currency saved") } }) {
                    Text("Save currency")
                }
            }

            // Account names
            SectionCard(title = "Account names") {
                AccountType.entries.forEach { t ->
                    val st = names.getValue(t)
                    OutlinedTextField(
                        value = st.value,
                        onValueChange = { st.value = it.take(40) },
                        label = { Text(t.defaultName) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    )
                }
                Button(onClick = {
                    vm.renameAccounts(names.mapValues { it.value.value }) { err -> toast(err ?: "Names saved") }
                }) { Text("Save names") }
            }

            // Theme
            SectionCard(title = "Appearance") {
                ChipRow(
                    ThemeMode.entries, s.themeMode,
                    { when (it) { ThemeMode.SYSTEM -> "Follow system"; ThemeMode.LIGHT -> "Light"; ThemeMode.DARK -> "Dark" } },
                    { vm.setTheme(it) },
                )
            }

            // Data
            SectionCard(title = "Your data") {
                Text(
                    "Everything is stored only on this phone. Back up regularly and keep the file somewhere safe " +
                        "(e.g. Google Drive or a computer).",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(Modifier.height(10.dp))
                Button(onClick = { backupLauncher.launch("paul_backup_${LocalDate.now()}.db") }, modifier = Modifier.fillMaxWidth()) {
                    Text("Back up database")
                }
                OutlinedButton(onClick = { restoreLauncher.launch(arrayOf("*/*")) }, modifier = Modifier.fillMaxWidth()) {
                    Text("Restore from backup")
                }
                OutlinedButton(onClick = {
                    vm.exportAll { file, err ->
                        if (file != null) pendingExport = file else toast(err ?: "Export failed")
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text("Export all records (CSV)") }
            }

            // About
            SectionCard(title = "About") {
                LabelValue("Version", BuildConfig.VERSION_NAME)
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                Text(
                    "PaulMoneyTracker follows the lessons of “The Richest Man in Babylon” by George S. Clason: " +
                        "keep a part of all you earn, control your spending, make your savings work, and pay what you owe. " +
                        "Works fully offline. No account, no bank connection.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    pendingExport?.let { file ->
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { pendingExport = null },
            title = { Text("Export ready") },
            text = { Text(file.name) },
            confirmButton = {
                TextButton(onClick = { FileActions.share(context, file, "text/csv"); pendingExport = null }) { Text("Share") }
            },
            dismissButton = { TextButton(onClick = { saveCsvLauncher.launch(file.name) }) { Text("Save to phone") } },
        )
    }

    restoreUri?.let { uri ->
        ConfirmDialog(
            title = "Restore this backup?",
            text = "All records currently in the app will be replaced by the backup. The app will restart.",
            confirmLabel = "Restore",
            destructive = true,
            onConfirm = {
                vm.restore(uri) { err ->
                    if (err != null) toast(err)
                    else (context as? Activity)?.let { FileActions.restartApp(it) }
                }
            },
            onDismiss = { restoreUri = null },
        )
    }
}

@Composable
fun AllocationSettingsScreen(state: AppState, nav: NavController) {
    val vm: SettingsViewModel = viewModel(factory = AppViewModels.Factory)
    val context = LocalContext.current
    val fmt = LocalMoney.current
    val current = state.settings.percentages()
    val fields = AccountType.entries.associateWith { t ->
        rememberSaveable { mutableStateOf(Money.formatPercent(current.of(t))) }
    }
    var confirm by remember { mutableStateOf(false) }

    val parsed = AccountType.entries.associateWith { Money.parsePercent(fields.getValue(it).value) }
    val allValid = parsed.values.all { it != null }
    val p = if (allValid) Percentages(
        parsed.getValue(AccountType.LIVING)!!, parsed.getValue(AccountType.SAVINGS)!!,
        parsed.getValue(AccountType.INVESTMENTS)!!, parsed.getValue(AccountType.GIVING)!!,
    ) else null
    val total = parsed.values.sumOf { it ?: 0 }
    val ok = p != null && p.isValid

    Column(Modifier.fillMaxSize()) {
        ScreenTopBar("Allocation percentages", onBack = { nav.popBackStack() })
        Column(
            Modifier
                .fillMaxSize()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                "New percentages apply only to income you record from now on. Income already recorded keeps the split it was given.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            AccountType.entries.forEach { t ->
                val st = fields.getValue(t)
                OutlinedTextField(
                    value = st.value,
                    onValueChange = { v -> st.value = v.filter { it.isDigit() || it == '.' }.take(6) },
                    label = { Text(state.name(t)) },
                    suffix = { Text("%") },
                    singleLine = true,
                    isError = parsed.getValue(t) == null,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            Text(
                "Total: ${Money.formatPercent(total)}%" + if (total != Percentages.FULL) " — must be exactly 100%" else " ✓",
                style = MaterialTheme.typography.titleMedium,
                color = if (ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
            )
            if (ok && p != null) {
                SectionCard(title = "Preview on ${fmt(10_000_000)}") {
                    val split = AllocationCalculator.allocate(10_000_000, p, Money.allocationUnit(state.settings.currencyDecimals))
                    AccountType.entries.forEach { t -> LabelValue(state.name(t), fmt(split.of(t)), valueColor = t.uiColor()) }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = {
                    AccountType.entries.forEach { t -> fields.getValue(t).value = Money.formatPercent(Percentages.DEFAULT.of(t)) }
                }, modifier = Modifier.weight(1f)) { Text("Reset to 70-10-10-10") }
                Button(onClick = { confirm = true }, enabled = ok && p != current, modifier = Modifier.weight(1f)) {
                    Text("Apply")
                }
            }
        }
    }

    if (confirm && p != null) {
        ConfirmDialog(
            title = "Apply new percentages?",
            text = AccountType.entries.joinToString("\n") { "${state.name(it)}: ${Money.formatPercent(p.of(it))}%" } +
                "\n\nOnly income recorded from now on will use these. Your existing records will not change.",
            confirmLabel = "Apply",
            onConfirm = {
                vm.setPercentages(p) { err ->
                    if (err != null) Toast.makeText(context, err, Toast.LENGTH_LONG).show()
                    else {
                        Toast.makeText(context, "New percentages saved", Toast.LENGTH_SHORT).show()
                        nav.popBackStack()
                    }
                }
            },
            onDismiss = { confirm = false },
        )
    }
}
