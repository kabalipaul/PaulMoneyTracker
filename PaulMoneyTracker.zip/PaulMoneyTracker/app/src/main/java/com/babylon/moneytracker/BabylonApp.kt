package com.babylon.moneytracker

import android.app.Application
import android.content.Context
import com.babylon.moneytracker.data.FinanceRepository
import com.babylon.moneytracker.data.SettingsRepository
import com.babylon.moneytracker.data.db.AppDatabase
import com.babylon.moneytracker.export.FileActions
import com.babylon.moneytracker.reminder.NotificationHelper
import com.babylon.moneytracker.reminder.ReminderScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** Simple manual dependency container: one database and one of each repository for the whole app. */
class AppContainer(context: Context) {
    val database: AppDatabase = AppDatabase.build(context.applicationContext)
    val finance = FinanceRepository(database)
    val settings = SettingsRepository(database)
}

class BabylonApp : Application() {
    lateinit var container: AppContainer
        private set

    val appScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        NotificationHelper.createChannel(this)
        FileActions.cleanTempFiles(this)
        appScope.launch {
            ReminderScheduler.reschedule(this@BabylonApp, container.settings.currentReminder())
        }
    }
}

val Context.container: AppContainer get() = (applicationContext as BabylonApp).container
