package com.babylon.moneytracker.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.babylon.moneytracker.domain.AccountType
import com.babylon.moneytracker.domain.FullReport
import com.babylon.moneytracker.domain.LoanDirection
import com.babylon.moneytracker.domain.LoanSideReport
import com.babylon.moneytracker.domain.LoanState
import com.babylon.moneytracker.domain.Money
import com.babylon.moneytracker.domain.ReportPeriod
import com.babylon.moneytracker.export.FileActions
import com.babylon.moneytracker.ui.AppState
import com.babylon.moneytracker.ui.AppViewModels
import com.babylon.moneytracker.ui.ExportKind
import com.babylon.moneytracker.ui.ReportsViewModel
import com.babylon.moneytracker.ui.components.BarChart
import com.babylon.moneytracker.ui.components.ChipRow
import com.babylon.moneytracker.ui.components.DateField
import com.babylon.moneytracker.ui.components.DateShort
import com.babylon.moneytracker.ui.components.DonutChart
import com.babylon.moneytracker.ui.components.EmptyNote
import com.babylon.moneytracker.ui.components.HorizontalBars
import com.babylon.moneytracker.ui.components.LabelValue
import com.babylon.moneytracker.ui.components.Legend
import com.babylon.moneytracker.ui.components.LineChart
import com.babylon.moneytracker.ui.components.LocalMoney
import com.babylon.moneytracker.ui.components.ProgressBar
import com.babylon.moneytracker.ui.components.ScreenTopBar
import com.babylon.moneytracker.ui.components.SectionCard
import com.babylon.moneytracker.ui.components.Slice
import com.babylon.moneytracker.ui.theme.Palette
import com.babylon.moneytracker.ui.theme.uiColor
import kotlinx.coroutines.launch
import java.io.File

private val reportTabs =
    listOf("Overview", "Financial position", "Income", "Allocation", "Expenses", "Savings", "Investments", "Loans")

@Composable
fun ReportsScreen(state: AppState, nav: NavController) {
    val vm: ReportsViewModel = viewModel(factory = AppViewModels.Factory)
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val period by vm.period.collectAsStateWithLifecycle()
    val custom by vm.customRange.collectAsStateWithLifecycle()
    val range by vm.range.collectAsStateWithLifecycle()
    val report by vm.report.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }

    var exported by remember { mutableStateOf<Pair<File, ExportKind>?>(null) }
    var busy by remember { mutableStateOf(false) }

    fun saveTo(uri: android.net.Uri?) {
        val file = exported?.first ?: return
        if (uri == null) return
        scope.launch {
            try {
                FileActions.copyToUri(context, file, uri)
                Toast.makeText(context, "Saved ${file.name}", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(context, e.message ?: "Could not save", Toast.LENGTH_LONG).show()
            }
            exported = null
        }
    }
    val savePdf = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { saveTo(it) }
    val saveCsv = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { saveTo(it) }

    fun export(kind: ExportKind) {
        busy = true
        vm.export(kind) { file, err ->
            busy = false
            if (file != null) exported = file to kind
            else Toast.makeText(context, err ?: "Export failed", Toast.LENGTH_LONG).show()
        }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenTopBar("Reports")
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            ChipRow(
                ReportPeriod.entries, period, { it.label }, { vm.selectPeriod(it) },
                modifier = Modifier.padding(horizontal = 16.dp),
            )
            if (period == ReportPeriod.CUSTOM) {
                Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    DateField("Start date", custom.start, { vm.setCustomRange(it, custom.end) }, Modifier.weight(1f))
                    DateField("End date", custom.end, { vm.setCustomRange(custom.start, it) }, Modifier.weight(1f))
                }
            }
            Text(
                range.label(),
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(horizontal = 16.dp),
            )
            Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { export(ExportKind.PDF) }, enabled = !busy, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.PictureAsPdf, contentDescription = null)
                    Spacer(Modifier.width(6.dp)); Text("Export PDF")
                }
                OutlinedButton(onClick = { export(ExportKind.CSV) }, enabled = !busy, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.TableChart, contentDescription = null)
                    Spacer(Modifier.width(6.dp)); Text("Export CSV")
                }
            }
            ScrollableTabRow(selectedTabIndex = tab, edgePadding = 16.dp, containerColor = MaterialTheme.colorScheme.background) {
                reportTabs.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) }) }
            }
            Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                val r = report
                if (r == null) {
                    EmptyNote("Preparing report…")
                } else when (tab) {
                    0 -> OverviewReport(state, r)
                    1 -> PositionReportView(state, r)
                    2 -> IncomeReportView(r)
                    3 -> AllocationReportView(state, r)
                    4 -> ExpenseReportView(r)
                    5 -> SavingsReportView(r)
                    6 -> InvestmentReportView(r)
                    else -> LoanReportView(r)
                }
            }
            Spacer(Modifier.height(88.dp))
        }
    }

    exported?.let { (file, kind) ->
        AlertDialog(
            onDismissRequest = { exported = null },
            title = { Text("Report ready") },
            text = { Text(file.name) },
            confirmButton = {
                TextButton(onClick = {
                    FileActions.share(context, file, kind.mime)
                    exported = null
                }) { Text("Share") }
            },
            dismissButton = {
                TextButton(onClick = {
                    if (kind == ExportKind.PDF) savePdf.launch(file.name) else saveCsv.launch(file.name)
                }) { Text("Save to phone") }
            },
        )
    }
}

@Composable
private fun OverviewReport(state: AppState, r: FullReport) {
    val fmt = LocalMoney.current
    val o = r.overall
    SectionCard(title = "Overall financial progress") {
        LabelValue("Total income", fmt(o.totalIncome), emphasize = true)
        LabelValue("Living expenses", fmt(o.livingExpenses))
        LabelValue("Allocated to savings", fmt(o.savingsAllocated))
        LabelValue("Investment contributions", fmt(o.investmentContributions))
        LabelValue("Debt repayment / giving", fmt(o.giving))
    }
    SectionCard(title = "Wealth growth") {
        LabelValue("Wealth at start", fmt(o.wealthAtStart))
        LabelValue("Wealth at end", fmt(o.wealthAtEnd), emphasize = true)
        val change = o.wealthAtEnd - o.wealthAtStart
        LabelValue(
            "Change",
            (if (change >= 0) "+" else "") + fmt(change),
            valueColor = if (change >= 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,
        )
        Spacer(Modifier.height(8.dp))
        LineChart(o.wealthGrowth, MaterialTheme.colorScheme.primary)
        Text(
            "Wealth = savings + uninvested investment cash + recorded investment value.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
    SectionCard(title = "Balances at end of period") {
        AccountType.entries.forEach { t ->
            LabelValue(state.name(t), fmt(o.balancesAtEnd[t] ?: 0), valueColor = t.uiColor())
        }
    }
}

@Composable
private fun IncomeReportView(r: FullReport) {
    val fmt = LocalMoney.current
    val i = r.income
    SectionCard(title = "Income") {
        LabelValue("Total income received", fmt(i.total), emphasize = true)
        LabelValue("Number of transactions", i.count.toString())
        LabelValue("Average per transaction", fmt(i.averagePerTransaction))
        LabelValue("Highest income day", i.highestDay?.let { "${it.date.format(DateShort)} · ${fmt(it.amount)}" } ?: "—")
        LabelValue("Lowest income day", i.lowestDay?.let { "${it.date.format(DateShort)} · ${fmt(it.amount)}" } ?: "—")
    }
    SectionCard(title = "Income trend") { LineChart(i.trend, MaterialTheme.colorScheme.primary) }
    SectionCard(title = "Monthly comparison") { BarChart(i.monthly, MaterialTheme.colorScheme.primary) }
    SectionCard(title = "Income by source") {
        if (i.bySource.isEmpty()) EmptyNote("No income in this period.")
        else HorizontalBars(i.bySource, MaterialTheme.colorScheme.primary, fmt::invoke)
    }
}

@Composable
private fun AllocationReportView(state: AppState, r: FullReport) {
    val fmt = LocalMoney.current
    val a = r.allocation
    SectionCard(title = "Allocation") {
        val slices = AccountType.entries.map { Slice(state.name(it), a.split.of(it), it.uiColor()) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            DonutChart(slices, size = 130.dp) {
                Text(Money.compact(a.totalIncome), style = MaterialTheme.typography.titleMedium)
            }
            Spacer(Modifier.width(16.dp))
            Legend(slices, fmt::invoke, Modifier.weight(1f))
        }
        Spacer(Modifier.height(8.dp))
        LabelValue("Total income", fmt(a.totalIncome), emphasize = true)
        AccountType.entries.forEach { t ->
            LabelValue(
                "${state.name(t)} (${String.format(java.util.Locale.US, "%.1f", (a.shares[t] ?: 0f) * 100)}%)",
                fmt(a.split.of(t)),
            )
        }
    }
    SectionCard(title = "Allocation over time") {
        if (a.overTime.all { it.second.total == 0L }) EmptyNote("No income in this period.")
        a.overTime.filter { it.second.total > 0 }.forEach { (label, split) ->
            Text(label, style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 6.dp))
            Row(Modifier.fillMaxWidth().height(10.dp)) {
                AccountType.entries.forEach { t ->
                    val w = split.of(t).toFloat() / split.total
                    if (w > 0f) {
                        Spacer(
                            Modifier
                                .weight(w)
                                .height(10.dp)
                                .then(Modifier.padding(end = 1.dp))
                                .background(t.uiColor())
                        )
                    }
                }
            }
            Text(
                AccountType.entries.joinToString("  ·  ") { "${Money.compact(split.of(it))}" },
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
private fun ExpenseReportView(r: FullReport) {
    val fmt = LocalMoney.current
    val e = r.expenditure
    SectionCard(title = "Expenditure") {
        LabelValue("Total expenses", fmt(e.total), emphasize = true)
        LabelValue("Living allocation received", fmt(e.livingAllocatedInPeriod))
        LabelValue("Remaining from period's allocation", fmt(e.remainingInPeriod))
        LabelValue("Living Expenses balance at end", fmt(e.livingBalanceAtEnd))
        e.byCategory.firstOrNull()?.let { LabelValue("Largest category", "${it.name} · ${fmt(it.amount)}") }
    }
    SectionCard(title = "Expenses by category") {
        if (e.byCategory.isEmpty()) EmptyNote("No expenses in this period.")
        else HorizontalBars(e.byCategory, Palette.Gold, fmt::invoke)
    }
    SectionCard(title = "Spending over the period") { BarChart(e.trend, Palette.Gold) }
    if (e.monthly.size > 1) {
        SectionCard(title = "Monthly spending") { BarChart(e.monthly, Palette.Bronze) }
    }
}

@Composable
private fun SavingsReportView(r: FullReport) {
    val fmt = LocalMoney.current
    val s = r.savings
    SectionCard(title = "Savings") {
        LabelValue("Contributions", fmt(s.contributions))
        LabelValue("Withdrawals", fmt(s.withdrawals))
        LabelValue("Savings balance at end", fmt(s.balanceAtEnd), emphasize = true)
        s.target?.let { t ->
            LabelValue("Savings target", fmt(t))
            LabelValue("Progress", "${((s.targetProgress ?: 0f) * 100).toInt()}%")
            ProgressBar(s.targetProgress ?: 0f, Palette.Gold)
        }
    }
    SectionCard(title = "Savings growth") { LineChart(s.growth, Palette.Gold) }
}

@Composable
private fun InvestmentReportView(r: FullReport) {
    val fmt = LocalMoney.current
    val i = r.investment
    SectionCard(title = "Investments") {
        LabelValue("Contributions (money invested)", fmt(i.contributions), emphasize = true)
        LabelValue("Returns recorded", fmt(i.returns))
        LabelValue("Capital cashed out", fmt(i.cashouts))
        LabelValue("Recorded value at end", fmt(i.holdingsValueAtEnd))
        LabelValue("Uninvested cash at end", fmt(i.cashBalanceAtEnd))
        Text(
            "Contributions are what you put in; returns are what investments paid you. " +
                "${i.contributionsWithValue} of ${i.totalContributionsCount} contributions in this period have a current value recorded.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
    SectionCard(title = "By investment type") {
        if (i.byType.isEmpty()) EmptyNote("No investments in this period.")
        else HorizontalBars(i.byType, Palette.Bronze, fmt::invoke)
    }
}

@Composable
private fun LoanReportView(r: FullReport) {
    val fmt = LocalMoney.current
    val lr = r.loans
    SectionCard(title = "Combined loan position") {
        LabelValue("Outstanding debts (I owe)", fmt(lr.borrowing.outstandingAtEnd), valueColor = Palette.Orange)
        LabelValue("Outstanding receivables (owed to me)", fmt(lr.lending.outstandingAtEnd), valueColor = MaterialTheme.colorScheme.primary)
        LabelValue(
            "Net loan position",
            (if (lr.netPositionAtEnd > 0) "+" else "") + fmt(lr.netPositionAtEnd),
            emphasize = true,
            valueColor = if (lr.netPositionAtEnd >= 0) MaterialTheme.colorScheme.primary else Palette.Orange,
        )
        LabelValue("Repayments made in period", fmt(lr.borrowing.repaidInPeriod))
        LabelValue("Repayments received in period", fmt(lr.lending.repaidInPeriod))
        if (lr.lending.interestInPeriod > 0) LabelValue("Interest earned in period", fmt(lr.lending.interestInPeriod))
        if (lr.borrowing.interestInPeriod > 0) LabelValue("Interest paid in period", fmt(lr.borrowing.interestInPeriod))
        Text(
            "Balances are as of the last day of the period.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
    LoanSideView("Borrowing (money I owe)", lr.borrowing)
    LoanSideView("Lending (money owed to me)", lr.lending)
}

@Composable
private fun LoanSideView(title: String, side: LoanSideReport) {
    val fmt = LocalMoney.current
    val borrowed = side.direction == LoanDirection.BORROWED
    val color = if (borrowed) Palette.Orange else MaterialTheme.colorScheme.primary
    SectionCard(title = title) {
        LabelValue(if (borrowed) "Money borrowed in period" else "Money lent in period", fmt(side.newPrincipal))
        LabelValue(if (borrowed) "Principal repaid in period" else "Principal recovered in period", fmt(side.principalRepaidInPeriod))
        if (side.interestInPeriod > 0) {
            LabelValue(if (borrowed) "Interest paid in period" else "Interest received in period", fmt(side.interestInPeriod))
        }
        LabelValue(
            if (borrowed) "Total outstanding debt" else "Total outstanding receivables",
            fmt(side.outstandingAtEnd), emphasize = true, valueColor = color,
        )
        if (side.byPerson.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Text(if (borrowed) "By creditor" else "By debtor", style = MaterialTheme.typography.labelLarge)
            side.byPerson.forEach { p ->
                LabelValue(
                    p.name + (p.nextDue?.let { " · due ${it.format(DateShort)}" } ?: ""),
                    "${fmt(p.outstanding)} of ${fmt(p.principal)}",
                )
            }
        } else {
            EmptyNote(if (borrowed) "No borrowing recorded up to this date." else "No lending recorded up to this date.")
        }
        if (side.upcoming.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Text("Due in the next 30 days", style = MaterialTheme.typography.labelLarge)
            side.upcoming.forEach { LoanLine(it) }
        }
        if (side.overdue.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Text("Overdue", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.error)
            side.overdue.forEach { LoanLine(it) }
        }
    }
}

@Composable
private fun LoanLine(s: LoanState) {
    val fmt = LocalMoney.current
    LabelValue(
        "${s.loan.counterparty} · ${s.loan.dueDate?.format(DateShort) ?: ""}",
        fmt(s.totalOutstanding),
        valueColor = if (s.isOverdue) MaterialTheme.colorScheme.error else Color.Unspecified,
    )
}

@Composable
private fun PositionReportView(state: AppState, r: FullReport) {
    val fmt = LocalMoney.current
    val p = r.position
    val e = p.end
    fun signed(v: Long) = (if (v > 0) "+" else "") + fmt(v)
    fun changeColor(v: Long): Color = if (v >= 0) Palette.Forest else Palette.Orange

    SectionCard(title = "Net worth on ${e.date.format(DateShort)}") {
        Text(
            fmt(e.netWorth),
            style = MaterialTheme.typography.headlineMedium,
            color = if (e.netWorth >= 0) MaterialTheme.colorScheme.primary else Palette.Orange,
        )
        LabelValue("On ${p.start.date.format(DateShort)}", fmt(p.start.netWorth))
        LabelValue("Change over the period", signed(p.netWorthChange), valueColor = changeColor(p.netWorthChange))
        Spacer(Modifier.height(8.dp))
        LineChart(p.netWorthTrend, MaterialTheme.colorScheme.primary)
        Text(
            "Net worth = everything you own (assets) − everything you owe (liabilities).",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }

    SectionCard(title = "What you own (assets)") {
        Text("Money in your accounts", style = MaterialTheme.typography.labelLarge)
        AccountType.entries.forEach { t ->
            LabelValue(
                state.name(t), fmt(e.cashIn(t)),
                valueColor = if (e.cashIn(t) < 0) MaterialTheme.colorScheme.error else Color.Unspecified,
            )
        }
        LabelValue("Total money in accounts", fmt(e.totalCash), emphasize = true)
        HorizontalDivider(Modifier.padding(vertical = 6.dp))
        LabelValue("Investments held (recorded value)", fmt(e.investmentsHeld))
        LabelValue("Money owed to me", fmt(e.receivables), valueColor = MaterialTheme.colorScheme.primary)
        HorizontalDivider(Modifier.padding(vertical = 6.dp))
        LabelValue("Total assets", fmt(e.totalAssets), emphasize = true)
        LabelValue("Change over the period", signed(e.totalAssets - p.start.totalAssets),
            valueColor = changeColor(e.totalAssets - p.start.totalAssets))
    }

    SectionCard(title = "What you owe (liabilities)") {
        LabelValue("Loans and debts outstanding", fmt(e.liabilities), valueColor = Palette.Orange)
        LabelValue("Total liabilities", fmt(e.liabilities), emphasize = true)
        LabelValue("Change over the period", signed(e.liabilities - p.start.liabilities))
    }

    SectionCard(title = "Health check") {
        val debtPct = (e.debtRatio * 100).toInt()
        LabelValue("Debt compared with assets", "$debtPct%",
            valueColor = when {
                debtPct >= 50 -> MaterialTheme.colorScheme.error
                debtPct >= 30 -> Palette.Orange
                else -> Palette.Forest
            })
        val kept = if (e.totalAssets > 0) ((e.cashIn(AccountType.SAVINGS) + e.investmentsHeld + e.cashIn(AccountType.INVESTMENTS)) * 100 / e.totalAssets) else 0L
        LabelValue("Savings and investments share of assets", "$kept%")
        Text(
            when {
                e.totalAssets <= 0 && e.liabilities <= 0 -> "Record some income to see your position."
                debtPct >= 50 -> "More than half of what you own is matched by debt. Focus on repaying loans."
                debtPct >= 30 -> "Debt is a sizeable share of your assets. Keep repayments on schedule."
                else -> "Your debt is low compared with what you own. Keep building savings and investments."
            },
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}
