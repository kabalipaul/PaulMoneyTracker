package com.babylon.moneytracker.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.KeyboardDoubleArrowLeft
import androidx.compose.material.icons.filled.KeyboardDoubleArrowRight
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.babylon.moneytracker.domain.AccountType
import com.babylon.moneytracker.domain.AllocationSplit
import com.babylon.moneytracker.domain.Money
import com.babylon.moneytracker.domain.ReportCalculator
import com.babylon.moneytracker.ui.AppState
import com.babylon.moneytracker.ui.Routes
import com.babylon.moneytracker.ui.components.DateLong
import com.babylon.moneytracker.ui.components.EmptyNote
import com.babylon.moneytracker.ui.components.LabelValue
import com.babylon.moneytracker.ui.components.LocalMoney
import com.babylon.moneytracker.ui.components.ScreenTopBar
import com.babylon.moneytracker.ui.components.SectionCard
import com.babylon.moneytracker.ui.components.TxRow
import com.babylon.moneytracker.ui.theme.uiColor
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.util.Locale

@Composable
fun CalendarScreen(state: AppState, nav: NavController) {
    val fmt = LocalMoney.current
    // Saved as strings so the selection survives rotation.
    var monthText by rememberSaveable { mutableStateOf(YearMonth.from(state.today).toString()) }
    var selectedText by rememberSaveable { mutableStateOf(state.today.toString()) }
    val month = YearMonth.parse(monthText)
    val selected = LocalDate.parse(selectedText)

    val summary = ReportCalculator.monthSummary(state.incomes, month)

    Column(Modifier.fillMaxSize()) {
        ScreenTopBar(
            title = "Income Calendar",
            actions = {
                TextButton(onClick = {
                    monthText = YearMonth.from(state.today).toString()
                    selectedText = state.today.toString()
                }) { Text("Today") }
            },
        )
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            // Month / year navigation
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { monthText = month.minusYears(1).toString() }) {
                    Icon(Icons.Filled.KeyboardDoubleArrowLeft, contentDescription = "Previous year")
                }
                IconButton(onClick = { monthText = month.minusMonths(1).toString() }) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, contentDescription = "Previous month")
                }
                Text(
                    month.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.US)),
                    style = MaterialTheme.typography.titleLarge,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = { monthText = month.plusMonths(1).toString() }) {
                    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = "Next month")
                }
                IconButton(onClick = { monthText = month.plusYears(1).toString() }) {
                    Icon(Icons.Filled.KeyboardDoubleArrowRight, contentDescription = "Next year")
                }
            }

            // Monthly summary
            SectionCard(title = "Month summary") {
                LabelValue("Total income", fmt(summary.total), emphasize = true)
                LabelValue("Days with income", "${summary.daysWithIncome} of ${month.lengthOfMonth()}")
                LabelValue("Average per income day", fmt(summary.averagePerIncomeDay))
                Spacer(Modifier.height(6.dp))
                HorizontalDivider()
                Spacer(Modifier.height(6.dp))
                SplitRows(state, summary.split)
            }

            // Calendar grid
            SectionCard {
                MonthGrid(
                    month = month,
                    today = state.today,
                    selected = selected,
                    dailyTotals = summary.dailyTotals,
                    onSelect = { selectedText = it.toString() },
                )
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.padding(end = 6.dp).height(10.dp).aspectRatio(1f).clip(RoundedCornerShape(3.dp)).background(MaterialTheme.colorScheme.primaryContainer))
                    Text("Income recorded", style = MaterialTheme.typography.labelSmall)
                    Spacer(Modifier.padding(horizontal = 8.dp))
                    Box(Modifier.padding(end = 6.dp).height(10.dp).aspectRatio(1f).border(1.5.dp, MaterialTheme.colorScheme.secondary, RoundedCornerShape(3.dp)))
                    Text("Today", style = MaterialTheme.typography.labelSmall)
                }
            }

            // Selected day details
            DayDetails(state, selected, nav)
            Spacer(Modifier.height(88.dp))
        }
    }
}

@Composable
private fun SplitRows(state: AppState, split: AllocationSplit) {
    val fmt = LocalMoney.current
    AccountType.entries.forEach { t ->
        LabelValue(state.name(t), fmt(split.of(t)), valueColor = t.uiColor())
    }
}

@Composable
private fun MonthGrid(
    month: YearMonth,
    today: LocalDate,
    selected: LocalDate,
    dailyTotals: Map<LocalDate, Long>,
    onSelect: (LocalDate) -> Unit,
) {
    val weekStart = DayOfWeek.MONDAY
    val days = (0..6).map { weekStart.plus(it.toLong()) }
    Row(Modifier.fillMaxWidth()) {
        days.forEach {
            Text(
                it.getDisplayName(TextStyle.SHORT, Locale.US),
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.weight(1f),
            )
        }
    }
    Spacer(Modifier.height(6.dp))
    val first = month.atDay(1)
    val leading = (first.dayOfWeek.value - weekStart.value + 7) % 7
    val cells = leading + month.lengthOfMonth()
    val rows = (cells + 6) / 7
    for (r in 0 until rows) {
        Row(Modifier.fillMaxWidth()) {
            for (c in 0 until 7) {
                val dayNum = r * 7 + c - leading + 1
                Box(Modifier.weight(1f).padding(2.dp)) {
                    if (dayNum in 1..month.lengthOfMonth()) {
                        val date = month.atDay(dayNum)
                        DayCell(
                            date = date,
                            total = dailyTotals[date],
                            isToday = date == today,
                            isSelected = date == selected,
                            onClick = { onSelect(date) },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DayCell(date: LocalDate, total: Long?, isToday: Boolean, isSelected: Boolean, onClick: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val hasIncome = total != null && total > 0
    val bg = when {
        isSelected -> scheme.primary
        hasIncome -> scheme.primaryContainer
        else -> Color.Transparent
    }
    val fg = when {
        isSelected -> scheme.onPrimary
        hasIncome -> scheme.onPrimaryContainer
        else -> scheme.onSurface
    }
    val shape = RoundedCornerShape(10.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .aspectRatio(0.8f)
            .clip(shape)
            .background(bg)
            .then(if (isToday && !isSelected) Modifier.border(1.5.dp, scheme.secondary, shape) else Modifier)
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(
            date.dayOfMonth.toString(),
            color = fg,
            fontWeight = if (isToday || hasIncome) FontWeight.Bold else FontWeight.Normal,
            style = MaterialTheme.typography.bodyMedium,
        )
        if (hasIncome) {
            Text(Money.compact(total!!), color = fg, fontSize = 10.sp, maxLines = 1)
        } else {
            Text("·", color = scheme.outline, fontSize = 10.sp)
        }
    }
}

@Composable
private fun DayDetails(state: AppState, date: LocalDate, nav: NavController) {
    val fmt = LocalMoney.current
    val entries = state.incomes.filter { it.date == date }
    val split = entries.fold(AllocationSplit.ZERO) { a, r -> a + r.split }
    SectionCard(title = date.format(DateLong)) {
        LabelValue("Total income", fmt(entries.sumOf { it.amount }), emphasize = true)
        if (entries.isEmpty()) {
            EmptyNote("No income recorded on this day.")
        } else {
            entries.forEach { r ->
                TxRow(
                    title = r.source,
                    subtitle = r.description ?: "Tap to edit",
                    amount = "+" + fmt(r.amount),
                    amountColor = MaterialTheme.colorScheme.primary,
                    onClick = { nav.navigate(Routes.income(id = r.id)) },
                )
            }
            Spacer(Modifier.height(4.dp))
            HorizontalDivider()
            Spacer(Modifier.height(4.dp))
            SplitRows(state, split)
        }
        Spacer(Modifier.height(10.dp))
        Button(onClick = { nav.navigate(Routes.income(date = date)) }, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Filled.Add, contentDescription = null)
            Spacer(Modifier.padding(horizontal = 4.dp))
            Text("Add income for this date")
        }
    }
}
