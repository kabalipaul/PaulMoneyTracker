package com.babylon.moneytracker.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import com.babylon.moneytracker.security.AppLock
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.babylon.moneytracker.domain.AccountSummary
import com.babylon.moneytracker.domain.AccountType
import com.babylon.moneytracker.domain.Money
import com.babylon.moneytracker.ui.AppState
import com.babylon.moneytracker.ui.Routes
import com.babylon.moneytracker.ui.components.DateShort
import com.babylon.moneytracker.ui.components.DonutChart
import com.babylon.moneytracker.ui.components.EmptyNote
import com.babylon.moneytracker.ui.components.LabelValue
import com.babylon.moneytracker.ui.components.Legend
import com.babylon.moneytracker.ui.components.LocalMoney
import com.babylon.moneytracker.ui.components.ProgressBar
import com.babylon.moneytracker.ui.components.ScreenTopBar
import com.babylon.moneytracker.ui.components.SectionCard
import com.babylon.moneytracker.ui.components.Slice
import com.babylon.moneytracker.ui.components.TxRow
import com.babylon.moneytracker.ui.theme.MoneyLarge
import com.babylon.moneytracker.ui.theme.Palette
import com.babylon.moneytracker.ui.theme.uiColor

@Composable
fun HomeScreen(state: AppState, nav: NavController) {
    val fmt = LocalMoney.current
    val o = state.overview
    Column(Modifier.fillMaxSize()) {
        ScreenTopBar(
            title = "PaulMoneyTracker",
            actions = {
                IconButton(onClick = { nav.navigate(Routes.SETTINGS) }) {
                    Icon(Icons.Filled.Settings, contentDescription = "Settings")
                }
            },
        )
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            WealthHero(state)

            // Gentle nudge to keep an off-phone copy of the data.
            val context = LocalContext.current
            val lastBackup = AppLock.lastBackupAt(context) // SharedPreferences are cached in memory, so this is cheap
            val hasData = state.incomes.isNotEmpty() || state.ledger.isNotEmpty()
            val stale = lastBackup == 0L || System.currentTimeMillis() - lastBackup > 14L * 24 * 3600 * 1000
            if (hasData && stale) {
                SectionCard(onClick = { nav.navigate(Routes.SETTINGS) }) {
                    Text("Back up your records", style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (lastBackup == 0L) "You have no backup yet. If this phone is lost, your records go with it. " +
                            "Tap to create an encrypted backup and send it to your email or Google Drive."
                        else "Your last backup is over two weeks old. Tap to make a fresh encrypted backup.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            // A. Income totals
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("Today", fmt(state.totals.today), Modifier.weight(1f))
                StatTile("This week", fmt(state.totals.week), Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("This month", fmt(state.totals.month), Modifier.weight(1f))
                StatTile("Since you started", fmt(state.totals.allTime), Modifier.weight(1f))
            }

            // B. Four envelopes
            Text("Your four accounts", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 4.dp))
            AccountType.entries.chunked(2).forEach { pair ->
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    pair.forEach { t ->
                        AccountCard(
                            summary = o.account(t),
                            name = state.name(t),
                            percentBp = state.settings.let {
                                when (t) {
                                    AccountType.LIVING -> it.livingBp
                                    AccountType.SAVINGS -> it.savingsBp
                                    AccountType.INVESTMENTS -> it.investmentsBp
                                    AccountType.GIVING -> it.givingBp
                                }
                            },
                            onClick = { nav.navigate(Routes.account(t)) },
                            modifier = Modifier.weight(1f),
                        )
                    }
                }
            }

            // Distribution chart
            SectionCard(title = "How your income has been distributed") {
                val slices = AccountType.entries.map { Slice(state.name(it), o.totalAllocated.of(it), it.uiColor()) }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    DonutChart(slices, size = 130.dp) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Total", style = MaterialTheme.typography.labelSmall)
                            Text(Money.compact(o.totalIncome), style = MaterialTheme.typography.titleMedium)
                        }
                    }
                    Spacer(Modifier.width(16.dp))
                    Legend(slices, fmt::invoke, Modifier.weight(1f))
                }
            }

            // Summary
            SectionCard(title = "Summary") {
                LabelValue("Total money earned", fmt(o.totalIncome), emphasize = true)
                LabelValue("Total amount allocated", fmt(o.totalAllocated.total))
                LabelValue("Total expenditure", fmt(o.totalExpenditure))
                LabelValue("Savings accumulated", fmt(o.savingsBalance))
                LabelValue("Total invested", fmt(o.investmentContributions))
                LabelValue("Investment returns", fmt(o.investmentReturns))
                if (state.loans.isNotEmpty()) {
                    LabelValue("Money I owe", fmt(state.loanTotals.owed), valueColor = Palette.Orange)
                    LabelValue("Money owed to me", fmt(state.loanTotals.receivable), valueColor = MaterialTheme.colorScheme.primary)
                }
            }

            // Recent income
            SectionCard(title = "Recent income") {
                if (state.incomes.isEmpty()) {
                    EmptyNote("No income recorded yet. Tap “Add Income” to record what you earned today.")
                } else {
                    state.incomes.take(5).forEach { r ->
                        TxRow(
                            title = r.source + (r.description?.let { " · $it" } ?: ""),
                            subtitle = r.date.format(DateShort),
                            amount = "+" + fmt(r.amount),
                            amountColor = MaterialTheme.colorScheme.primary,
                            onClick = { nav.navigate(Routes.income(id = r.id)) },
                        )
                    }
                }
            }
            Spacer(Modifier.height(88.dp)) // room for the floating button
        }
    }
}

@Composable
private fun WealthHero(state: AppState) {
    val fmt = LocalMoney.current
    val o = state.overview
    Card(
        colors = CardDefaults.cardColors(containerColor = Palette.Forest, contentColor = Color.White),
        shape = RoundedCornerShape(22.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(20.dp)) {
            val hasLoans = state.loans.isNotEmpty()
            Text(if (hasLoans) "Net wealth you have built" else "Wealth you have built", style = MaterialTheme.typography.labelLarge, color = Palette.LightGreen)
            Spacer(Modifier.height(4.dp))
            Text(fmt(state.netWealth), style = MoneyLarge, color = Color.White)
            Spacer(Modifier.height(4.dp))
            Text(
                (if (hasLoans) "Savings + investments + money owed to you − money you owe" else "Savings + investments") +
                    ", out of ${fmt(o.totalIncome)} earned",
                style = MaterialTheme.typography.bodySmall,
                color = Palette.LightGreen,
            )
            Spacer(Modifier.height(14.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Color.White.copy(alpha = 0.18f))
            ) {
                Box(
                    Modifier
                        .fillMaxWidth(state.netWealthProgress)
                        .height(10.dp)
                        .clip(RoundedCornerShape(50))
                        .background(Palette.Gold)
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "You have kept ${(state.netWealthProgress * 100).toInt()}% of everything you earned. " +
                    "A part of all you earn is yours to keep.",
                style = MaterialTheme.typography.bodySmall,
                color = Color.White.copy(alpha = 0.9f),
            )
        }
    }
}

@Composable
private fun StatTile(label: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
        shape = RoundedCornerShape(16.dp),
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(4.dp))
            Text(value, style = MaterialTheme.typography.titleMedium, maxLines = 1)
        }
    }
}

/** Label for the envelope's main use: Spent / Withdrawn / Invested / Used. */
fun usedLabel(t: AccountType): String = when (t) {
    AccountType.LIVING -> "Spent"
    AccountType.SAVINGS -> "Withdrawn"
    AccountType.INVESTMENTS -> "Invested"
    AccountType.GIVING -> "Used"
}

@Composable
fun AccountCard(
    summary: AccountSummary,
    name: String,
    percentBp: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val fmt = LocalMoney.current
    val color = summary.type.uiColor()
    Card(
        onClick = onClick,
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
        shape = RoundedCornerShape(18.dp),
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.width(4.dp).height(16.dp).clip(RoundedCornerShape(2.dp)).background(color))
                Spacer(Modifier.width(8.dp))
                Text(name, style = MaterialTheme.typography.labelLarge, maxLines = 2, modifier = Modifier.weight(1f))
            }
            Text(
                "${Money.formatPercent(percentBp)}% of income",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(10.dp))
            Text(
                fmt(summary.balance),
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = if (summary.balance < 0) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
            )
            Text(
                if (summary.type == AccountType.LIVING || summary.type == AccountType.GIVING) "remaining" else "current balance",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Spacer(Modifier.height(8.dp))
            ProgressBar(summary.usedFraction, color, height = 6)
            Spacer(Modifier.height(8.dp))
            MiniRow("Allocated", fmt(summary.allocated))
            MiniRow(usedLabel(summary.type), fmt(summary.used))
            if (summary.otherIn > 0 || summary.otherOut > 0) {
                MiniRow("Other in / out", "${Money.compact(summary.otherIn)} / ${Money.compact(summary.otherOut)}")
            }
        }
    }
}

@Composable
private fun MiniRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.labelSmall, maxLines = 1)
    }
}
