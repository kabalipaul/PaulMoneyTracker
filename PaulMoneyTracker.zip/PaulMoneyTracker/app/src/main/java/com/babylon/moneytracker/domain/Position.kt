package com.babylon.moneytracker.domain

import java.time.LocalDate

/**
 * Statement of financial position (a personal balance sheet) on one date:
 * what you own, what you owe, and the difference (net worth).
 */
data class PositionSnapshot(
    val date: LocalDate,
    /** Money held in each envelope (can be negative if an envelope is overspent). */
    val cash: Map<AccountType, Long>,
    /** Recorded value of money currently invested. */
    val investmentsHeld: Long,
    /** Money other people owe me (principal + interest). */
    val receivables: Long,
    /** Money I owe (principal + interest). */
    val liabilities: Long,
) {
    val totalCash: Long get() = cash.values.sum()
    val totalAssets: Long get() = totalCash + investmentsHeld + receivables
    val netWorth: Long get() = totalAssets - liabilities

    /** Share of assets financed by debt, 0..1 (0 when there are no assets). */
    val debtRatio: Float
        get() = if (totalAssets <= 0) 0f else (liabilities.toDouble() / totalAssets).toFloat().coerceAtLeast(0f)

    fun cashIn(t: AccountType): Long = cash[t] ?: 0L
}

data class PositionReport(
    /** Position at the close of the day before the period started. */
    val start: PositionSnapshot,
    /** Position at the end of the period. */
    val end: PositionSnapshot,
    val netWorthTrend: List<SeriesPoint>,
) {
    val netWorthChange: Long get() = end.netWorth - start.netWorth
}

object PositionCalculator {

    fun snapshot(
        incomes: List<IncomeRecord>,
        ledger: List<LedgerRecord>,
        loans: List<LoanRecord>,
        date: LocalDate,
        unit: Long = 1L,
    ): PositionSnapshot {
        val o = LedgerCalculator.overview(incomes, ledger, upTo = date)
        val states = loans.filter { !it.date.isAfter(date) }.map { LoanCalculator.compute(it, date, unit) }
        return PositionSnapshot(
            date = date,
            cash = AccountType.entries.associateWith { o.account(it).balance },
            investmentsHeld = o.investmentHoldingsValue,
            receivables = states.filter { it.loan.direction == LoanDirection.LENT }.sumOf { it.totalOutstanding },
            liabilities = states.filter { it.loan.direction == LoanDirection.BORROWED }.sumOf { it.totalOutstanding },
        )
    }

    fun report(
        incomes: List<IncomeRecord>,
        ledger: List<LedgerRecord>,
        loans: List<LoanRecord>,
        range: DateRange,
        unit: Long = 1L,
    ): PositionReport = PositionReport(
        start = snapshot(incomes, ledger, loans, range.start.minusDays(1), unit),
        end = snapshot(incomes, ledger, loans, range.end, unit),
        netWorthTrend = ReportCalculator.buckets(range).map { b ->
            SeriesPoint(b.label, snapshot(incomes, ledger, loans, b.end, unit).netWorth)
        },
    )
}
