package com.babylon.moneytracker.domain

import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

data class SeriesPoint(val label: String, val value: Long)
data class NamedAmount(val name: String, val amount: Long)
data class DayAmount(val date: LocalDate, val amount: Long)

data class Bucket(val label: String, val start: LocalDate, val end: LocalDate) {
    operator fun contains(d: LocalDate) = !d.isBefore(start) && !d.isAfter(end)
}

data class IncomeReport(
    val total: Long,
    val count: Int,
    val averagePerTransaction: Long,
    val highestDay: DayAmount?,
    val lowestDay: DayAmount?,
    val bySource: List<NamedAmount>,
    val trend: List<SeriesPoint>,
    val monthly: List<SeriesPoint>,
)

data class AllocationReport(
    val totalIncome: Long,
    val split: AllocationSplit,
    /** Actual share of income per envelope, 0..1. */
    val shares: Map<AccountType, Float>,
    val overTime: List<Pair<String, AllocationSplit>>,
)

data class ExpenditureReport(
    val total: Long,
    val byCategory: List<NamedAmount>,
    val trend: List<SeriesPoint>,
    val monthly: List<SeriesPoint>,
    val livingAllocatedInPeriod: Long,
    /** Living allocation received in the period minus expenses in the period. */
    val remainingInPeriod: Long,
    /** Living Expenses balance on the last day of the period. */
    val livingBalanceAtEnd: Long,
)

data class SavingsReport(
    /** Allocations + deposits + transfers in during the period. */
    val contributions: Long,
    /** Withdrawals + transfers out during the period. */
    val withdrawals: Long,
    val balanceAtEnd: Long,
    val growth: List<SeriesPoint>,
    val target: Long?,
    val targetProgress: Float?,
)

data class InvestmentReport(
    val contributions: Long,
    val returns: Long,
    val cashouts: Long,
    val holdingsValueAtEnd: Long,
    val contributionsWithValue: Int,
    val totalContributionsCount: Int,
    val byType: List<NamedAmount>,
    val cashBalanceAtEnd: Long,
)

data class OverallReport(
    val totalIncome: Long,
    val livingExpenses: Long,
    val savingsAllocated: Long,
    val investmentContributions: Long,
    val giving: Long,
    val balancesAtEnd: Map<AccountType, Long>,
    val wealthAtStart: Long,
    val wealthAtEnd: Long,
    val wealthGrowth: List<SeriesPoint>,
)

data class FullReport(
    val range: DateRange,
    val income: IncomeReport,
    val allocation: AllocationReport,
    val expenditure: ExpenditureReport,
    val savings: SavingsReport,
    val investment: InvestmentReport,
    val overall: OverallReport,
    val loans: LoanReport,
)

object ReportCalculator {

    private val dayFmt = DateTimeFormatter.ofPattern("d MMM", Locale.US)
    private val monthFmt = DateTimeFormatter.ofPattern("MMM yy", Locale.US)

    /** Daily buckets for up to a month, weekly up to ~4 months, monthly beyond. */
    fun buckets(range: DateRange): List<Bucket> {
        val out = mutableListOf<Bucket>()
        when {
            range.dayCount <= 31 -> {
                var d = range.start
                while (!d.isAfter(range.end)) {
                    out += Bucket(d.format(dayFmt), d, d); d = d.plusDays(1)
                }
            }
            range.dayCount <= 124 -> {
                var s = range.start
                while (!s.isAfter(range.end)) {
                    val e = minOf(s.plusDays(6), range.end)
                    out += Bucket(s.format(dayFmt), s, e); s = e.plusDays(1)
                }
            }
            else -> out += monthBuckets(range)
        }
        return out
    }

    fun monthBuckets(range: DateRange): List<Bucket> {
        val out = mutableListOf<Bucket>()
        var ym = YearMonth.from(range.start)
        val last = YearMonth.from(range.end)
        while (!ym.isAfter(last)) {
            val s = maxOf(ym.atDay(1), range.start)
            val e = minOf(ym.atEndOfMonth(), range.end)
            out += Bucket(ym.format(monthFmt), s, e)
            ym = ym.plusMonths(1)
        }
        return out
    }

    fun build(
        incomes: List<IncomeRecord>,
        ledger: List<LedgerRecord>,
        range: DateRange,
        savingsTarget: Long? = null,
        loans: List<LoanRecord> = emptyList(),
        today: LocalDate = range.end,
        unit: Long = 1L,
    ): FullReport {
        val inc = incomes.filter { it.date in range }
        val led = ledger.filter { it.date in range }
        val buckets = buckets(range)
        val months = monthBuckets(range)

        // ---------- Income ----------
        val total = inc.sumOf { it.amount }
        val byDay = inc.groupBy { it.date }.map { (d, l) -> DayAmount(d, l.sumOf { it.amount }) }
        val income = IncomeReport(
            total = total,
            count = inc.size,
            averagePerTransaction = if (inc.isEmpty()) 0 else total / inc.size,
            highestDay = byDay.maxWithOrNull(compareBy<DayAmount> { it.amount }.thenBy { it.date }),
            lowestDay = byDay.minWithOrNull(compareBy<DayAmount> { it.amount }.thenBy { it.date }),
            bySource = inc.groupBy { it.source }
                .map { (s, l) -> NamedAmount(s, l.sumOf { it.amount }) }
                .sortedByDescending { it.amount },
            trend = buckets.map { b -> SeriesPoint(b.label, inc.filter { it.date in b }.sumOf { it.amount }) },
            monthly = months.map { b -> SeriesPoint(b.label, inc.filter { it.date in b }.sumOf { it.amount }) },
        )

        // ---------- Allocation ----------
        val split = inc.fold(AllocationSplit.ZERO) { a, r -> a + r.split }
        val allocation = AllocationReport(
            totalIncome = total,
            split = split,
            shares = AccountType.entries.associateWith {
                if (total == 0L) 0f else (split.of(it).toDouble() / total).toFloat()
            },
            overTime = months.map { b ->
                b.label to inc.filter { it.date in b }.fold(AllocationSplit.ZERO) { a, r -> a + r.split }
            },
        )

        // ---------- Expenditure ----------
        val expenses = led.filter { it.type == TxType.EXPENSE }
        val expTotal = expenses.sumOf { it.amount }
        val endOverview = LedgerCalculator.overview(incomes, ledger, upTo = range.end)
        val expenditure = ExpenditureReport(
            total = expTotal,
            byCategory = expenses.groupBy { it.expenseCategory ?: "Other" }
                .map { (c, l) -> NamedAmount(c, l.sumOf { it.amount }) }
                .sortedByDescending { it.amount },
            trend = buckets.map { b -> SeriesPoint(b.label, expenses.filter { it.date in b }.sumOf { it.amount }) },
            monthly = months.map { b -> SeriesPoint(b.label, expenses.filter { it.date in b }.sumOf { it.amount }) },
            livingAllocatedInPeriod = split.living,
            remainingInPeriod = split.living - expTotal,
            livingBalanceAtEnd = endOverview.account(AccountType.LIVING).balance,
        )

        // ---------- Savings ----------
        val sav = led.filter { it.account == AccountType.SAVINGS }
        val savIn = split.savings + sav.filter { it.type.direction == TxDirection.IN }.sumOf { it.amount }
        val savOut = sav.filter { it.type.direction == TxDirection.OUT }.sumOf { it.amount }
        val savBalance = endOverview.savingsBalance
        val savings = SavingsReport(
            contributions = savIn,
            withdrawals = savOut,
            balanceAtEnd = savBalance,
            growth = buckets.map { b ->
                SeriesPoint(b.label, LedgerCalculator.overview(incomes, ledger, upTo = b.end).savingsBalance)
            },
            target = savingsTarget?.takeIf { it > 0 },
            targetProgress = savingsTarget?.takeIf { it > 0 }?.let {
                (savBalance.toDouble() / it).toFloat().coerceIn(0f, 1f)
            },
        )

        // ---------- Investments ----------
        val contribs = led.filter { it.type == TxType.INVESTMENT_CONTRIBUTION }
        val investment = InvestmentReport(
            contributions = contribs.sumOf { it.amount },
            returns = led.filter { it.type == TxType.INVESTMENT_RETURN }.sumOf { it.amount },
            cashouts = led.filter { it.type == TxType.INVESTMENT_CASHOUT }.sumOf { it.amount },
            holdingsValueAtEnd = endOverview.investmentHoldingsValue,
            contributionsWithValue = contribs.count { it.currentValue != null },
            totalContributionsCount = contribs.size,
            byType = contribs.groupBy { it.investmentType ?: "Other" }
                .map { (t, l) -> NamedAmount(t, l.sumOf { it.amount }) }
                .sortedByDescending { it.amount },
            cashBalanceAtEnd = endOverview.account(AccountType.INVESTMENTS).balance,
        )

        // ---------- Overall ----------
        val startOverview = LedgerCalculator.overview(incomes, ledger, upTo = range.start.minusDays(1))
        val overall = OverallReport(
            totalIncome = total,
            livingExpenses = expTotal,
            savingsAllocated = split.savings,
            investmentContributions = investment.contributions,
            giving = led.filter { it.type.isGiving }.sumOf { it.amount },
            balancesAtEnd = AccountType.entries.associateWith { endOverview.account(it).balance },
            wealthAtStart = startOverview.wealthBuilt,
            wealthAtEnd = endOverview.wealthBuilt,
            wealthGrowth = buckets.map { b ->
                SeriesPoint(b.label, LedgerCalculator.overview(incomes, ledger, upTo = b.end).wealthBuilt)
            },
        )

        return FullReport(
            range, income, allocation, expenditure, savings, investment, overall,
            LoanReport.build(loans, range, today, unit),
        )
    }

    /** Month summary shown under the calendar. */
    data class MonthSummary(
        val total: Long,
        val daysWithIncome: Int,
        val averagePerIncomeDay: Long,
        val split: AllocationSplit,
        val dailyTotals: Map<LocalDate, Long>,
    )

    fun monthSummary(incomes: List<IncomeRecord>, month: YearMonth): MonthSummary {
        val inMonth = incomes.filter { YearMonth.from(it.date) == month }
        val daily = inMonth.groupBy { it.date }.mapValues { (_, l) -> l.sumOf { it.amount } }
        val total = inMonth.sumOf { it.amount }
        return MonthSummary(
            total = total,
            daysWithIncome = daily.size,
            averagePerIncomeDay = if (daily.isEmpty()) 0 else total / daily.size,
            split = inMonth.fold(AllocationSplit.ZERO) { a, r -> a + r.split },
            dailyTotals = daily,
        )
    }
}
