package com.babylon.moneytracker.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.babylon.moneytracker.domain.Goal
import com.babylon.moneytracker.domain.GoalMetric
import com.babylon.moneytracker.domain.GoalProgress
import com.babylon.moneytracker.domain.Money
import com.babylon.moneytracker.ui.AppState
import com.babylon.moneytracker.ui.MainViewModel
import com.babylon.moneytracker.ui.components.AmountField
import com.babylon.moneytracker.ui.components.DateField
import com.babylon.moneytracker.ui.components.DateShort
import com.babylon.moneytracker.ui.components.EmptyNote
import com.babylon.moneytracker.ui.components.LocalMoney
import com.babylon.moneytracker.ui.components.ProgressBar
import com.babylon.moneytracker.ui.components.ScreenTopBar
import com.babylon.moneytracker.ui.components.SectionCard
import com.babylon.moneytracker.ui.components.SelectField
import com.babylon.moneytracker.ui.theme.Palette
import java.time.LocalDate
import java.time.temporal.ChronoUnit

/** Sentinel for "new goal" in the editor. */
private val NEW_GOAL = Goal(0, "", 0, null, GoalMetric.SAVINGS_BALANCE, 0)

@Composable
fun GoalsScreen(state: AppState, vm: MainViewModel) {
    var editing by remember { mutableStateOf<Goal?>(null) }

    Column(Modifier.fillMaxSize()) {
        ScreenTopBar(
            title = "My Financial Goals",
            actions = {
                IconButton(onClick = { editing = NEW_GOAL }) { Icon(Icons.Filled.Add, contentDescription = "New goal") }
            },
        )
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (state.goals.isEmpty()) {
                SectionCard {
                    Text("Set your first goal", style = MaterialTheme.typography.titleMedium)
                    EmptyNote(
                        "For example: save UGX 5,000,000, invest UGX 3,000,000, or build an emergency fund. " +
                            "Progress updates automatically from your accounts."
                    )
                    OutlinedButton(onClick = { editing = NEW_GOAL }) { Text("Create a goal") }
                }
            }
            state.goals.forEach { g -> GoalCard(g, state.today) { editing = g.goal } }
            Spacer(Modifier.height(88.dp))
        }
    }

    editing?.let { goal ->
        GoalEditor(state, vm, goal) { editing = null }
    }
}

@Composable
private fun GoalCard(p: GoalProgress, today: LocalDate, onClick: () -> Unit) {
    val fmt = LocalMoney.current
    val g = p.goal
    SectionCard(onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(g.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            if (p.isComplete) Icon(Icons.Filled.CheckCircle, contentDescription = "Achieved", tint = MaterialTheme.colorScheme.primary)
        }
        Text(g.metric.label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
            Text(fmt(p.current), style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
            Text("${p.percent}%", style = MaterialTheme.typography.titleMedium, color = Palette.Gold)
        }
        Text("of ${fmt(g.target)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(8.dp))
        ProgressBar(p.fraction, if (p.isComplete) MaterialTheme.colorScheme.primary else Palette.Gold, height = 10)
        g.targetDate?.let { d ->
            val days = ChronoUnit.DAYS.between(today, d)
            val remaining = (g.target - p.current).coerceAtLeast(0)
            val text = when {
                p.isComplete -> "Target date ${d.format(DateShort)} · achieved"
                days < 0 -> "Target date ${d.format(DateShort)} has passed · ${fmt(remaining)} to go"
                else -> "${d.format(DateShort)} · $days days left · ${fmt(remaining)} to go"
            }
            Spacer(Modifier.height(6.dp))
            Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun GoalEditor(state: AppState, vm: MainViewModel, goal: Goal, onClose: () -> Unit) {
    val context = LocalContext.current
    val decimals = state.settings.currencyDecimals
    val isNew = goal.id == 0L
    var name by remember { mutableStateOf(goal.name) }
    var target by remember { mutableStateOf(if (isNew) "" else Money.toInput(goal.target, decimals)) }
    var metric by remember { mutableStateOf(goal.metric) }
    var manual by remember { mutableStateOf(if (goal.manualCurrent > 0) Money.toInput(goal.manualCurrent, decimals) else "") }
    var date by remember { mutableStateOf(goal.targetDate) }
    var confirmDelete by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(if (isNew) "New goal" else "Edit goal") },
        text = {
            Column(
                Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it }, singleLine = true,
                    label = { Text("Goal name") }, modifier = Modifier.fillMaxWidth(),
                )
                AmountField(target, { target = it }, "Target amount", decimals = decimals)
                SelectField("Track progress using", GoalMetric.entries, metric, { it.label }, { metric = it })
                if (metric == GoalMetric.MANUAL) {
                    AmountField(manual, { manual = it }, "Current amount", decimals = decimals, optional = true)
                }
                DateField("Target date (optional)", date, { date = it }, onClear = { date = null })
                if (!isNew) {
                    TextButton(onClick = { confirmDelete = true }) {
                        Text("Delete goal", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                vm.saveGoal(if (isNew) null else goal.id, name, target, date, metric, manual) { err ->
                    if (err != null) Toast.makeText(context, err, Toast.LENGTH_LONG).show() else onClose()
                }
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } },
    )

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Delete this goal?") },
            text = { Text("Your financial records are not affected.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.deleteGoal(goal.id) { onClose() }
                    confirmDelete = false
                }) { Text("Delete", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel") } },
        )
    }
}
