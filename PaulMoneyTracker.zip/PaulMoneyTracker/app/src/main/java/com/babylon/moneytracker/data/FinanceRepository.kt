package com.babylon.moneytracker.data

import androidx.room.withTransaction
import com.babylon.moneytracker.data.db.AccountTransaction
import com.babylon.moneytracker.data.db.Allocation
import com.babylon.moneytracker.data.db.AppDatabase
import com.babylon.moneytracker.data.db.ExpenseTransaction
import com.babylon.moneytracker.data.db.IncomeTransaction
import com.babylon.moneytracker.data.db.InvestmentTransaction
import com.babylon.moneytracker.data.db.Loan
import com.babylon.moneytracker.data.db.LoanRepayment
import com.babylon.moneytracker.data.db.SavingsGoal
import com.babylon.moneytracker.domain.AccountType
import com.babylon.moneytracker.domain.AllocationCalculator
import com.babylon.moneytracker.domain.Goal
import com.babylon.moneytracker.domain.GoalMetric
import com.babylon.moneytracker.domain.IncomeRecord
import com.babylon.moneytracker.domain.InterestPeriod
import com.babylon.moneytracker.domain.LOAN_ACCOUNTS
import com.babylon.moneytracker.domain.LedgerCalculator
import com.babylon.moneytracker.domain.LedgerRecord
import com.babylon.moneytracker.domain.LoanCalculator
import com.babylon.moneytracker.domain.LoanDirection
import com.babylon.moneytracker.domain.LoanPayment
import com.babylon.moneytracker.domain.LoanRecord
import com.babylon.moneytracker.domain.Money
import com.babylon.moneytracker.domain.Percentages
import com.babylon.moneytracker.domain.RepaymentOrder
import com.babylon.moneytracker.domain.TxType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import java.time.LocalDate
import java.util.UUID

/** Input for an envelope transaction. Amounts are minor units. */
data class LedgerInput(
    val account: AccountType,
    val type: TxType,
    val amount: Long,
    val date: LocalDate,
    val description: String,
    val notes: String?,
    val expenseCategory: String? = null,
    val investmentType: String? = null,
    val currentValue: Long? = null,
)

/** Input for creating or editing a loan. Amounts are minor units. */
data class LoanInput(
    val direction: LoanDirection,
    val counterparty: String,
    val principal: Long,
    val date: LocalDate,
    val dueDate: LocalDate?,
    val account: AccountType,
    val interestRateBp: Int,
    val interestPeriod: InterestPeriod,
    val repaymentOrder: RepaymentOrder,
    val purpose: String?,
    val contact: String?,
    val notes: String?,
)

/**
 * The only place that writes financial records. Every multi-row write runs
 * inside a database transaction so an income and its four allocations are
 * always saved (or removed) together.
 */
class FinanceRepository(private val db: AppDatabase) {

    private val incomeDao = db.incomeDao()
    private val ledgerDao = db.ledgerDao()
    private val goalDao = db.goalDao()
    private val accountDao = db.accountDao()
    private val loanDao = db.loanDao()

    val incomes: Flow<List<IncomeRecord>> = incomeDao.observeAll().map { list -> list.map { it.toRecord() } }
    val ledger: Flow<List<LedgerRecord>> = ledgerDao.observeAll().map { list -> list.map { it.toRecord() } }
    val goals: Flow<List<Goal>> = goalDao.observeAll().map { list -> list.map { it.toGoal() } }

    /** Every loan with its repayments, rebuilt from the loan tables and the ledger. */
    val loans: Flow<List<LoanRecord>> =
        combine(loanDao.observeLoans(), loanDao.observeRepayments(), ledger) { loans, links, led ->
            buildLoanRecords(loans, links, led)
        }

    /** Display names for the four envelopes (user-editable). */
    val accountNames: Flow<Map<AccountType, String>> = accountDao.observeAll().map { rows ->
        AccountType.entries.associateWith { t -> rows.firstOrNull { it.id == t.id }?.name ?: t.defaultName }
    }

    // ---------------- Income ----------------

    suspend fun addIncome(
        amount: Long,
        date: LocalDate,
        source: String,
        description: String?,
        percentages: Percentages,
        unit: Long,
    ): Long {
        require(amount > 0) { "Income must be greater than zero" }
        val now = System.currentTimeMillis()
        return db.withTransaction {
            val id = incomeDao.insert(
                IncomeTransaction(
                    amountMinor = amount,
                    dateEpochDay = date.toEpochDay(),
                    source = source,
                    description = description?.takeIf { it.isNotBlank() },
                    livingBp = percentages.living,
                    savingsBp = percentages.savings,
                    investmentsBp = percentages.investments,
                    givingBp = percentages.giving,
                    createdAt = now,
                    updatedAt = now,
                )
            )
            incomeDao.insertAllocations(allocationRows(id, amount, percentages, unit))
            id
        }
    }

    /**
     * Edits an income entry. Its original allocations are removed and rebuilt
     * from the new amount using the percentages stored on the entry itself,
     * so a later change to the settings never rewrites history.
     */
    suspend fun updateIncome(id: Long, amount: Long, date: LocalDate, source: String, description: String?, unit: Long) {
        require(amount > 0) { "Income must be greater than zero" }
        db.withTransaction {
            val existing = incomeDao.getById(id) ?: error("Income entry not found")
            incomeDao.update(
                existing.copy(
                    amountMinor = amount,
                    dateEpochDay = date.toEpochDay(),
                    source = source,
                    description = description?.takeIf { it.isNotBlank() },
                    updatedAt = System.currentTimeMillis(),
                )
            )
            incomeDao.deleteAllocations(id)
            incomeDao.insertAllocations(allocationRows(id, amount, existing.percentages(), unit))
        }
    }

    /** Removes an income entry and its four allocations together. */
    suspend fun deleteIncome(id: Long) {
        db.withTransaction {
            incomeDao.deleteAllocations(id) // the foreign-key cascade would do this too; explicit is safer
            incomeDao.delete(id)
        }
    }

    suspend fun getIncome(id: Long): IncomeTransaction? = incomeDao.getById(id)

    suspend fun incomeCountOn(date: LocalDate): Int = incomeDao.countOn(date.toEpochDay())

    private fun allocationRows(incomeId: Long, amount: Long, p: Percentages, unit: Long): List<Allocation> {
        val split = AllocationCalculator.allocate(amount, p, unit)
        return AccountType.entries.map { t ->
            Allocation(incomeId = incomeId, accountId = t.id, percentBp = p.of(t), amountMinor = split.of(t))
        }
    }

    // ---------------- Envelope transactions ----------------

    suspend fun addLedger(input: LedgerInput): Long {
        validate(input)
        val now = System.currentTimeMillis()
        return db.withTransaction {
            val id = ledgerDao.insert(
                AccountTransaction(
                    accountId = input.account.id,
                    type = input.type,
                    amountMinor = input.amount,
                    dateEpochDay = input.date.toEpochDay(),
                    description = input.description.trim(),
                    notes = input.notes?.takeIf { it.isNotBlank() },
                    referenceId = null,
                    createdAt = now,
                    updatedAt = now,
                )
            )
            writeDetails(id, input)
            id
        }
    }

    suspend fun updateLedger(id: Long, input: LedgerInput) {
        validate(input)
        db.withTransaction {
            val existing = ledgerDao.getById(id)?.tx ?: error("Transaction not found")
            require(!existing.type.isTransfer) { "Use updateTransfer for transfers" }
            require(!existing.type.isLoan) { "This entry belongs to a loan. Edit it from the Loans section." }
            ledgerDao.update(
                existing.copy(
                    accountId = input.account.id,
                    type = input.type,
                    amountMinor = input.amount,
                    dateEpochDay = input.date.toEpochDay(),
                    description = input.description.trim(),
                    notes = input.notes?.takeIf { it.isNotBlank() },
                    updatedAt = System.currentTimeMillis(),
                )
            )
            ledgerDao.deleteExpenseFor(id)
            ledgerDao.deleteInvestmentFor(id)
            writeDetails(id, input)
        }
    }

    /** Deletes a transaction. Deleting either leg of a transfer deletes both legs. */
    suspend fun deleteLedger(id: Long) {
        db.withTransaction {
            val existing = ledgerDao.getById(id)?.tx ?: return@withTransaction
            require(!existing.type.isLoan) { "This entry belongs to a loan. Delete it from the Loans section." }
            val ref = existing.referenceId
            val ids = if (existing.type.isTransfer && ref != null) ledgerDao.getByReference(ref).map { it.id } else listOf(id)
            ids.forEach { txId ->
                ledgerDao.deleteExpenseFor(txId)
                ledgerDao.deleteInvestmentFor(txId)
                ledgerDao.delete(txId)
            }
        }
    }

    suspend fun getLedger(id: Long): LedgerRecord? = ledgerDao.getById(id)?.toRecord()

    /**
     * Moves money between two envelopes. Recorded as two linked rows
     * (OUT on [from], IN on [to]); never counted as income or expenditure.
     */
    suspend fun transfer(from: AccountType, to: AccountType, amount: Long, date: LocalDate, description: String) {
        require(from != to) { "Choose two different accounts" }
        require(amount > 0) { "Amount must be greater than zero" }
        val ref = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        db.withTransaction {
            ledgerDao.insert(transferRow(from, TxType.TRANSFER_OUT, amount, date, description, ref, now))
            ledgerDao.insert(transferRow(to, TxType.TRANSFER_IN, amount, date, description, ref, now))
        }
    }

    suspend fun updateTransfer(ref: String, amount: Long, date: LocalDate, description: String) {
        require(amount > 0) { "Amount must be greater than zero" }
        db.withTransaction {
            ledgerDao.getByReference(ref).forEach { row ->
                ledgerDao.update(
                    row.copy(
                        amountMinor = amount,
                        dateEpochDay = date.toEpochDay(),
                        description = description.trim(),
                        updatedAt = System.currentTimeMillis(),
                    )
                )
            }
        }
    }

    suspend fun transferLegs(ref: String): List<AccountTransaction> = ledgerDao.getByReference(ref)

    private fun transferRow(
        account: AccountType, type: TxType, amount: Long, date: LocalDate, description: String, ref: String, now: Long,
    ) = AccountTransaction(
        accountId = account.id,
        type = type,
        amountMinor = amount,
        dateEpochDay = date.toEpochDay(),
        description = description.trim().ifBlank { "Transfer" },
        notes = null,
        referenceId = ref,
        createdAt = now,
        updatedAt = now,
    )

    private suspend fun writeDetails(txId: Long, input: LedgerInput) {
        if (input.type == TxType.EXPENSE) {
            ledgerDao.insertExpense(ExpenseTransaction(accountTransactionId = txId, category = input.expenseCategory ?: "Other"))
        }
        if (input.account == AccountType.INVESTMENTS) {
            ledgerDao.insertInvestment(
                InvestmentTransaction(
                    accountTransactionId = txId,
                    investmentType = input.investmentType ?: "Other",
                    currentValueMinor = if (input.type == TxType.INVESTMENT_CONTRIBUTION) input.currentValue else null,
                )
            )
        }
    }

    private fun validate(input: LedgerInput) {
        require(input.amount > 0) { "Amount must be greater than zero" }
        require(input.account in input.type.accounts) { "${input.type.label} is not allowed for this account" }
        require(!input.type.isTransfer) { "Use transfer() for transfers" }
        require(!input.type.isLoan) { "Loan entries are recorded from the Loans section" }
        require(input.currentValue == null || input.currentValue >= 0) { "Value cannot be negative" }
    }


    // ---------------- Loans ----------------
    //
    // Every loan action writes the loan row AND its account-ledger row inside one
    // database transaction, then re-checks the result. If a check fails, the
    // exception rolls the whole transaction back, so the loan ledger and the
    // account balances can never disagree.

    private fun buildLoanRecords(loans: List<Loan>, links: List<LoanRepayment>, ledger: List<LedgerRecord>): List<LoanRecord> {
        val byId = ledger.associateBy { it.id }
        val linksByLoan = links.groupBy { it.loanId }
        return loans.map { l ->
            LoanRecord(
                id = l.id,
                direction = l.direction,
                counterparty = l.counterparty,
                principal = l.principalMinor,
                date = LocalDate.ofEpochDay(l.dateEpochDay),
                dueDate = l.dueDateEpochDay?.let { LocalDate.ofEpochDay(it) },
                account = byId[l.disbursementTxId]?.account ?: AccountType.LIVING,
                interestRateBp = l.interestRateBp,
                interestPeriod = l.interestPeriod,
                repaymentOrder = l.repaymentOrder,
                purpose = l.purpose,
                contact = l.contact,
                notes = l.notes,
                disbursementTxId = l.disbursementTxId,
                payments = linksByLoan[l.id].orEmpty().mapNotNull { link ->
                    byId[link.accountTransactionId]?.let { t ->
                        LoanPayment(t.id, t.amount, t.date, t.account, t.notes, t.createdAt)
                    }
                },
                createdAt = l.createdAt,
            )
        }
    }

    private suspend fun ledgerNow(): List<LedgerRecord> = ledgerDao.getAll().map { it.toRecord() }
    private suspend fun incomesNow(): List<IncomeRecord> = incomeDao.getAll().map { it.toRecord() }

    private suspend fun currencyUnit(): Long = Money.allocationUnit(db.settingsDao().getSettings()?.currencyDecimals ?: 0)

    private suspend fun fmt(minor: Long): String {
        val s = db.settingsDao().getSettings()
        return Money.format(minor, s?.currencySymbol ?: "UGX", s?.currencyDecimals ?: 0)
    }

    /**
     * Rejects the change if it pushed any account below zero (balances are compared
     * before and after the change). Accounts that the change did not reduce are left alone.
     */
    private suspend fun ensureNoOverdraft(incomes: List<IncomeRecord>, before: List<LedgerRecord>) {
        val b = LedgerCalculator.overview(incomes, before)
        val a = LedgerCalculator.overview(incomes, ledgerNow())
        for (t in AccountType.entries) {
            val was = b.account(t).balance
            val now = a.account(t).balance
            if (now < was && now < 0) {
                val name = accountDao.getAll().firstOrNull { it.id == t.id }?.name ?: t.defaultName
                throw IllegalArgumentException(
                    "Not enough money in $name. Available: ${fmt(was.coerceAtLeast(0))}."
                )
            }
        }
    }

    private suspend fun loadLoan(id: Long): LoanRecord? {
        val loan = loanDao.getLoan(id) ?: return null
        return buildLoanRecords(listOf(loan), loanDao.getRepaymentsFor(id), ledgerNow()).first()
    }

    /** Rejects the change if any repayment pays more than was owed at its date. */
    private suspend fun ensureNotOverpaid(loanId: Long) {
        val rec = loadLoan(loanId) ?: return
        val last = (rec.payments.map { it.date } + LocalDate.now() + rec.date).max()
        val state = LoanCalculator.compute(rec, last, currencyUnit())
        if (state.excess > 0) {
            throw IllegalArgumentException(
                "That is more than the balance owed. Reduce the amount by ${fmt(state.excess)}."
            )
        }
    }

    private fun validateLoan(input: LoanInput) {
        require(input.counterparty.isNotBlank()) {
            if (input.direction == LoanDirection.BORROWED) "Enter the creditor's name" else "Enter the borrower's name"
        }
        require(input.principal > 0) { "Amount must be greater than zero" }
        require(input.account in LOAN_ACCOUNTS) { "Choose Living Expenses, Savings or Debt Repayment/Giving" }
        require(input.dueDate == null || !input.dueDate.isBefore(input.date)) {
            "The expected repayment date cannot be before the loan date"
        }
        require(input.interestRateBp in 0..100_000) { "Enter an interest rate between 0% and 1000%" }
    }

    private fun disbursementType(d: LoanDirection) =
        if (d == LoanDirection.BORROWED) TxType.LOAN_RECEIVED else TxType.LOAN_GIVEN

    private fun disbursementText(d: LoanDirection, name: String) =
        if (d == LoanDirection.BORROWED) "Borrowed from ${name.trim()}" else "Lent to ${name.trim()}"

    private fun repaymentText(d: LoanDirection, name: String) =
        if (d == LoanDirection.BORROWED) "Repayment to ${name.trim()}" else "Repayment from ${name.trim()}"

    /** Registers money borrowed or lent, and moves it into / out of the chosen account. */
    suspend fun createLoan(input: LoanInput): Long {
        validateLoan(input)
        val now = System.currentTimeMillis()
        val noInterest = input.interestPeriod == InterestPeriod.NONE
        return db.withTransaction {
            val incomes = incomesNow()
            val before = ledgerNow()
            val txId = ledgerDao.insert(
                AccountTransaction(
                    accountId = input.account.id,
                    type = disbursementType(input.direction),
                    amountMinor = input.principal,
                    dateEpochDay = input.date.toEpochDay(),
                    description = disbursementText(input.direction, input.counterparty),
                    notes = input.purpose?.takeIf { it.isNotBlank() },
                    referenceId = null,
                    createdAt = now,
                    updatedAt = now,
                )
            )
            val id = loanDao.insertLoan(
                Loan(
                    direction = input.direction,
                    counterparty = input.counterparty.trim(),
                    principalMinor = input.principal,
                    dateEpochDay = input.date.toEpochDay(),
                    dueDateEpochDay = input.dueDate?.toEpochDay(),
                    interestRateBp = if (noInterest) 0 else input.interestRateBp,
                    interestPeriod = if (input.interestRateBp == 0) InterestPeriod.NONE else input.interestPeriod,
                    repaymentOrder = input.repaymentOrder,
                    purpose = input.purpose?.trim()?.takeIf { it.isNotBlank() },
                    contact = input.contact?.trim()?.takeIf { it.isNotBlank() },
                    notes = input.notes?.trim()?.takeIf { it.isNotBlank() },
                    disbursementTxId = txId,
                    createdAt = now,
                    updatedAt = now,
                )
            )
            ensureNoOverdraft(incomes, before)
            id
        }
    }

    /** Edits a loan's details. The outstanding balance is recalculated, never typed in. */
    suspend fun updateLoan(id: Long, input: LoanInput) {
        validateLoan(input)
        val noInterest = input.interestPeriod == InterestPeriod.NONE
        db.withTransaction {
            val existing = loanDao.getLoan(id) ?: error("Loan not found")
            val incomes = incomesNow()
            val before = ledgerNow()
            val earliestPayment = loadLoan(id)?.payments?.minOfOrNull { it.date }
            require(earliestPayment == null || !earliestPayment.isBefore(input.date)) {
                "A repayment is dated before this loan date. Change that repayment first."
            }
            val now = System.currentTimeMillis()
            loanDao.updateLoan(
                existing.copy(
                    counterparty = input.counterparty.trim(),
                    principalMinor = input.principal,
                    dateEpochDay = input.date.toEpochDay(),
                    dueDateEpochDay = input.dueDate?.toEpochDay(),
                    interestRateBp = if (noInterest) 0 else input.interestRateBp,
                    interestPeriod = if (input.interestRateBp == 0) InterestPeriod.NONE else input.interestPeriod,
                    repaymentOrder = input.repaymentOrder,
                    purpose = input.purpose?.trim()?.takeIf { it.isNotBlank() },
                    contact = input.contact?.trim()?.takeIf { it.isNotBlank() },
                    notes = input.notes?.trim()?.takeIf { it.isNotBlank() },
                    updatedAt = now,
                )
            )
            val tx = ledgerDao.getById(existing.disbursementTxId)?.tx ?: error("Loan transaction not found")
            ledgerDao.update(
                tx.copy(
                    accountId = input.account.id,
                    amountMinor = input.principal,
                    dateEpochDay = input.date.toEpochDay(),
                    description = disbursementText(existing.direction, input.counterparty),
                    notes = input.purpose?.trim()?.takeIf { it.isNotBlank() },
                    updatedAt = now,
                )
            )
            ensureNoOverdraft(incomes, before)
            ensureNotOverpaid(id)
        }
    }

    /** Deletes a loan, its repayments and every linked account entry, then re-checks balances. */
    suspend fun deleteLoan(id: Long) {
        db.withTransaction {
            val existing = loanDao.getLoan(id) ?: return@withTransaction
            val incomes = incomesNow()
            val before = ledgerNow()
            val links = loanDao.getRepaymentsFor(id)
            links.forEach { loanDao.deleteRepaymentByTx(it.accountTransactionId) }
            loanDao.deleteLoan(id)
            links.forEach { ledgerDao.delete(it.accountTransactionId) }
            ledgerDao.delete(existing.disbursementTxId)
            ensureNoOverdraft(incomes, before)
        }
    }

    /** Records a repayment made (borrowed loans) or received (lent loans). */
    suspend fun addLoanPayment(loanId: Long, amount: Long, date: LocalDate, account: AccountType, notes: String?): Long {
        require(amount > 0) { "Amount must be greater than zero" }
        require(account in LOAN_ACCOUNTS) { "Choose Living Expenses, Savings or Debt Repayment/Giving" }
        val now = System.currentTimeMillis()
        return db.withTransaction {
            val loan = loanDao.getLoan(loanId) ?: error("Loan not found")
            require(!date.isBefore(LocalDate.ofEpochDay(loan.dateEpochDay))) { "The repayment date cannot be before the loan date" }
            val incomes = incomesNow()
            val before = ledgerNow()
            val txId = ledgerDao.insert(
                AccountTransaction(
                    accountId = account.id,
                    type = if (loan.direction == LoanDirection.BORROWED) TxType.LOAN_REPAYMENT else TxType.LOAN_RECOVERED,
                    amountMinor = amount,
                    dateEpochDay = date.toEpochDay(),
                    description = repaymentText(loan.direction, loan.counterparty),
                    notes = notes?.trim()?.takeIf { it.isNotBlank() },
                    referenceId = null,
                    createdAt = now,
                    updatedAt = now,
                )
            )
            loanDao.insertRepayment(LoanRepayment(loanId = loanId, accountTransactionId = txId, createdAt = now))
            ensureNoOverdraft(incomes, before)
            ensureNotOverpaid(loanId)
            txId
        }
    }

    /** Edits a repayment: its account entry is changed in place and every balance recalculated. */
    suspend fun updateLoanPayment(txId: Long, amount: Long, date: LocalDate, account: AccountType, notes: String?) {
        require(amount > 0) { "Amount must be greater than zero" }
        require(account in LOAN_ACCOUNTS) { "Choose Living Expenses, Savings or Debt Repayment/Giving" }
        db.withTransaction {
            val link = loanDao.getRepaymentByTx(txId) ?: error("Repayment not found")
            val loan = loanDao.getLoan(link.loanId) ?: error("Loan not found")
            require(!date.isBefore(LocalDate.ofEpochDay(loan.dateEpochDay))) { "The repayment date cannot be before the loan date" }
            val incomes = incomesNow()
            val before = ledgerNow()
            val tx = ledgerDao.getById(txId)?.tx ?: error("Repayment not found")
            ledgerDao.update(
                tx.copy(
                    accountId = account.id,
                    amountMinor = amount,
                    dateEpochDay = date.toEpochDay(),
                    notes = notes?.trim()?.takeIf { it.isNotBlank() },
                    updatedAt = System.currentTimeMillis(),
                )
            )
            ensureNoOverdraft(incomes, before)
            ensureNotOverpaid(link.loanId)
        }
    }

    /** Deletes a repayment and reverses its effect on the account. */
    suspend fun deleteLoanPayment(txId: Long) {
        db.withTransaction {
            loanDao.getRepaymentByTx(txId) ?: return@withTransaction
            val incomes = incomesNow()
            val before = ledgerNow()
            loanDao.deleteRepaymentByTx(txId)
            ledgerDao.delete(txId)
            ensureNoOverdraft(incomes, before)
        }
    }

    // ---------------- Accounts & goals ----------------

    suspend fun renameAccount(type: AccountType, name: String) {
        accountDao.rename(type.id, name.trim().ifBlank { type.defaultName })
    }

    suspend fun saveGoal(
        id: Long?, name: String, target: Long, targetDate: LocalDate?, metric: GoalMetric, manualCurrent: Long,
    ) {
        require(name.isNotBlank()) { "Give the goal a name" }
        require(target > 0) { "Target must be greater than zero" }
        val row = SavingsGoal(
            id = id ?: 0,
            name = name.trim(),
            targetMinor = target,
            targetDateEpochDay = targetDate?.toEpochDay(),
            metric = metric,
            manualCurrentMinor = manualCurrent.coerceAtLeast(0),
            createdAt = System.currentTimeMillis(),
        )
        if (id == null) goalDao.insert(row) else goalDao.update(row)
    }

    suspend fun deleteGoal(id: Long) = goalDao.delete(id)
}
