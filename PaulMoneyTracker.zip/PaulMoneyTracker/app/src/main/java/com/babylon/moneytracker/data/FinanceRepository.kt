package com.babylon.moneytracker.data

import androidx.room.withTransaction
import com.babylon.moneytracker.data.db.AccountTransaction
import com.babylon.moneytracker.data.db.Allocation
import com.babylon.moneytracker.data.db.AppDatabase
import com.babylon.moneytracker.data.db.ExpenseTransaction
import com.babylon.moneytracker.data.db.IncomeTransaction
import com.babylon.moneytracker.data.db.InvestmentTransaction
import com.babylon.moneytracker.data.db.SavingsGoal
import com.babylon.moneytracker.domain.AccountType
import com.babylon.moneytracker.domain.AllocationCalculator
import com.babylon.moneytracker.domain.Goal
import com.babylon.moneytracker.domain.GoalMetric
import com.babylon.moneytracker.domain.IncomeRecord
import com.babylon.moneytracker.domain.LedgerRecord
import com.babylon.moneytracker.domain.Percentages
import com.babylon.moneytracker.domain.TxType
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.time.LocalDate
import java.util.UUID

/** Input for an envelope transaction. Amounts are minor units. */
data class LedgerInput(
    val account: AccountType,
    val type: TxType,
    val amount: Long,
    val date: LocalDate,
    val description: String,
    val notes: String?,
    val expenseCategory: String? = null,
    val investmentType: String? = null,
    val currentValue: Long? = null,
)

/**
 * The only place that writes financial records. Every multi-row write runs
 * inside a database transaction so an income and its four allocations are
 * always saved (or removed) together.
 */
class FinanceRepository(private val db: AppDatabase) {

    private val incomeDao = db.incomeDao()
    private val ledgerDao = db.ledgerDao()
    private val goalDao = db.goalDao()
    private val accountDao = db.accountDao()

    val incomes: Flow<List<IncomeRecord>> = incomeDao.observeAll().map { list -> list.map { it.toRecord() } }
    val ledger: Flow<List<LedgerRecord>> = ledgerDao.observeAll().map { list -> list.map { it.toRecord() } }
    val goals: Flow<List<Goal>> = goalDao.observeAll().map { list -> list.map { it.toGoal() } }

    /** Display names for the four envelopes (user-editable). */
    val accountNames: Flow<Map<AccountType, String>> = accountDao.observeAll().map { rows ->
        AccountType.entries.associateWith { t -> rows.firstOrNull { it.id == t.id }?.name ?: t.defaultName }
    }

    // ---------------- Income ----------------

    suspend fun addIncome(
        amount: Long,
        date: LocalDate,
        source: String,
        description: String?,
        percentages: Percentages,
        unit: Long,
    ): Long {
        require(amount > 0) { "Income must be greater than zero" }
        val now = System.currentTimeMillis()
        return db.withTransaction {
            val id = incomeDao.insert(
                IncomeTransaction(
                    amountMinor = amount,
                    dateEpochDay = date.toEpochDay(),
                    source = source,
                    description = description?.takeIf { it.isNotBlank() },
                    livingBp = percentages.living,
                    savingsBp = percentages.savings,
                    investmentsBp = percentages.investments,
                    givingBp = percentages.giving,
                    createdAt = now,
                    updatedAt = now,
                )
            )
            incomeDao.insertAllocations(allocationRows(id, amount, percentages, unit))
            id
        }
    }

    /**
     * Edits an income entry. Its original allocations are removed and rebuilt
     * from the new amount using the percentages stored on the entry itself,
     * so a later change to the settings never rewrites history.
     */
    suspend fun updateIncome(id: Long, amount: Long, date: LocalDate, source: String, description: String?, unit: Long) {
        require(amount > 0) { "Income must be greater than zero" }
        db.withTransaction {
            val existing = incomeDao.getById(id) ?: error("Income entry not found")
            incomeDao.update(
                existing.copy(
                    amountMinor = amount,
                    dateEpochDay = date.toEpochDay(),
                    source = source,
                    description = description?.takeIf { it.isNotBlank() },
                    updatedAt = System.currentTimeMillis(),
                )
            )
            incomeDao.deleteAllocations(id)
            incomeDao.insertAllocations(allocationRows(id, amount, existing.percentages(), unit))
        }
    }

    /** Removes an income entry and its four allocations together. */
    suspend fun deleteIncome(id: Long) {
        db.withTransaction {
            incomeDao.deleteAllocations(id) // the foreign-key cascade would do this too; explicit is safer
            incomeDao.delete(id)
        }
    }

    suspend fun getIncome(id: Long): IncomeTransaction? = incomeDao.getById(id)

    suspend fun incomeCountOn(date: LocalDate): Int = incomeDao.countOn(date.toEpochDay())

    private fun allocationRows(incomeId: Long, amount: Long, p: Percentages, unit: Long): List<Allocation> {
        val split = AllocationCalculator.allocate(amount, p, unit)
        return AccountType.entries.map { t ->
            Allocation(incomeId = incomeId, accountId = t.id, percentBp = p.of(t), amountMinor = split.of(t))
        }
    }

    // ---------------- Envelope transactions ----------------

    suspend fun addLedger(input: LedgerInput): Long {
        validate(input)
        val now = System.currentTimeMillis()
        return db.withTransaction {
            val id = ledgerDao.insert(
                AccountTransaction(
                    accountId = input.account.id,
                    type = input.type,
                    amountMinor = input.amount,
                    dateEpochDay = input.date.toEpochDay(),
                    description = input.description.trim(),
                    notes = input.notes?.takeIf { it.isNotBlank() },
                    referenceId = null,
                    createdAt = now,
                    updatedAt = now,
                )
            )
            writeDetails(id, input)
            id
        }
    }

    suspend fun updateLedger(id: Long, input: LedgerInput) {
        validate(input)
        db.withTransaction {
            val existing = ledgerDao.getById(id)?.tx ?: error("Transaction not found")
            require(!existing.type.isTransfer) { "Use updateTransfer for transfers" }
            ledgerDao.update(
                existing.copy(
                    accountId = input.account.id,
                    type = input.type,
                    amountMinor = input.amount,
                    dateEpochDay = input.date.toEpochDay(),
                    description = input.description.trim(),
                    notes = input.notes?.takeIf { it.isNotBlank() },
                    updatedAt = System.currentTimeMillis(),
                )
            )
            ledgerDao.deleteExpenseFor(id)
            ledgerDao.deleteInvestmentFor(id)
            writeDetails(id, input)
        }
    }

    /** Deletes a transaction. Deleting either leg of a transfer deletes both legs. */
    suspend fun deleteLedger(id: Long) {
        db.withTransaction {
            val existing = ledgerDao.getById(id)?.tx ?: return@withTransaction
            val ref = existing.referenceId
            val ids = if (existing.type.isTransfer && ref != null) ledgerDao.getByReference(ref).map { it.id } else listOf(id)
            ids.forEach { txId ->
                ledgerDao.deleteExpenseFor(txId)
                ledgerDao.deleteInvestmentFor(txId)
                ledgerDao.delete(txId)
            }
        }
    }

    suspend fun getLedger(id: Long): LedgerRecord? = ledgerDao.getById(id)?.toRecord()

    /**
     * Moves money between two envelopes. Recorded as two linked rows
     * (OUT on [from], IN on [to]); never counted as income or expenditure.
     */
    suspend fun transfer(from: AccountType, to: AccountType, amount: Long, date: LocalDate, description: String) {
        require(from != to) { "Choose two different accounts" }
        require(amount > 0) { "Amount must be greater than zero" }
        val ref = UUID.randomUUID().toString()
        val now = System.currentTimeMillis()
        db.withTransaction {
            ledgerDao.insert(transferRow(from, TxType.TRANSFER_OUT, amount, date, description, ref, now))
            ledgerDao.insert(transferRow(to, TxType.TRANSFER_IN, amount, date, description, ref, now))
        }
    }

    suspend fun updateTransfer(ref: String, amount: Long, date: LocalDate, description: String) {
        require(amount > 0) { "Amount must be greater than zero" }
        db.withTransaction {
            ledgerDao.getByReference(ref).forEach { row ->
                ledgerDao.update(
                    row.copy(
                        amountMinor = amount,
                        dateEpochDay = date.toEpochDay(),
                        description = description.trim(),
                        updatedAt = System.currentTimeMillis(),
                    )
                )
            }
        }
    }

    suspend fun transferLegs(ref: String): List<AccountTransaction> = ledgerDao.getByReference(ref)

    private fun transferRow(
        account: AccountType, type: TxType, amount: Long, date: LocalDate, description: String, ref: String, now: Long,
    ) = AccountTransaction(
        accountId = account.id,
        type = type,
        amountMinor = amount,
        dateEpochDay = date.toEpochDay(),
        description = description.trim().ifBlank { "Transfer" },
        notes = null,
        referenceId = ref,
        createdAt = now,
        updatedAt = now,
    )

    private suspend fun writeDetails(txId: Long, input: LedgerInput) {
        if (input.type == TxType.EXPENSE) {
            ledgerDao.insertExpense(ExpenseTransaction(accountTransactionId = txId, category = input.expenseCategory ?: "Other"))
        }
        if (input.account == AccountType.INVESTMENTS) {
            ledgerDao.insertInvestment(
                InvestmentTransaction(
                    accountTransactionId = txId,
                    investmentType = input.investmentType ?: "Other",
                    currentValueMinor = if (input.type == TxType.INVESTMENT_CONTRIBUTION) input.currentValue else null,
                )
            )
        }
    }

    private fun validate(input: LedgerInput) {
        require(input.amount > 0) { "Amount must be greater than zero" }
        require(input.account in input.type.accounts) { "${input.type.label} is not allowed for this account" }
        require(!input.type.isTransfer) { "Use transfer() for transfers" }
        require(input.currentValue == null || input.currentValue >= 0) { "Value cannot be negative" }
    }

    // ---------------- Accounts & goals ----------------

    suspend fun renameAccount(type: AccountType, name: String) {
        accountDao.rename(type.id, name.trim().ifBlank { type.defaultName })
    }

    suspend fun saveGoal(
        id: Long?, name: String, target: Long, targetDate: LocalDate?, metric: GoalMetric, manualCurrent: Long,
    ) {
        require(name.isNotBlank()) { "Give the goal a name" }
        require(target > 0) { "Target must be greater than zero" }
        val row = SavingsGoal(
            id = id ?: 0,
            name = name.trim(),
            targetMinor = target,
            targetDateEpochDay = targetDate?.toEpochDay(),
            metric = metric,
            manualCurrentMinor = manualCurrent.coerceAtLeast(0),
            createdAt = System.currentTimeMillis(),
        )
        if (id == null) goalDao.insert(row) else goalDao.update(row)
    }

    suspend fun deleteGoal(id: Long) = goalDao.delete(id)
}
