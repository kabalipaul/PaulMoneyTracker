# PaulMoneyTracker

A personal, offline Android app that records every amount you earn, splits it
automatically by the **70–10–10–10** principle from *The Richest Man in Babylon*,
and tracks spending, savings, investments, goals and reports.

- Kotlin · Jetpack Compose (Material 3) · MVVM · Room · Coroutines/Flow · WorkManager · Navigation Compose
- Works fully offline, no account, no bank connection. All data stays on the phone.
- Min Android 8.0 (API 26), target Android 15 (API 35).

See **docs/USER_GUIDE.md** for how to use the app and **docs/ARCHITECTURE.md** for design and financial rules.

---

## 1. Build the APK

### Option A: Android Studio (recommended)

1. Install **Android Studio** (Ladybug 2024.2 or newer) from developer.android.com/studio.
2. Unzip this project, then in Android Studio choose **File → Open** and select the `PaulMoneyTracker` folder.
3. Wait for "Gradle sync" to finish. The first time, it downloads Gradle and the libraries (needs internet once, a few hundred MB).
4. Build the APK: **Build → Build App Bundle(s) / APK(s) → Build APK(s)**.
   - Debug APK: `app/build/outputs/apk/debug/app-debug.apk`
   - Or for the release build, open the Gradle panel → `app → Tasks → build → assembleRelease`
     → `app/build/outputs/apk/release/app-release.apk`
5. Run the unit tests: right-click `app/src/test` → **Run 'Tests in test'**, or run `gradlew testDebugUnitTest`.

From a terminal instead (Windows: `gradlew.bat`):

```
./gradlew testDebugUnitTest
./gradlew assembleRelease
```

You need JDK 17+. Android Studio already includes one.

### Option B: GitHub (no Android Studio needed)

1. Create a **private** GitHub repository and upload this folder to it.
2. The included workflow `.github/workflows/build-apk.yml` runs the tests and builds the APK on every push.
3. Open the repository's **Actions** tab → latest run → download **PaulMoneyTracker-apk** (a zip containing the APK).

### About signing

From version 1.1.0, release builds are signed with the app's own key, `app/paul-release.jks`
(passwords in `app/keystore.properties`). Every build made from this project, on any computer or on GitHub,
therefore installs as an **update** over the previous version and keeps your data.
Keep the repository **private**: anyone with this key could sign an app that installs over yours.
Version 1.0.0 was signed with a temporary key, so moving from 1.0.0 to 1.1.0 needs a one-time uninstall.
Back up your data first (Settings → Back up database), then restore it after installing.

## 2. Install on your Android phone

1. Copy the `.apk` to your phone (USB cable, Google Drive, WhatsApp to yourself, etc.).
2. Tap the file in the phone's **Files** app.
3. If asked, allow **"Install unknown apps"** for the app you opened it with (Files, Drive, Chrome…).
4. Tap **Install**, then **Open**.
5. When asked, **allow notifications**. Daily reminders need this on Android 13+.
6. Optional: on some phones (Tecno, Infinix, Xiaomi, Samsung), battery savers stop reminders.
   Open Android **Settings → Apps → PaulMoneyTracker → Battery** and choose **Unrestricted / No restrictions**.

With a cable and Android Studio you can also press **Run ▶** to install directly
(enable *Developer options → USB debugging* on the phone first).

## 3. Project layout

```
app/src/main/java/com/babylon/moneytracker/
├── domain/        Pure Kotlin rules: Money, AllocationCalculator, LedgerCalculator, ReportCalculator, Periods
├── data/db/       Room entities, DAOs, AppDatabase
├── data/          FinanceRepository, SettingsRepository, mappers
├── reminder/      WorkManager worker, scheduler, boot receiver, notifications
├── export/        PDF writer, CSV exporter, share / save / backup / restore
├── ui/            ViewModels, navigation, theme, components (charts), screens
├── BabylonApp.kt  Application + dependency container
└── MainActivity.kt
app/src/test/      JUnit tests for allocation, balances, money formatting and reports
```

## 4. Testing checklist

Unit tests (`app/src/test`) cover: UGX 100,000 and 1,500,000 splits, rounding remainder to Living,
custom percentages, multiple incomes per day, edit/delete recalculation, expenses, savings withdrawals and
deposits, investment contributions vs. returns vs. cash-outs, transfers not counted as income, balances as
of a date, goal progress, custom-range reports, period ranges, and calendar month summaries.

Manual checks on a phone (from the spec):

| # | Scenario | How |
|---|----------|-----|
| 1–2 | Record 100,000 and 1,500,000 | Add Income; the preview and Home cards show 70/10/10/10 |
| 3–4 | Several incomes same day / different dates | Calendar: day totals and month summary |
| 5–6 | Edit / delete income | Tap an entry → change amount or delete; check the account cards |
| 7 | Living expense | My Accounts → Living → Record expense |
| 8 | Savings withdrawal | Savings → Withdraw |
| 9 | Investment + return | Investments → Invest money / Record return |
| 10 | Change percentages | Settings → Allocation; older entries keep their split |
| 11–12 | Custom report + exports | Reports → Custom range → Export PDF / CSV |
| 13 | Reminder with app closed | Set reminder 2 min ahead, swipe app away, wait |
| 14 | Reminder after reboot | Set time, restart phone, wait |
| 15 | Data persists | Force-close and reopen |
